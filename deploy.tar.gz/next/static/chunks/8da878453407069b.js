(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,384706,e=>{"use strict";var t=e.i(819016);e.s(["PopupModal",()=>t.default])},186761,254167,e=>{"use strict";var t=e.i(843476),a=e.i(271645);e.i(404121);var s=e.i(384706);e.i(489435);var o=e.i(573494),r=e.i(257320),l=e.i(926409),n=e.i(192885),i=e.i(134189),c=e.i(371275),d=e.i(427217),u=e.i(984174),m=e.i(521292),p=e.i(57135),h=e.i(163858),x=e.i(107657),g=e.i(91754);let b=a.forwardRef(function({title:e,titleId:t,...s},o){return a.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:o,"aria-labelledby":t},s),e?a.createElement("title",{id:t},e):null,a.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v2.25a2.25 2.25 0 0 1-2.25 2.25H6a2.25 2.25 0 0 1-2.25-2.25V6ZM3.75 15.75A2.25 2.25 0 0 1 6 13.5h2.25a2.25 2.25 0 0 1 2.25 2.25V18a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18v-2.25ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v2.25A2.25 2.25 0 0 1 18 10.5h-2.25a2.25 2.25 0 0 1-2.25-2.25V6ZM13.5 15.75a2.25 2.25 0 0 1 2.25-2.25H18a2.25 2.25 0 0 1 2.25 2.25V18A2.25 2.25 0 0 1 18 20.25h-2.25A2.25 2.25 0 0 1 13.5 18v-2.25Z"}))});var y=e.i(657688),f=e.i(383642),v=e.i(618566),w=e.i(113295),N=e.i(305957),j=e.i(958243);let C=[{id:1,title:"Idea Scope",description:"What type of storefront do you want to create?"},{id:2,title:"Company Details",description:"Tell us about your company"},{id:3,title:"Description",description:"Describe your business"},{id:4,title:"Subdomain",description:"Choose your storefront URL"},{id:5,title:"Logo",description:"Upload your company logo"},{id:6,title:"Theming",description:"Customize your storefront appearance"},{id:7,title:"Site Layout",description:"Choose how your site is structured"},{id:8,title:"AI Design",description:"Generate design recommendations"}],S=[{value:"fashion",label:"Fashion & Apparel"},{value:"electronics",label:"Electronics"},{value:"food",label:"Food & Beverages"},{value:"home",label:"Home & Living"},{value:"beauty",label:"Beauty & Cosmetics"},{value:"sports",label:"Sports & Outdoors"},{value:"books",label:"Books & Media"},{value:"toys",label:"Toys & Games"},{value:"other",label:"Other"}],k="storefront_wizard_data";e.s([],186761),e.s(["StorefrontWizard",0,({isOpen:e,onClose:P,onComplete:I})=>{let F=(0,v.useRouter)(),{user:$,loading:A}=(0,f.useAuth)(),[T,E]=(0,a.useState)(1),[B,O]=(0,a.useState)(!1),{showSuccess:D,showError:L}=(0,N.useToast)(),M=(0,j.getMainDomain)(),[U,q]=(0,a.useState)(!1),[z,R]=(0,a.useState)(!1),[W,G]=(0,a.useState)(!1),[H,Y]=(0,a.useState)([]),[J,V]=(0,a.useState)(0),[Z,_]=(0,a.useState)(""),[Q,K]=(0,a.useState)({}),[X,ee]=(0,a.useState)(!1),[et,ea]=(0,a.useState)(!1),es=async()=>{if($)try{let e=await (0,w.loadWizardFromFirebase)($);if(e)return{ideaScope:e.ideaScope||"",companyName:e.companyName||"",description:e.description||"",subdomain:e.subdomain||"",logo:null,logoPreview:e.logoPreview||null,theme:e.theme||er(),layout:e.layout||"multi-page"}}catch(e){console.error("Error loading from Firebase:",e)}if((0,w.hasLocalWizardData)()){let e=(0,w.loadWizardLocally)();if(e)return R(!0),{ideaScope:e.ideaScope||"",companyName:e.companyName||"",description:e.description||"",subdomain:e.subdomain||"",logo:null,logoPreview:e.logoPreview||null,theme:e.theme||er(),layout:e.layout||"multi-page"}}try{let e=localStorage.getItem(k);if(e){let t=JSON.parse(e);return{...t,logo:null,logoPreview:t.logoPreview||null,theme:t.theme||er(),layout:t.layout||"multi-page"}}}catch(e){console.error("Error loading saved form data:",e)}return eo()},eo=()=>({ideaScope:"",companyName:"",description:"",subdomain:"",logo:null,logoPreview:null,theme:er(),layout:"multi-page"}),er=()=>({primaryColor:"#3B82F6",fontFamily:"Inter",designFeel:"modern"}),[el,en]=(0,a.useState)(eo()),[ei,ec]=(0,a.useState)({}),[ed,eu]=(0,a.useState)(!1),[em,ep]=(0,a.useState)(!1);(0,a.useEffect)(()=>{(async()=>{e&&!em&&(en(await es()),ep(!0))})()},[e,$,em]),(0,a.useEffect)(()=>{A||O(!0),(async()=>{if($&&e&&B)try{let e=await (0,w.loadWizardFromFirebase)($);e&&(en({ideaScope:e.ideaScope||"",companyName:e.companyName||"",description:e.description||"",subdomain:e.subdomain||"",logo:null,logoPreview:e.logoPreview||null,theme:e.theme||er(),layout:e.layout||"multi-page"}),D("Your saved progress has been loaded!"))}catch(e){console.error("Error loading Firebase data:",e)}})()},[$,e,A,B]),(0,a.useEffect)(()=>{e&&em&&(async()=>{let e={ideaScope:el.ideaScope,companyName:el.companyName,description:el.description,subdomain:el.subdomain,logo:null,logoPreview:el.logoPreview,theme:el.theme||er(),layout:el.layout||"multi-page"};try{$?await (0,w.saveWizardToFirebase)(e,$):(0,w.saveWizardLocally)(e),localStorage.setItem(k,JSON.stringify(e))}catch(t){console.error("Error saving data:",t),localStorage.setItem(k,JSON.stringify(e))}})()},[el,e,$,em]),(0,a.useEffect)(()=>{if(e&&1){let e=localStorage.getItem(`${k}_step`);if(e){let t=parseInt(e,10);t>=1&&t<=C.length&&E(t)}}},[e]);let eh=e=>{let{name:t,value:a}=e.target,s={...el,[t]:a};en(s),ei[t]&&ec(e=>({...e,[t]:""}));{let e={...s,logo:null};localStorage.setItem(k,JSON.stringify(e))}},ex=e=>{let t=e.target.files?.[0];if(t){if(t.size>5242880)return void ec(e=>({...e,logo:"File size must be less than 5MB"}));if(!t.type.startsWith("image/"))return void ec(e=>({...e,logo:"File must be an image"}));let e=new FileReader;e.onloadend=()=>{let a={...el,logo:t,logoPreview:e.result};en(a);{let e={...a,logo:null};localStorage.setItem(k,JSON.stringify(e))}},e.readAsDataURL(t),ei.logo&&ec(e=>({...e,logo:""}))}},eg=e=>{let t={};switch(e){case 1:el.ideaScope||(t.ideaScope="Please select an idea scope");break;case 2:el.companyName||(t.companyName="Company name is required");break;case 3:el.description?el.description.length<50&&(t.description="Description must be at least 50 characters"):t.description="Description is required";break;case 4:el.subdomain?/^[a-z0-9-]+$/.test(el.subdomain)?el.subdomain.length<3&&(t.subdomain="Subdomain must be at least 3 characters"):t.subdomain="Subdomain can only contain lowercase letters, numbers, and hyphens":t.subdomain="Subdomain is required";break;case 5:break;case 6:el.theme?.primaryColor||(t.primaryColor="Primary color is required"),el.theme?.fontFamily||(t.fontFamily="Font family is required"),el.theme?.designFeel||(t.designFeel="Design feel is required");break;case 7:el.layout||(t.layout="Please select a layout")}return ec(t),0===Object.keys(t).length},eb=async()=>{if(!el.companyName||!el.description||!el.ideaScope)return void L("Please complete the previous steps before generating AI recommendations");q(!0);try{await new Promise(e=>setTimeout(e,2e3));let e=`Based on your ${el.ideaScope} storefront for ${el.companyName}, we recommend a ${el.theme?.designFeel||"modern"} design approach. The storefront should feature a clean, professional layout with ${el.theme?.primaryColor||"blue"} as the primary accent color. Use ${el.theme?.fontFamily||"Inter"} font family for a contemporary feel. Focus on showcasing your products with high-quality imagery and clear call-to-action buttons. The design should emphasize ${el.description}`;en(t=>({...t,theme:{...t.theme,aiDescription:e}})),D("AI design recommendations generated!")}catch(e){L("Failed to generate AI recommendations. Please try again.")}finally{q(!1)}},ey=async()=>{if(!el.companyName||!el.ideaScope)return void L("Company name and niche are required");ee(!0);try{let e=await fetch(`/api/ai/generate-description/questions/all?companyName=${encodeURIComponent(el.companyName)}&niche=${encodeURIComponent(el.ideaScope)}`);if(!e.ok)throw Error("Failed to fetch questions");let t=await e.json();if(t.questions&&t.questions.length>0)Y(t.questions),V(0),_(""),K({});else throw Error("No questions received")}catch(e){L(e.message||"Failed to load questions")}finally{ee(!1)}},ef=async()=>{if(!Z.trim())return void L("Please provide an answer");let e=H[J];if(!e)return;let t={...Q,[e.question]:Z};K(t),_(""),J<H.length-1?V(J+1):await ev(t)},ev=async e=>{if(0===Object.keys(e).length)return void L("No answers provided");ea(!0);try{let t=await fetch("/api/ai/generate-description",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({companyName:el.companyName,niche:el.ideaScope,answers:e})});if(!t.ok)throw Error("Failed to generate description");let a=await t.json();en(e=>({...e,description:a.description})),D("Business description generated successfully!"),G(!1),Y([]),K({}),V(0),_("")}catch(e){L(e.message||"Failed to generate description")}finally{ea(!1)}},ew=async()=>{if(eg(T)){if(!$){let e=window.location.pathname;F.push(`/signin?callbackUrl=${encodeURIComponent(e)}`);return}I?.(el),P(),setTimeout(()=>{E(1),en(eo()),eu(!1)},500)}},eN=()=>{P()};return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)(s.PopupModal,{isOpen:e,onClose:eN,size:"2xl",placement:"center",showCloseButton:!1,className:"max-w-3xl",children:[(0,t.jsxs)("div",{className:"p-6 relative",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-6",children:[(0,t.jsxs)("div",{children:[(0,t.jsx)("h2",{className:"text-2xl font-bold text-neutral-800",children:"Create Your Storefront"}),(0,t.jsxs)("p",{className:"text-sm text-neutral-600 mt-1",children:["Step ",T," of ",C.length]})]}),(0,t.jsx)("button",{onClick:eN,className:"p-2 hover:bg-neutral-100 rounded-full transition-colors",children:(0,t.jsx)(d.XMarkIcon,{className:"w-5 h-5 text-neutral-600"})})]}),(0,t.jsx)("div",{className:"mb-8",children:(0,t.jsx)("div",{className:"flex items-start justify-between mb-2 w-full",children:C.map((e,a)=>(0,t.jsxs)("div",{className:"flex items-start flex-1 relative",children:[(0,t.jsxs)("div",{className:"flex flex-col items-center flex-1 z-10",children:[(0,t.jsx)("div",{className:`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors shrink-0 ${T>=e.id?"bg-blue-600 border-blue-600 text-white":"border-neutral-300 bg-white text-neutral-400"}`,children:T>e.id?(0,t.jsx)(h.CheckCircleIcon,{className:"w-6 h-6"}):(0,t.jsx)("span",{className:"text-sm font-semibold",children:e.id})}),(0,t.jsx)("p",{className:`text-xs mt-2 text-center max-w-[100px] ${T>=e.id?"text-neutral-800 font-medium":"text-neutral-400"}`,children:e.title})]}),a<C.length-1&&(0,t.jsx)("div",{className:`absolute top-5 left-[calc(50%+20px)] right-0 h-0.5 transition-colors ${T>e.id?"bg-blue-600":"bg-neutral-200"}`,style:{width:"calc(100% - 40px)"}})]},e.id))})}),(0,t.jsx)("div",{className:"min-h-[400px] mb-6 relative",children:(()=>{switch(T){case 1:return(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"text-center mb-6",children:[(0,t.jsx)(u.SparklesIcon,{className:"w-16 h-16 text-blue-600 mx-auto mb-4"}),(0,t.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"What type of storefront do you want to create?"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Select the category that best describes your business"})]}),(0,t.jsx)("div",{className:"grid grid-cols-2 gap-3",children:S.map(e=>(0,t.jsx)("button",{type:"button",onClick:()=>{let t={...el,ideaScope:e.value};en(t),ei.ideaScope&&ec(e=>({...e,ideaScope:""}));{let e={...t,logo:null};localStorage.setItem(k,JSON.stringify(e))}},className:`p-4 rounded-lg border-2 transition-all text-left ${el.ideaScope===e.value?"border-blue-600 bg-blue-50":"border-neutral-200 hover:border-blue-300"}`,children:(0,t.jsx)("span",{className:"text-sm font-medium text-neutral-800",children:e.label})},e.value))}),ei.ideaScope&&(0,t.jsx)("p",{className:"text-sm text-error mt-2",children:ei.ideaScope})]});case 2:return(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"text-center mb-6",children:[(0,t.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Company Information"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Tell us about your company"})]}),(0,t.jsx)(o.Input,{label:"Dfold Lab",name:"companyName",type:"text",value:el.companyName,onChange:eh,error:ei.companyName,placeholder:"Enter your company name",className:"w-full"})]});case 3:return(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"text-center mb-6",children:[(0,t.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Business Description"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Describe what your business does (minimum 50 characters)"})]}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)(r.TextArea,{label:"Description",name:"description",value:el.description,onChange:eh,error:ei.description,placeholder:"Tell us about your business, products, and what makes you unique...",className:"w-full min-h-[150px] pr-12"}),el.companyName&&el.ideaScope&&(0,t.jsx)("button",{type:"button",onClick:()=>{el.companyName&&el.ideaScope?(G(!0),K({}),V(0),Y([]),ey()):L("Please complete company name and niche selection first")},className:"absolute right-3 top-9 p-2 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-600 transition-colors",title:"Generate description with AI",children:(0,t.jsx)(u.SparklesIcon,{className:"w-5 h-5"})})]}),(0,t.jsxs)("p",{className:"text-xs text-neutral-500",children:[el.description.length," / 50 characters minimum"]}),el.companyName&&el.ideaScope&&(0,t.jsxs)("p",{className:"text-xs text-blue-600 flex items-center gap-1",children:[(0,t.jsx)(u.SparklesIcon,{className:"w-3 h-3"}),"Click the sparkles icon to generate a description with AI"]})]});case 4:return(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"text-center mb-6",children:[(0,t.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Choose Your Subdomain"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"This will be your storefront URL"})]}),(0,t.jsxs)("div",{className:"relative",children:[(0,t.jsx)(o.Input,{label:"Subdomain",name:"subdomain",type:"text",value:el.subdomain,onChange:eh,error:ei.subdomain,placeholder:"your-store",className:"w-full pr-24"}),(0,t.jsxs)("div",{className:"absolute right-3 top-9 text-neutral-500 text-sm",children:[".",M]})]}),(0,t.jsxs)("div",{className:"bg-neutral-50 p-4 rounded-lg",children:[(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Your storefront will be available at:"}),(0,t.jsxs)("p",{className:"text-sm font-semibold text-primary-600 mt-1",children:[el.subdomain||"your-store",".",M]})]})]});case 5:return(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsxs)("div",{className:"text-center mb-6",children:[(0,t.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Upload Your Logo"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Add your company logo (PNG, JPG, max 5MB)"})]}),(0,t.jsx)("div",{className:"border-2 border-dashed border-neutral-300 rounded-lg p-8 text-center hover:border-primary-400 transition-colors",children:el.logoPreview?(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsx)("div",{className:"relative w-32 h-32 mx-auto",children:(0,t.jsx)(y.default,{src:el.logoPreview,alt:"Logo preview",fill:!0,className:"object-contain rounded-lg"})}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:el.logo?.name}),(0,t.jsx)("button",{type:"button",onClick:()=>{en(e=>({...e,logo:null,logoPreview:null}))},className:"text-sm text-error hover:text-error/80",children:"Remove"})]}):(0,t.jsxs)("label",{className:"cursor-pointer",children:[(0,t.jsx)("input",{type:"file",accept:"image/*",onChange:ex,className:"hidden"}),(0,t.jsxs)("div",{className:"space-y-2",children:[(0,t.jsx)("div",{className:"w-12 h-12 mx-auto bg-neutral-100 rounded-full flex items-center justify-center",children:(0,t.jsx)("svg",{className:"w-6 h-6 text-neutral-600",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,t.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 4v16m8-8H4"})})}),(0,t.jsx)("p",{className:"text-sm font-medium text-neutral-700",children:"Click to upload or drag and drop"}),(0,t.jsx)("p",{className:"text-xs text-neutral-500",children:"PNG, JPG up to 5MB"})]})]})}),ei.logo&&(0,t.jsx)("p",{className:"text-sm text-error mt-2",children:ei.logo})]});case 6:return(0,t.jsxs)("div",{className:"space-y-6",children:[(0,t.jsxs)("div",{className:"text-center mb-6",children:[(0,t.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Customize Your Storefront Appearance"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Choose colors, fonts, and design style for your storefront"})]}),(0,t.jsx)(i.ColorPicker,{value:el.theme?.primaryColor||"#3B82F6",onChange:e=>{en(t=>({...t,theme:{...t.theme,primaryColor:e}})),ei.primaryColor&&ec(e=>({...e,primaryColor:""}))},label:"Primary Color"}),ei.primaryColor&&(0,t.jsx)("p",{className:"text-sm text-error mt-1",children:ei.primaryColor}),(0,t.jsx)("div",{children:(0,t.jsxs)(l.Select,{label:"Font Family",name:"fontFamily",value:el.theme?.fontFamily||"Inter",onChange:e=>{en(t=>({...t,theme:{...t.theme,fontFamily:e.target.value}})),ei.fontFamily&&ec(e=>({...e,fontFamily:""}))},error:ei.fontFamily,className:"w-full",children:[(0,t.jsx)("option",{value:"Inter",children:"Inter (Modern)"}),(0,t.jsx)("option",{value:"Roboto",children:"Roboto (Clean)"}),(0,t.jsx)("option",{value:"Poppins",children:"Poppins (Bold)"}),(0,t.jsx)("option",{value:"Open Sans",children:"Open Sans (Friendly)"}),(0,t.jsx)("option",{value:"Montserrat",children:"Montserrat (Elegant)"}),(0,t.jsx)("option",{value:"Lato",children:"Lato (Professional)"})]})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-sm font-medium text-neutral-700 mb-2",children:"Design Feel"}),(0,t.jsx)("div",{className:"grid grid-cols-2 gap-3",children:[{value:"modern",label:"Modern",desc:"Clean and minimalist"},{value:"classic",label:"Classic",desc:"Traditional and elegant"},{value:"bold",label:"Bold",desc:"Vibrant and energetic"},{value:"minimal",label:"Minimal",desc:"Simple and focused"}].map(e=>(0,t.jsxs)("button",{type:"button",onClick:()=>{en(t=>({...t,theme:{...t.theme,designFeel:e.value}})),ei.designFeel&&ec(e=>({...e,designFeel:""}))},className:`p-4 rounded-lg border-2 text-left transition-all ${el.theme?.designFeel===e.value?"border-blue-600 bg-blue-50":"border-neutral-200 hover:border-blue-300"}`,children:[(0,t.jsx)("div",{className:"font-semibold text-neutral-800",children:e.label}),(0,t.jsx)("div",{className:"text-xs text-neutral-600 mt-1",children:e.desc})]},e.value))}),ei.designFeel&&(0,t.jsx)("p",{className:"text-sm text-error mt-2",children:ei.designFeel})]})]});case 7:return(0,t.jsx)("div",{className:"space-y-6",children:(0,t.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,t.jsxs)("button",{onClick:()=>en({...el,layout:"single-page"}),className:`p-6 rounded-2xl border-2 transition-all text-left flex flex-col gap-4 ${"single-page"===el.layout?"border-blue-500 bg-blue-50":"border-neutral-100 hover:border-neutral-200 bg-white"}`,children:[(0,t.jsx)("div",{className:`p-3 rounded-xl w-fit ${"single-page"===el.layout?"bg-blue-500 text-white":"bg-neutral-100 text-neutral-500"}`,children:(0,t.jsx)(g.DocumentIcon,{className:"w-8 h-8"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"font-bold text-lg text-neutral-900",children:"Single Page Layout"}),(0,t.jsx)("p",{className:"text-sm text-neutral-500 mt-1",children:"Everything on one page (Home, Products, Cart, Checkout). Perfect for simple, fast stores."})]}),"single-page"===el.layout&&(0,t.jsx)(h.CheckCircleIcon,{className:"w-6 h-6 text-blue-500 absolute top-4 right-4"})]}),(0,t.jsxs)("button",{onClick:()=>en({...el,layout:"multi-page"}),className:`p-6 rounded-2xl border-2 transition-all text-left flex flex-col gap-4 ${"multi-page"===el.layout?"border-blue-500 bg-blue-50":"border-neutral-100 hover:border-neutral-200 bg-white"}`,children:[(0,t.jsx)("div",{className:`p-3 rounded-xl w-fit ${"multi-page"===el.layout?"bg-blue-500 text-white":"bg-neutral-100 text-neutral-500"}`,children:(0,t.jsx)(b,{className:"w-8 h-8"})}),(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{className:"font-bold text-lg text-neutral-900",children:"Multi Page Layout"}),(0,t.jsx)("p",{className:"text-sm text-neutral-500 mt-1",children:"Standard e-commerce structure with separate pages for browsing, cart, and checkout."})]}),"multi-page"===el.layout&&(0,t.jsx)(h.CheckCircleIcon,{className:"w-6 h-6 text-blue-500 absolute top-4 right-4"})]})]})});case 8:return(0,t.jsxs)("div",{className:"space-y-6",children:[(0,t.jsxs)("div",{className:"text-center mb-6",children:[(0,t.jsx)(u.SparklesIcon,{className:"w-16 h-16 text-blue-600 mx-auto mb-4"}),(0,t.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"AI Design Recommendations"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Generate personalized design recommendations based on your storefront details"})]}),el.theme?.aiDescription?(0,t.jsxs)("div",{className:"bg-blue-50 border border-blue-200 rounded-lg p-6",children:[(0,t.jsxs)("div",{className:"flex items-start gap-3",children:[(0,t.jsx)(u.SparklesIcon,{className:"w-6 h-6 text-primary-600 flex-shrink-0 mt-0.5"}),(0,t.jsxs)("div",{className:"flex-1",children:[(0,t.jsx)("h4",{className:"font-semibold text-neutral-800 mb-2",children:"AI Design Analysis"}),(0,t.jsx)("p",{className:"text-sm text-neutral-700 leading-relaxed whitespace-pre-wrap",children:el.theme.aiDescription})]})]}),(0,t.jsx)(n.Button,{type:"button",variant:"light",onClick:eb,isLoading:U,className:"mt-4",children:"Regenerate"})]}):(0,t.jsx)("div",{className:"text-center py-12",children:U?(0,t.jsx)(c.CaptivatingLoader,{loadingTexts:["Analyzing your business details...","Generating color palette options...","Selecting typography combinations...","Crafting layout recommendations...","Finalizing your design..."],subText:"Our AI is creating a custom design just for you"}):(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)("p",{className:"text-neutral-600 mb-6",children:"Click the button below to generate AI-powered design recommendations for your storefront"}),(0,t.jsx)(n.Button,{type:"button",onPress:eb,loading:U,color:"primary",className:"text-white",startContent:(0,t.jsx)(u.SparklesIcon,{className:"w-5 h-5"}),children:"Generate Design Recommendations"})]})})]});default:return null}})()}),(0,t.jsxs)("div",{className:"flex items-center justify-between pt-6 border-t border-neutral-200",children:[(0,t.jsx)(n.Button,{type:"button",variant:"bordered",onClick:()=>{T>1&&E(T-1)},isDisabled:1===T,startContent:(0,t.jsx)(p.ArrowLeftIcon,{className:"w-4 h-4"}),className:`border-neutral-300 text-neutral-600 hover:bg-neutral-50 ${1===T?"invisible":"visible"}`,children:"Previous"}),(0,t.jsx)("div",{className:"flex gap-2",children:T<C.length?(0,t.jsx)(n.Button,{type:"button",onClick:()=>{if(eg(T)&&T<C.length){let e=T+1;E(e),localStorage.setItem(`${k}_step`,e.toString())}},className:"bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md hover:shadow-lg transition-all",endContent:(0,t.jsx)(m.ArrowRightIcon,{className:"w-4 h-4"}),children:"Next"}):(0,t.jsxs)(t.Fragment,{children:[!$&&(0,t.jsxs)("div",{className:"flex items-center gap-2 text-sm text-neutral-600 mb-2",children:[(0,t.jsx)(x.LockClosedIcon,{className:"w-4 h-4"}),(0,t.jsx)("span",{children:"Sign in required to create storefront"})]}),(0,t.jsx)(n.Button,{type:"button",onClick:ew,loading:ed,className:"bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md hover:shadow-lg transition-all",endContent:(0,t.jsx)(h.CheckCircleIcon,{className:"w-4 h-4"}),children:"Create Storefront"})]})})]})]}),(0,t.jsx)(s.PopupModal,{isOpen:z,onClose:()=>R(!1),title:"Found Saved Progress",size:"md",children:(0,t.jsxs)("div",{className:"space-y-4",children:[(0,t.jsx)("p",{className:"text-neutral-600",children:"We found saved progress from a previous session. Would you like to continue from where you left off?"}),(0,t.jsxs)("div",{className:"flex gap-3",children:[(0,t.jsx)(n.Button,{onPress:()=>{R(!1),D("Continuing with saved progress")},className:"flex-1 bg-blue-600 hover:bg-blue-700 text-white",children:"Continue"}),(0,t.jsx)(n.Button,{onPress:()=>{(0,w.clearWizardLocally)(),en(eo()),R(!1),D("Starting fresh")},variant:"bordered",className:"flex-1",children:"Start Fresh"})]})]})}),B?$||T!==C.length?null:(0,t.jsx)("div",{className:"absolute inset-0 bg-white/95 backdrop-blur-sm flex items-center justify-center z-10 rounded-lg",children:(0,t.jsxs)("div",{className:"text-center p-6 max-w-md",children:[(0,t.jsx)(x.LockClosedIcon,{className:"w-12 h-12 text-blue-600 mx-auto mb-4"}),(0,t.jsx)("h3",{className:"text-lg font-semibold text-neutral-800 mb-2",children:"Sign In Required"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600 mb-6",children:"Please sign in or create an account to create your storefront. Your progress has been saved and will be restored when you return."}),(0,t.jsxs)("div",{className:"flex gap-3 justify-center",children:[(0,t.jsx)(n.Button,{onClick:()=>{P(),F.push("/signup")},className:"bg-blue-600 hover:bg-blue-700 text-white",children:"Sign Up"}),(0,t.jsx)(n.Button,{onClick:()=>{let e=window.location.pathname;F.push(`/signin?callbackUrl=${encodeURIComponent(e)}`)},variant:"bordered",className:"border-neutral-300",children:"Sign In"})]})]})}):(0,t.jsx)("div",{className:"absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-10 rounded-lg",children:(0,t.jsxs)("div",{className:"text-center",children:[(0,t.jsx)("div",{className:"animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600",children:"Checking authentication..."})]})})]}),(0,t.jsx)(s.PopupModal,{isOpen:W,onClose:()=>{G(!1),K({}),Y([]),V(0),_("")},title:"AI Description Generator",size:"md",children:(0,t.jsx)("div",{className:"space-y-6",children:et?(0,t.jsx)(c.CaptivatingLoader,{loadingTexts:["Synthesizing your answers...","Drafting compelling copy...","Optimizing for SEO...","Polishing the tone...","Almost ready..."],subText:"Creating your unique business description"}):X?(0,t.jsx)("div",{className:"py-8",children:(0,t.jsx)(c.CaptivatingLoader,{loadingTexts:["Preparing AI interview...","Understanding your business...","Crafting relevant questions...","Almost ready..."],subText:"Our AI is tailored to your niche"})}):H.length>0&&J<H.length?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{className:"bg-blue-50 rounded-lg p-4 mb-4",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between mb-2",children:[(0,t.jsxs)("span",{className:"text-sm font-semibold text-blue-600",children:["Question ",J+1," of ",H.length]}),(0,t.jsxs)("span",{className:"text-xs text-blue-500",children:[Math.round((J+1)/H.length*100),"% complete"]})]}),(0,t.jsx)("div",{className:"w-full bg-blue-200 rounded-full h-2",children:(0,t.jsx)("div",{className:"bg-blue-600 h-2 rounded-full transition-all duration-300",style:{width:`${(J+1)/H.length*100}%`}})})]}),(0,t.jsxs)("div",{children:[(0,t.jsx)("label",{className:"block text-sm font-medium text-neutral-700 mb-2",children:H[J]?.question}),H[J]?.hint&&(0,t.jsx)("p",{className:"text-xs text-neutral-500 mb-2",children:H[J]?.hint}),H[J]?.type==="textarea"?(0,t.jsx)(r.TextArea,{value:Z,onChange:e=>_(e.target.value),placeholder:"Type your answer here...",className:"w-full min-h-[120px]",name:"aiAnswer"}):(0,t.jsx)(o.Input,{value:Z,onChange:e=>_(e.target.value),placeholder:"Type your answer here...",className:"w-full",name:"aiAnswer",type:"text"})]}),(0,t.jsxs)("div",{className:"flex gap-3",children:[(0,t.jsx)(n.Button,{onClick:ef,className:"flex-1 bg-blue-600 hover:bg-blue-700 text-white",isDisabled:!Z.trim(),children:J<H.length-1?"Next Question":"Generate Description"}),(0,t.jsx)(n.Button,{onClick:()=>{G(!1),K({}),Y([]),V(0),_("")},variant:"light",className:"px-4",children:"Cancel"})]})]}):(0,t.jsxs)("div",{className:"text-center py-8",children:[(0,t.jsx)(u.SparklesIcon,{className:"w-16 h-16 text-blue-600 mx-auto mb-4"}),(0,t.jsx)("h3",{className:"text-lg font-semibold text-neutral-800 mb-2",children:"Let AI Help Create Your Description"}),(0,t.jsx)("p",{className:"text-sm text-neutral-600 mb-6",children:"We'll ask you 5 quick questions about your business to generate a compelling description."}),(0,t.jsx)(n.Button,{onClick:ey,className:"bg-blue-600 hover:bg-blue-700 text-white",isDisabled:X,children:X?"Loading...":"Start Questionnaire"})]})})})]})}],254167)},579269,66439,e=>{"use strict";let t=async e=>{var t,a;let r,{pageType:n,businessNiche:i,companyName:c,theme:d,templateHtml:u}=e;return u?{html:(t=u,a={primaryColor:d.primaryColor,fontFamily:d.fontFamily,companyName:c,businessNiche:i},(r=(r=(r=(r=t).replace(/--primary-color:\s*[^;]+/g,`--primary-color: ${a.primaryColor}`)).replace(/font-family:\s*[^;]+/g,`font-family: ${a.fontFamily}, sans-serif`)).replace(/\{\{companyName\}\}/g,a.companyName)).replace(/\{\{businessNiche\}\}/g,a.businessNiche)),css:o(d),metadata:{title:`${c} - ${l(n)}`,description:`Browse ${i} products at ${c}`}}:await s(e)},a=async e=>{let{wizardData:a}=e,s="single-page"===a.layout,n=s?["homepage"]:["homepage","products","product-detail","cart","checkout"];console.log("🚀 Starting complete site generation for:",a.companyName),console.log(`📋 Layout: ${a.layout}`),console.log(`📋 Will generate ${n.length} essential pages`);let i={},c=a.theme||{primaryColor:"#3B82F6",fontFamily:"Inter",designFeel:"modern"};console.log(`📄 Generating ${n.length} essential pages...`);let d=n.map(async e=>{try{let s=Date.now(),o=await t({pageType:e,businessNiche:a.ideaScope,companyName:a.companyName,description:a.description,theme:c,logoUrl:a.logoPreview||void 0,layout:a.layout}),r=((Date.now()-s)/1e3).toFixed(1);return console.log(`✅ Successfully generated ${e} in ${r}s`),{pageType:e,page:o}}catch(t){return console.error(`❌ Error generating ${e}:`,t),{pageType:e,page:{html:r({pageType:e,businessNiche:a.ideaScope,companyName:a.companyName,description:a.description,theme:c}),css:o(c),metadata:{title:`${a.companyName} - ${l(e)}`,description:a.description}}}}});if((await Promise.all(d)).forEach(e=>{i[e.pageType]=e.page}),!s)for(let e of s?[]:["categories","account","search","testimonial"])console.log(`📄 Creating basic template for optional page: ${e}`),i[e]={html:r({pageType:e,businessNiche:a.ideaScope,companyName:a.companyName,description:a.description,theme:c}),css:o(c),metadata:{title:`${a.companyName} - ${l(e)}`,description:a.description}};return console.log("🎉 Complete site generation finished. Generated pages:",Object.keys(i).length),i};async function s(e){try{console.log("🔄 Generating page with AI:",e.pageType);let t=new AbortController,a=setTimeout(()=>{console.warn("⏱️ Request timeout for:",e.pageType),t.abort()},18e4);try{let s=await fetch("/api/ai/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({pageType:e.pageType,businessNiche:e.businessNiche,companyName:e.companyName,description:e.description,theme:e.theme,logoUrl:e.logoUrl,layout:e.layout}),signal:t.signal});if(clearTimeout(a),console.log("📡 API response status:",s.status,s.statusText),!s.ok){let e;try{e=await s.json()}catch{e={message:`HTTP ${s.status}: ${s.statusText}`}}throw console.error("❌ API error:",e),Error(e.message||e.error||`API error: ${s.status}`)}let o=await s.json();if(console.log("✅ API response received:",{success:o.success,hasPage:!!o.page}),!o.success||!o.page)throw console.error("❌ Invalid response structure:",o),Error("Invalid response from AI service");return o.page}catch(e){if(clearTimeout(a),"AbortError"===e.name)throw Error("Request timeout: AI generation took too long (2 minutes)");throw e}}catch(t){return console.error("❌ Error calling AI generation API:",t),console.error("Error details:",{message:t.message,stack:t.stack}),console.warn("⚠️ Falling back to basic template for:",e.pageType),{html:r(e),css:o(e.theme),metadata:{title:`${e.companyName} - ${l(e.pageType)}`,description:e.description}}}}function o(e){return`
    :root {
      --primary-color: ${e.primaryColor};
      --font-family: ${e.fontFamily}, sans-serif;
    }
    
    body {
      font-family: var(--font-family);
    }
    
    .primary-bg {
      background-color: var(--primary-color);
    }
    
    .primary-text {
      color: var(--primary-color);
    }
    
    /* Add more theme-based styles */
  `}function r(e){let{pageType:t,companyName:a,businessNiche:s,theme:o,description:r}=e,n=new Date().getFullYear(),i=`
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${a} - ${l(t)}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=${o.fontFamily.replace(" ","+")}:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
      body { font-family: '${o.fontFamily}', sans-serif; }
      .primary-bg { background-color: ${o.primaryColor}; }
      .primary-text { color: ${o.primaryColor}; }
      .primary-border { border-color: ${o.primaryColor}; }
    </style>
  `,c=`
    <header class="bg-white shadow-sm sticky top-0 z-50">
      <nav class="container mx-auto px-4 py-4 flex items-center justify-between">
        <a href="/" class="text-2xl font-bold primary-text">${a}</a>
        {{menu}}
      </nav>
    </header>
  `,d=`
    <footer class="bg-gray-900 text-white py-12">
      <div class="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <h3 class="text-xl font-bold mb-4">${a}</h3>
          <p class="text-gray-400">${r||"Your trusted "+s+" store."}</p>
        </div>
        <div>
          <h4 class="font-semibold mb-4">Quick Links</h4>
          {{footerLinks}}
        </div>
        <div>
          <h4 class="font-semibold mb-4">Contact</h4>
          <p class="text-gray-400">Email: info@{{companyName}}.com</p>
        </div>
        <div>
          <h4 class="font-semibold mb-4">Follow Us</h4>
          <div class="flex gap-4">
            <a href="#" class="text-gray-400 hover:text-white">Twitter</a>
            <a href="#" class="text-gray-400 hover:text-white">Facebook</a>
          </div>
        </div>
      </div>
      <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
        &copy; ${n} ${a}. All rights reserved.
      </div>
    </footer>
  `,u=`
    <script>
      // Dynamic Data Fetching Script
      (function() {
        const API_BASE = '/api';
        const storefrontId = window.location.hostname.split('.')[0]; // Extract subdomain

        async function fetchProducts() {
          try {
            const container = document.getElementById('products-container');
            if (!container) return;
            const res = await fetch(API_BASE + '/storefront/' + storefrontId + '/products');
            if (!res.ok) return;
            const data = await res.json();
            // Render logic can be added here or rely on server-side injection
            console.log('Products fetched:', data);
          } catch (e) { console.error('Failed to fetch products', e); }
        }

        async function fetchCategories() {
          try {
            const container = document.getElementById('categories-container');
            if (!container) return;
            const res = await fetch(API_BASE + '/storefront/' + storefrontId + '/categories');
            if (!res.ok) return;
            const data = await res.json();
            console.log('Categories fetched:', data);
          } catch (e) { console.error('Failed to fetch categories', e); }
        }

        document.addEventListener('DOMContentLoaded', function() {
          fetchProducts();
          fetchCategories();
        });
      })();
    </script>
  `,m="";switch(t){case"homepage":m=`
        <!-- Hero Section -->
        <section class="relative bg-gradient-to-r from-gray-900 to-gray-700 text-white py-24">
          <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-6xl font-bold mb-6">Welcome to ${a}</h1>
            <p class="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">${r||"Discover exceptional "+s+" products curated just for you."}</p>
            <a href="/products" class="inline-block primary-bg text-white px-8 py-4 rounded-lg font-semibold hover:opacity-90 transition-opacity">Shop Now</a>
          </div>
        </section>
        
        <!-- Featured Products -->
        <section class="py-16 bg-gray-50">
          <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-10">Featured Products</h2>
            <div id="products-container">{{featuredProducts}}</div>
          </div>
        </section>

        <!-- About Us Section -->
        <section class="py-16 bg-white">
          <div class="container mx-auto px-4 max-w-3xl text-center">
            <h2 class="text-3xl font-bold mb-6">About Our Story</h2>
            <p class="text-lg text-gray-600 mb-8">${r||"We are dedicated to providing the best products in the "+s+" industry."}</p>
          </div>
        </section>

        <!-- Contact Us Section -->
        <section class="py-16 bg-gray-50">
          <div class="container mx-auto px-4 max-w-2xl">
            <h2 class="text-3xl font-bold text-center mb-10">Get In Touch</h2>
            <form class="space-y-4 bg-white p-8 rounded-xl shadow-sm">
              <div><input type="text" placeholder="Name" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></div>
              <div><input type="email" placeholder="Email" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></div>
              <div><textarea placeholder="Message" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea></div>
              <button type="button" class="w-full primary-bg text-white py-3 rounded-lg font-semibold hover:opacity-90">Send Message</button>
            </form>
          </div>
        </section>
        <!-- Categories -->
        <section class="py-16">
          <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-10">Shop by Category</h2>
            <div id="categories-container">{{categories}}</div>
          </div>
        </section>
      `;break;case"products":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Our Products</h1>
            <div id="products-container">{{products}}</div>
          </div>
        </section>
      `;break;case"product-detail":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-2 gap-12">
              <div class="aspect-square bg-gray-100 rounded-2xl flex items-center justify-center">
                <img src="{{product.image}}" alt="{{product.name}}" class="max-h-full object-contain"/>
              </div>
              <div>
                <h1 class="text-3xl font-bold mb-4">{{product.name}}</h1>
                <p class="text-2xl primary-text font-semibold mb-6">{{product.price}}</p>
                <p class="text-gray-600 mb-8">{{product.description}}</p>
                <button class="primary-bg text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 w-full md:w-auto">Add to Cart</button>
              </div>
            </div>
          </div>
        </section>
      `;break;case"categories":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Shop by Category</h1>
            <div id="categories-container">{{categories}}</div>
          </div>
        </section>
      `;break;case"cart":m=`
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Your Cart</h1>
            <div id="cart-items" class="bg-white rounded-xl shadow p-6">
              <p class="text-gray-500 text-center py-12">Your cart is empty.</p>
            </div>
            <div class="mt-8 flex justify-end">
              <a href="/checkout" class="primary-bg text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90">Proceed to Checkout</a>
            </div>
          </div>
        </section>
      `;break;case"checkout":m=`
        <section class="py-12">
          <div class="container mx-auto px-4 max-w-2xl">
            <h1 class="text-3xl font-bold mb-8 text-center">Checkout</h1>
            <form class="space-y-6 bg-white p-8 rounded-xl shadow">
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label><input type="text" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Address</label><textarea class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></textarea></div>
              <button type="submit" class="w-full primary-bg text-white py-3 rounded-lg font-semibold hover:opacity-90">Place Order</button>
            </form>
          </div>
        </section>
      `;break;case"about":m=`
        <section class="py-16">
          <div class="container mx-auto px-4 max-w-3xl text-center">
            <h1 class="text-4xl font-bold mb-6">About ${a}</h1>
            <p class="text-xl text-gray-600 mb-8">${r||"We are passionate about bringing you the best "+s+" products."}</p>
            <div class="grid md:grid-cols-3 gap-8 mt-12">
              <div class="p-6 bg-gray-50 rounded-xl"><h3 class="font-bold text-lg mb-2">Our Mission</h3><p class="text-gray-600">To deliver quality and value to our customers.</p></div>
              <div class="p-6 bg-gray-50 rounded-xl"><h3 class="font-bold text-lg mb-2">Our Vision</h3><p class="text-gray-600">To be a leader in the ${s} industry.</p></div>
              <div class="p-6 bg-gray-50 rounded-xl"><h3 class="font-bold text-lg mb-2">Our Values</h3><p class="text-gray-600">Integrity, Quality, Customer Focus.</p></div>
            </div>
          </div>
        </section>
      `;break;case"contact":m=`
        <section class="py-16">
          <div class="container mx-auto px-4 max-w-2xl">
            <h1 class="text-4xl font-bold mb-6 text-center">Contact Us</h1>
            <p class="text-center text-gray-600 mb-10">Have questions? We'd love to hear from you.</p>
            <form class="space-y-6 bg-white p-8 rounded-xl shadow">
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Name</label><input type="text" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Message</label><textarea rows="5" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></textarea></div>
              <button type="submit" class="w-full primary-bg text-white py-3 rounded-lg font-semibold hover:opacity-90">Send Message</button>
            </form>
          </div>
        </section>
      `;break;case"testimonial":m=`
        <section class="py-16 bg-gray-50">
          <div class="container mx-auto px-4">
            <h1 class="text-4xl font-bold mb-10 text-center">What Our Customers Say</h1>
            <div class="grid md:grid-cols-3 gap-8">{{testimonials}}</div>
          </div>
        </section>
      `;break;case"account":m=`
        <section class="py-12">
          <div class="container mx-auto px-4 max-w-4xl">
            <h1 class="text-3xl font-bold mb-8">My Account</h1>
            <div class="grid md:grid-cols-3 gap-6">
              <a href="/account/orders" class="p-6 bg-white rounded-xl shadow hover:shadow-lg transition-shadow"><h3 class="font-bold">Order History</h3><p class="text-gray-500 text-sm">View past orders</p></a>
              <a href="/account/settings" class="p-6 bg-white rounded-xl shadow hover:shadow-lg transition-shadow"><h3 class="font-bold">Account Settings</h3><p class="text-gray-500 text-sm">Manage your profile</p></a>
              <a href="/account/addresses" class="p-6 bg-white rounded-xl shadow hover:shadow-lg transition-shadow"><h3 class="font-bold">Addresses</h3><p class="text-gray-500 text-sm">Manage your addresses</p></a>
            </div>
          </div>
        </section>
      `;break;case"search":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Search Results</h1>
            <div class="mb-8"><input type="text" placeholder="Search products..." class="w-full md:w-1/2 border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
            <div id="products-container">{{products}}</div>
          </div>
        </section>
      `;break;default:m=`
        <section class="py-16">
          <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl font-bold mb-6">${l(t)}</h1>
            <p class="text-gray-600">Welcome to ${a}.</p>
          </div>
        </section>
      `}return`
    <!DOCTYPE html>
    <html lang="en">
    <head>${i}</head>
    <body class="bg-gray-50 text-gray-900 min-h-screen flex flex-col">
      ${c}
      <main class="flex-grow">${m}</main>
      ${d}
      ${u}
    </body>
    </html>
  `}function l(e){return({homepage:"Home",categories:"Categories",products:"Products","product-detail":"Product Details",cart:"Shopping Cart",checkout:"Checkout",account:"My Account",search:"Search Results",about:"About Us",contact:"Contact Us",testimonial:"Testimonials"})[e]||"Page"}async function n(e){try{let t=await fetch(`/api/user/plan?userId=${encodeURIComponent(e)}`);if(!t.ok)throw Error(`Failed to get user plan: ${t.statusText}`);return(await t.json()).data||null}catch(e){return console.error("Error getting user plan:",e),null}}async function i(e){try{let t=await n(e);if(!t)return{allowed:!1,current:0,max:0,message:"User plan not found"};let a=t.currentUsage.storefronts,s=t.limits.maxStorefronts;if(a>=s)return{allowed:!1,current:a,max:s,message:`You have reached your plan limit of ${s} storefront${s>1?"s":""}. Please upgrade your plan to create more storefronts.`};return{allowed:!0,current:a,max:s}}catch(e){return console.error("Error checking storefront limit:",e),{allowed:!1,current:0,max:0,message:"Error checking limits"}}}async function c(e){try{let t=await fetch("/api/user/plan",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:e,action:"incrementStorefront"})});if(!t.ok){let e=await t.json();throw Error(e.error||"Failed to increment storefront count")}}catch(e){throw console.error("Error incrementing storefront count:",e),e}}async function d(e,t){try{let a=await fetch("/api/user/plan",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:e,action:"incrementPage",storefrontId:t})});if(!a.ok){let e=await a.json();throw Error(e.error||"Failed to increment page count")}}catch(e){throw console.error("Error incrementing page count:",e),e}}e.s(["generateCompleteSite",0,a],579269),e.i(436180),e.i(317875),e.i(956003),e.s(["canCreateStorefront",()=>i,"getUserPlan",()=>n,"incrementPageCount",()=>d,"incrementStorefrontCount",()=>c],66439)},163341,e=>{"use strict";var t=e.i(271645);let a=t.forwardRef(function({title:e,titleId:a,...s},o){return t.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:o,"aria-labelledby":a},s),e?t.createElement("title",{id:a},e):null,t.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z"}))});e.s(["ChartBarIcon",0,a],163341)}]);