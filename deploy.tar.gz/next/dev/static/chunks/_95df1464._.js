(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/firebaseConfig.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "app",
    ()=>app,
    "auth",
    ()=>auth,
    "checkFirebaseConnection",
    ()=>checkFirebaseConnection,
    "db",
    ()=>db,
    "ensureFirebaseOnline",
    ()=>ensureFirebaseOnline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/app/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/app/dist/esm/index.esm2017.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm2017.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm2017$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/esm2017/index.js [app-client] (ecmascript)");
;
;
;
const firebaseConfig = {
    apiKey: ("TURBOPACK compile-time value", "AIzaSyDp_EH2NNsSWJ-o_wUT2wzFOiLQUQ8Mewk") || "",
    authDomain: ("TURBOPACK compile-time value", "storefront-64d56.firebaseapp.com") || "storefront-64d56.firebaseapp.com",
    projectId: ("TURBOPACK compile-time value", "storefront-64d56") || "storefront-64d56",
    storageBucket: ("TURBOPACK compile-time value", "storefront-64d56.firebasestorage.app") || "storefront-64d56.firebasestorage.app",
    messagingSenderId: ("TURBOPACK compile-time value", "695330621735") || "695330621735",
    appId: ("TURBOPACK compile-time value", "1:695330621735:web:6dbc73154a74c7ae1c8102") || "1:695330621735:web:6dbc73154a74c7ae1c8102",
    measurementId: ("TURBOPACK compile-time value", "G-Z851FP9YGC") || "G-Z851FP9YGC"
};
// Validate that required config is present
if (!firebaseConfig.apiKey) {
    if ("TURBOPACK compile-time truthy", 1) {
        console.warn("Firebase API key is missing. Please set NEXT_PUBLIC_FIREBASE_API_KEY in your .env.local file");
    }
}
// Initialize Firebase only if API key is present, otherwise use a placeholder config for build
let app;
let db;
let auth;
try {
    if (firebaseConfig.apiKey) {
        app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initializeApp"])(firebaseConfig);
        db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirestore"])(app);
        auth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm2017$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuth"])(app);
    } else {
        // Use placeholder config for build time when API key is missing
        const placeholderConfig = {
            apiKey: "placeholder-key-for-build",
            authDomain: firebaseConfig.authDomain,
            projectId: firebaseConfig.projectId,
            storageBucket: firebaseConfig.storageBucket,
            messagingSenderId: firebaseConfig.messagingSenderId,
            appId: firebaseConfig.appId,
            measurementId: firebaseConfig.measurementId
        };
        app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initializeApp"])(placeholderConfig, 'placeholder');
        db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirestore"])(app);
        auth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm2017$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuth"])(app);
    }
} catch (error) {
    // During build, if Firebase initialization fails, try with placeholder
    // This allows the build to complete even without valid Firebase config
    if (("TURBOPACK compile-time value", "development") === 'production' || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PHASE === 'phase-production-build') {
        console.warn("Firebase initialization failed during build. Using placeholder config.");
        const placeholderConfig = {
            apiKey: "placeholder-key-for-build",
            authDomain: firebaseConfig.authDomain,
            projectId: firebaseConfig.projectId,
            storageBucket: firebaseConfig.storageBucket,
            messagingSenderId: firebaseConfig.messagingSenderId,
            appId: firebaseConfig.appId,
            measurementId: firebaseConfig.measurementId
        };
        try {
            app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["initializeApp"])(placeholderConfig, 'placeholder');
            db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirestore"])(app);
            auth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$esm2017$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getAuth"])(app);
        } catch (placeholderError) {
            // If even placeholder fails, we need to provide defaults
            // This should rarely happen, but ensures build doesn't fail
            throw new Error("Firebase initialization failed. Please check your Firebase configuration.");
        }
    } else {
        throw error;
    }
}
;
const ensureFirebaseOnline = async ()=>{
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["enableNetwork"])(db);
        return true;
    } catch (error) {
        // Silently fail - network might already be enabled or unavailable
        return false;
    }
};
const checkFirebaseConnection = async ()=>{
    try {
        // Try a simple read operation to check connectivity
        const { doc, getDoc } = await __turbopack_context__.A("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript, async loader)");
        const testRef = doc(db, "_test", "connection");
        await Promise.race([
            getDoc(testRef),
            new Promise((_, reject)=>setTimeout(()=>reject(new Error('timeout')), 5000))
        ]);
        return true;
    } catch (error) {
        // If it's a timeout or unavailable error, Firebase is likely offline
        if (error.message === 'timeout' || error.code === 'unavailable') {
            return false;
        }
        // Other errors (like permission-denied) mean Firebase is online but we don't have access
        return true;
    }
};
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/services/firebase.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearWizardLocally",
    ()=>clearWizardLocally,
    "hasLocalWizardData",
    ()=>hasLocalWizardData,
    "loadAllUserSites",
    ()=>loadAllUserSites,
    "loadGeneratedSiteFromFirebase",
    ()=>loadGeneratedSiteFromFirebase,
    "loadWizardFromFirebase",
    ()=>loadWizardFromFirebase,
    "loadWizardLocally",
    ()=>loadWizardLocally,
    "sanitizeData",
    ()=>sanitizeData,
    "saveGeneratedSiteToFirebase",
    ()=>saveGeneratedSiteToFirebase,
    "saveWizardLocally",
    ()=>saveWizardLocally,
    "saveWizardToFirebase",
    ()=>saveWizardToFirebase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm2017.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/firebaseConfig.ts [app-client] (ecmascript)");
;
;
const sanitizeData = (data)=>{
    if (data === null || typeof data !== 'object') {
        return data;
    }
    if (Array.isArray(data)) {
        return data.map(sanitizeData);
    }
    const sanitized = {};
    Object.keys(data).forEach((key)=>{
        const value = data[key];
        if (value !== undefined) {
            sanitized[key] = sanitizeData(value);
        }
    });
    return sanitized;
};
const COLLECTION_NAME = "storefront_wizards";
/**
 * Helper to extract a string userId from various user object formats
 */ const extractUserId = (user)=>{
    if (!user) return null;
    const id = user.uid || user.id || user.user_id;
    return id ? String(id) : null;
};
const saveWizardToFirebase = async (data, user)=>{
    try {
        const userId = extractUserId(user);
        // Validate userId - Firebase doc() requires a non-empty string
        if (!userId) {
            console.warn("Invalid userId, falling back to localStorage");
            throw new Error("Invalid user ID - cannot save to Firebase");
        }
        const userEmail = user.email || user.email;
        const wizardData = {
            ...data,
            userId,
            userEmail,
            updatedAt: new Date()
        };
        // Check if wizard already exists for this user
        const wizardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, userId);
        const wizardDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(wizardRef);
        if (wizardDoc.exists()) {
            // Update existing wizard
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateDoc"])(wizardRef, sanitizeData(wizardData));
        } else {
            // Create new wizard
            wizardData.createdAt = new Date();
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setDoc"])(wizardRef, sanitizeData(wizardData));
        }
    } catch (error) {
        console.error("Error saving wizard to Firebase:", error);
        throw error;
    }
};
const loadWizardFromFirebase = async (user)=>{
    const userId = extractUserId(user);
    if (!userId) return null;
    try {
        const wizardRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, userId);
        const wizardDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(wizardRef);
        if (wizardDoc.exists()) {
            return wizardDoc.data();
        }
        return null;
    } catch (error) {
        console.error("Error loading wizard from Firebase:", error);
        return null;
    }
};
const saveWizardLocally = (data)=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        localStorage.setItem("wizard_data_local", JSON.stringify(data));
        localStorage.setItem("wizard_data_timestamp", new Date().toISOString());
    } catch (error) {
        console.error("Error saving wizard locally:", error);
    }
};
const loadWizardLocally = ()=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    try {
        const data = localStorage.getItem("wizard_data_local");
        if (data) {
            return JSON.parse(data);
        }
    } catch (error) {
        console.error("Error loading wizard locally:", error);
    }
    return null;
};
const clearWizardLocally = ()=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    localStorage.removeItem("wizard_data_local");
    localStorage.removeItem("wizard_data_timestamp");
};
const hasLocalWizardData = ()=>{
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    return !!localStorage.getItem("wizard_data_local");
};
const saveGeneratedSiteToFirebase = async (site, user)=>{
    try {
        // Handle different user object types
        const userId = extractUserId(user);
        if (!userId) {
            console.error("Firebase Service: User ID missing", {
                user
            });
            throw new Error("User ID is missing from user object");
        }
        if (!site.subdomain) {
            console.error("Firebase Service: Subdomain missing from site data");
            throw new Error("Subdomain is required to save site");
        }
        console.log(`Firebase Service: Saving site for userId: ${userId}, subdomain: ${site.subdomain}`);
        const siteData = {
            ...site,
            userId: userId,
            updatedAt: new Date()
        };
        // Save to multi-site collection using subdomain as doc ID
        const multiSiteRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], "user_storefronts", site.subdomain);
        const multiSiteDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(multiSiteRef);
        if (multiSiteDoc.exists()) {
            console.log("Firebase Service: Updating existing site in multi-site collection");
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateDoc"])(multiSiteRef, sanitizeData(siteData));
        } else {
            console.log("Firebase Service: Creating new site in multi-site collection");
            siteData.generatedAt = new Date();
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setDoc"])(multiSiteRef, sanitizeData(siteData));
        }
        // Also save to legacy collection (backward compatibility - first site only)
        const legacySiteRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], "storefront_sites", userId);
        const legacySiteDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(legacySiteRef);
        if (!legacySiteDoc.exists()) {
            // Only save to legacy if no site exists there yet
            console.log("Firebase Service: Also saving to legacy collection for backward compat");
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setDoc"])(legacySiteRef, sanitizeData(siteData));
        }
        console.log("Firebase Service: Site saved successfully");
    } catch (error) {
        console.error("Firebase Service: Error saving generated site to Firebase:", error);
        if (error.code === 'permission-denied') {
            throw new Error("Permission denied. Please checking your login status.");
        }
        throw error;
    }
};
const loadGeneratedSiteFromFirebase = async (user, retries = 3)=>{
    const userId = extractUserId(user);
    if (!userId) {
        console.error("User ID is missing from user object", {
            user
        });
        return null;
    }
    try {
        // 1. First attempt: Load from multi-site collection by querying for this userId
        console.log("🔍 Loading site for userId:", userId);
        const sitesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], "user_storefronts");
        const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["query"])(sitesRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("userId", "==", userId));
        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
        if (!querySnapshot.empty) {
            // Sort by updatedAt descending and pick the latest one
            const sites = querySnapshot.docs.map((doc)=>doc.data());
            sites.sort((a, b)=>{
                const dateA = a.updatedAt instanceof Date ? a.updatedAt.getTime() : a.updatedAt?.seconds ? a.updatedAt.seconds * 1000 : 0;
                const dateB = b.updatedAt instanceof Date ? b.updatedAt.getTime() : b.updatedAt?.seconds ? b.updatedAt.seconds * 1000 : 0;
                return dateB - dateA;
            });
            console.log("✅ Found site in user_storefronts:", sites[0].subdomain);
            return sites[0];
        }
        // 2. Second attempt: Check legacy collection (for earlier users)
        const legacyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], "storefront_sites", userId);
        const legacyDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(legacyRef);
        if (legacyDoc.exists()) {
            console.log("✅ Found site in legacy collection");
            return legacyDoc.data();
        }
        console.log("❌ No site found for user");
        return null;
    } catch (error) {
        console.error("Firebase Service: Error loading generated site:", error);
        // Log permission errors specifically for debugging
        if (error.code === 'permission-denied') {
            console.error("🔒 Firestore Permission Denied:", {
                collection: "user_storefronts",
                userId,
                errorCode: error.code,
                errorMessage: error.message
            });
        }
        // Progressive backoff for retries
        if (retries > 0) {
            console.log(`🔄 Retrying load (${retries} attempts left)...`);
            await new Promise((resolve)=>setTimeout(resolve, 1000 * (4 - retries)));
            return loadGeneratedSiteFromFirebase(user, retries - 1);
        }
        return null;
    }
};
const loadAllUserSites = async (user)=>{
    const userId = extractUserId(user);
    if (!userId) {
        console.error("User ID is missing from user object");
        return [];
    }
    try {
        const sites = [];
        // 1. Check the multi-site collection
        try {
            const sitesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], 'user_storefronts');
            const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["query"])(sitesRef, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])('userId', '==', userId));
            const snapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
            snapshot.docs.forEach((doc)=>{
                sites.push(doc.data());
            });
        } catch (multiSiteError) {
            console.warn('Error loading from user_storefronts:', multiSiteError);
        }
        // 2. Check the legacy collection
        try {
            const legacyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], 'storefront_sites', userId);
            const legacyDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(legacyRef);
            if (legacyDoc.exists()) {
                const legacyData = legacyDoc.data();
                // Avoid duplicates if already found in multi-site
                if (!sites.find((s)=>s.subdomain === legacyData.subdomain)) {
                    sites.push(legacyData);
                }
            }
        } catch (legacyError) {
            console.warn('Error loading from legacy storefront_sites:', legacyError);
        }
        // Sort by updatedAt descending
        sites.sort((a, b)=>{
            const dateA = a.updatedAt instanceof Date ? a.updatedAt.getTime() : a.updatedAt?.seconds ? a.updatedAt.seconds * 1000 : 0;
            const dateB = b.updatedAt instanceof Date ? b.updatedAt.getTime() : b.updatedAt?.seconds ? b.updatedAt.seconds * 1000 : 0;
            return dateB - dateA;
        });
        return sites;
    } catch (error) {
        console.error("Error loading user sites:", error);
        return [];
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useToast.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useToast",
    ()=>useToast
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$chunk$2d$ZPZBECKL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@heroui/toast/dist/chunk-ZPZBECKL.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/button/dist/chunk-WBUKVQRU.mjs [app-client] (ecmascript) <export button_default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
const useToast = ()=>{
    _s();
    const showToast = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useToast.useCallback[showToast]": (message, color = 'primary', description)=>{
            // Define color-specific classes
            const colorClasses = {
                success: {
                    base: "border-green-200 bg-green-50/90",
                    title: "text-green-900",
                    description: "text-green-700"
                },
                danger: {
                    base: "border-red-200 bg-red-50/90",
                    title: "text-red-900",
                    description: "text-red-700"
                },
                warning: {
                    base: "border-amber-200 bg-amber-50/90",
                    title: "text-amber-900",
                    description: "text-amber-700"
                },
                primary: {
                    base: "border-blue-200 bg-blue-50/90",
                    title: "text-blue-900",
                    description: "text-blue-700"
                }
            };
            const selectedColors = colorClasses[color];
            let toastId;
            // Create toast options with 5-second auto-dismiss
            const toastOptions = {
                title: message,
                description,
                color,
                variant: "flat",
                timeout: 5000,
                radius: "lg",
                endContent: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                    isIconOnly: true,
                    size: "sm",
                    variant: "light",
                    onPress: {
                        "useToast.useCallback[showToast]": ()=>{
                            if (toastId !== null) (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$chunk$2d$ZPZBECKL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["closeToast"])(String(toastId));
                        }
                    }["useToast.useCallback[showToast]"],
                    className: "min-w-8 w-8 h-8 rounded-full hover:bg-black/5",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
                        className: "w-4 h-4 text-neutral-500"
                    }, void 0, false, {
                        fileName: "[project]/hooks/useToast.tsx",
                        lineNumber: 54,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/hooks/useToast.tsx",
                    lineNumber: 45,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)),
                classNames: {
                    base: `max-w-sm w-full shadow-lg backdrop-blur-sm ${selectedColors.base} pr-2`,
                    title: `text-sm font-semibold ${selectedColors.title}`,
                    description: `text-xs ${selectedColors.description}`,
                    wrapper: "px-3 py-2"
                }
            };
            toastId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$toast$2f$dist$2f$chunk$2d$ZPZBECKL$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addToast"])(toastOptions);
        }
    }["useToast.useCallback[showToast]"], []);
    const showSuccess = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useToast.useCallback[showSuccess]": (message, description)=>{
            showToast(message, 'success', description);
        }
    }["useToast.useCallback[showSuccess]"], [
        showToast
    ]);
    const showError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useToast.useCallback[showError]": (message, description)=>{
            showToast(message, 'danger', description);
        }
    }["useToast.useCallback[showError]"], [
        showToast
    ]);
    const showWarning = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useToast.useCallback[showWarning]": (message, description)=>{
            showToast(message, 'warning', description);
        }
    }["useToast.useCallback[showWarning]"], [
        showToast
    ]);
    const showInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useToast.useCallback[showInfo]": (message, description)=>{
            showToast(message, 'primary', description);
        }
    }["useToast.useCallback[showInfo]"], [
        showToast
    ]);
    return {
        showToast,
        showSuccess,
        showError,
        showWarning,
        showInfo
    };
};
_s(useToast, "DExUlUdp6xmWfoi5ubZCt6DcxYg=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/classname.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cn",
    ()=>cn
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/tailwind-merge/dist/bundle-mjs.mjs [app-client] (ecmascript)");
;
;
function cn(...inputs) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$tailwind$2d$merge$2f$dist$2f$bundle$2d$mjs$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["twMerge"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsx"])(inputs));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/formatCurrency.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatCurrency",
    ()=>formatCurrency
]);
const formatCurrency = (amount, currency = "GBP")=>{
    const locale = typeof navigator !== "undefined" ? navigator.language : "en-NG";
    const effectiveLocale = currency === "NGN" ? "en-NG" : locale;
    return new Intl.NumberFormat(effectiveLocale, {
        style: "currency",
        currency
    }).format(amount);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/constants/seo.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "APP_AUTHORS",
    ()=>APP_AUTHORS,
    "APP_KEYWORDS",
    ()=>APP_KEYWORDS,
    "APP_OPEN_GRAPH",
    ()=>APP_OPEN_GRAPH,
    "APP_ROBOTS",
    ()=>APP_ROBOTS,
    "APP_THEME_COLOR",
    ()=>APP_THEME_COLOR,
    "APP_TWITTER",
    ()=>APP_TWITTER,
    "SEO_DESCRIPTION",
    ()=>SEO_DESCRIPTION,
    "SEO_TITLE",
    ()=>SEO_TITLE,
    "SITE_URL",
    ()=>SITE_URL
]);
const SITE_URL = 'https://dfoldlab.co.uk';
const SEO_TITLE = 'StoreFront — Build Your Dream Online Store';
const SEO_DESCRIPTION = 'StoreFront is the ultimate platform for creating stunning, professional online stores in minutes. Launch your business with powerful tools, custom themes, and AI-driven design recommendations.';
const APP_KEYWORDS = [
    'StoreFront',
    'ecommerce builder',
    'online store',
    'website builder',
    'sell online',
    'shop builder',
    'business',
    'ecommerce platform',
    'startup',
    'entrepreneur'
];
const APP_AUTHORS = [
    {
        name: 'StoreFront'
    }
];
const APP_OPEN_GRAPH = {
    title: 'StoreFront — Build Your Dream Online Store',
    description: 'StoreFront is the ultimate platform for creating stunning, professional online stores in minutes. Launch your business with powerful tools, custom themes, and AI-driven design recommendations.',
    url: SITE_URL,
    siteName: 'StoreFront',
    locale: 'en_US',
    type: 'website'
};
const APP_TWITTER = {
    card: 'summary_large_image',
    title: 'StoreFront — Build Your Dream Online Store',
    description: 'Create stunning, professional online stores in minutes with StoreFront. Launch your business with powerful tools and AI-driven design.'
};
const APP_ROBOTS = {
    index: true,
    follow: true
};
const APP_THEME_COLOR = [
    {
        media: '(prefers-color-scheme: light)',
        color: '#ffffff'
    },
    {
        media: '(prefers-color-scheme: dark)',
        color: '#030712'
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/constants/logo.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LOGO",
    ()=>LOGO
]);
const LOGO = {
    black: '/img/logo/logo.svg',
    white: '/img/logo/logo.svg',
    mini: '/favicon.svg',
    alt: 'StoreFront'
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/constants/nav.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LOGOS",
    ()=>LOGOS,
    "NAV_BUTTONS",
    ()=>NAV_BUTTONS,
    "NAV_CONSTANT",
    ()=>NAV_CONSTANT,
    "NAV_ITEMS",
    ()=>NAV_ITEMS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/logo.ts [app-client] (ecmascript)");
;
const NAV_ITEMS = [
    {
        label: "Features",
        href: "#features"
    },
    {
        label: "How it works",
        href: "#how-it-works"
    },
    {
        label: "Pricing",
        href: "#pricing"
    }
];
const NAV_BUTTONS = [
    {
        label: "Log in",
        href: "/signin",
        variant: "link",
        showOnMobile: false
    },
    {
        label: "Get Started",
        href: "/signup",
        variant: "solid",
        radius: "full",
        showOnMobile: false
    }
];
const LOGOS = {
    light: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOGO"].white,
    dark: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["LOGO"].black
};
const NAV_CONSTANT = {
    NAV_ITEMS,
    NAV_BUTTONS,
    LOGOS
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/constants/api.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE_URL",
    ()=>API_BASE_URL,
    "ENDPOINT",
    ()=>ENDPOINT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
const DEFAULT_API_URL = "https://shorp-epos-backend.onrender.com/api/v1";
const API_BASE_URL = ("TURBOPACK compile-time value", "https://shorp-epos-backend.onrender.com/api/v1") || DEFAULT_API_URL;
const ENDPOINT = {
    AUTH: {
        ROLE_PERMISSIONS: '/role-permissions',
        LOGIN: '/auth/login',
        GOOGLE_SIGNIN: '/auth/google/signin',
        GOOGLE_SIGNUP: '/auth/google/signup',
        SIGNUP: '/auth/signup',
        LOGOUT: '/auth/signout',
        REQUEST_OTP: '/auth/reset',
        VERIFY_ACCOUNT: '/auth/verify-account',
        RESET_PASSWORD: '/auth/reset',
        VERIFY_OTP: '/auth/verify-account',
        REFRESH_TOKEN: '/auth/refresh-token',
        PERMISSIONS: '/roles/me/permission',
        ROLES: '/roles',
        ROLE_PERMISSION_DETAILS: '/roles'
    },
    ADDRESS: {
        AUTOCOMPLETE: '/autocomplete',
        GET: '/get'
    },
    STORES: {
        BASE: '/stores'
    },
    UPLOADS: {
        MULTIPLE: '/uploads/mulitple',
        DELETE: '/uploads/delete'
    },
    SUBSCRIPTION: {
        PLANS: '/subscription-plans'
    },
    VARIATIONS: '/variations',
    UNITS: '/units',
    CATEGORIES: '/categories',
    BRANDS: '/brands',
    SUPPLIERS: '/suppliers',
    PRODUCTS: '/products',
    SALES: '/sales',
    ADJUSTMENTS: '/adjustments',
    ANALYTICS: {
        TRENDS: (businessId)=>`/analytics/business/${businessId}/trends`,
        SUMMARY: (businessId)=>`/analytics/business/${businessId}/summary`
    },
    WHATSAPP: {
        BASE: '/whatsapp',
        OVERVIEW: (businessId)=>`/whatsapp/business/${businessId}/overview`,
        NUMBERS: {
            LIST: (businessId)=>`/whatsapp/business/${businessId}/numbers`,
            CONNECT: (businessId)=>`/whatsapp/business/${businessId}/numbers/connect`,
            UPDATE_TOKEN: (businessId, id)=>`/whatsapp/business/${businessId}/numbers/${id}/token`,
            DELETE: (businessId, id)=>`/whatsapp/business/${businessId}/numbers/${id}`
        },
        SETTINGS: {
            GET: (businessId)=>`/whatsapp/business/${businessId}/settings`,
            UPDATE: (businessId)=>`/whatsapp/business/${businessId}/settings`
        },
        SESSIONS: {
            LIST: (businessId)=>`/whatsapp/business/${businessId}/sessions`,
            GET: (sessionId)=>`/whatsapp/sessions/${sessionId}`,
            CART: (sessionId)=>`/whatsapp/sessions/${sessionId}/cart`
        },
        MARKETING: {
            SUBSCRIBERS: {
                LIST: (businessId)=>`/whatsapp/marketing/business/${businessId}/subscribers`,
                CREATE: (businessId)=>`/whatsapp/marketing/business/${businessId}/subscribers`,
                UPDATE: (businessId, phone)=>`/whatsapp/marketing/business/${businessId}/subscribers/${phone}`,
                DELETE: (businessId, phone)=>`/whatsapp/marketing/business/${businessId}/subscribers/${phone}`,
                IMPORT: (businessId)=>`/whatsapp/marketing/business/${businessId}/subscribers/import`
            },
            CAMPAIGNS: {
                LIST: (businessId)=>`/whatsapp/marketing/business/${businessId}/campaigns`,
                CREATE: (businessId)=>`/whatsapp/marketing/business/${businessId}/campaigns`,
                GET: (businessId, campaignId)=>`/whatsapp/marketing/business/${businessId}/campaigns/${campaignId}`,
                UPDATE: (businessId, campaignId)=>`/whatsapp/marketing/business/${businessId}/campaigns/${campaignId}`,
                RUN: (businessId, campaignId)=>`/whatsapp/marketing/business/${businessId}/campaigns/${campaignId}/run`
            }
        },
        SERVICE_TOKENS: {
            LIST: '/whatsapp/service-tokens',
            CREATE: '/whatsapp/service-tokens',
            SCOPES: '/whatsapp/service-tokens/scopes',
            REVOKE: (id)=>`/whatsapp/service-tokens/${id}/revoke`,
            DELETE: (id)=>`/whatsapp/service-tokens/${id}`
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/constants/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/seo.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/logo.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$nav$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/nav.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/api.ts [app-client] (ecmascript)");
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/apiClient.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "client",
    ()=>client,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/constants/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/api.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$cookies$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/cookies.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$types$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/types/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$types$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/types/auth.ts [app-client] (ecmascript)");
;
;
;
;
// Flag to prevent multiple simultaneous refresh attempts
let isRefreshing = false;
let failedQueue = [];
const baseURL = __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"];
const apiClient = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL,
    timeout: 30000,
    headers: {
        "Content-Type": "application/json"
    }
});
const client = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].create({
    baseURL,
    timeout: 30000,
    headers: {
        "Content-Type": "application/json"
    }
});
apiClient.interceptors.request.use((config)=>{
    // Try to get token from cookie first, then localStorage
    let token = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$cookies$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCookie"])(__TURBOPACK__imported__module__$5b$project$5d2f$types$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]);
    if (!token && ("TURBOPACK compile-time value", "object") !== "undefined") {
        token = localStorage.getItem("auth_token");
    }
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    // Log request in development
    if ("TURBOPACK compile-time truthy", 1) {
        console.log(`[API Request] ${config.method?.toUpperCase()} ${config.baseURL}${config.url}`);
    }
    return config;
}, (error)=>Promise.reject(error));
// Add request interceptor to client as well
client.interceptors.request.use((config)=>{
    // Try to get token from cookie first, then localStorage
    let token = (0, __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$cookies$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCookie"])(__TURBOPACK__imported__module__$5b$project$5d2f$types$2f$auth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AUTH_TOKEN_KEY"]);
    if (!token && ("TURBOPACK compile-time value", "object") !== "undefined") {
        token = localStorage.getItem("auth_token");
    }
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error)=>Promise.reject(error));
const responseInterceptor = async (error)=>{
    // Log error in development with more details
    if ("TURBOPACK compile-time truthy", 1) {
        const errorDetails = {
            status: error.response?.status,
            statusText: error.response?.statusText,
            url: error.config?.url ?? "unknown",
            baseURL: error.config?.baseURL ?? "unknown",
            message: error.message,
            code: error.code
        };
        // Add response data if available
        if (error.response?.data) {
            errorDetails.responseData = error.response.data;
        }
        console.error("[API Error]", errorDetails);
    }
    const originalRequest = error.config;
    if (error.response?.status === 401) {
        // Don't redirect if we're already on the signin page (prevents redirect loop)
        const currentPath = ("TURBOPACK compile-time truthy", 1) ? window.location.pathname : "TURBOPACK unreachable";
        if (currentPath === "/signin" || currentPath.startsWith("/signin")) {
            // Already on signin page, don't redirect - let the login form handle the error
            return Promise.reject(error);
        }
        // Don't redirect for login/signup/refresh endpoints - let them handle their own errors
        const requestUrl = originalRequest?.url || "";
        if (requestUrl.includes("/auth/login") || requestUrl.includes("/auth/signup") || requestUrl.includes("/auth/google") || requestUrl.includes("/auth/refresh-token")) {
            // Let the auth functions handle the error
            return Promise.reject(error);
        }
        // If this is a retry after refresh, or refresh is in progress, handle accordingly
        if (originalRequest?._retry) {
            // Already retried, refresh token must be invalid - logout
            const { logout } = await __turbopack_context__.A("[project]/utils/index.ts [app-client] (ecmascript, async loader)");
            await logout();
            const callbackUrl = currentPath || "/";
            if ("TURBOPACK compile-time truthy", 1) {
                window.location.href = `/signin?callbackUrl=${encodeURIComponent(callbackUrl)}`;
            }
            return Promise.reject(error);
        }
        // Try to refresh token
        if (isRefreshing) {
            // If refresh is already in progress, queue this request
            return new Promise((resolve, reject)=>{
                failedQueue.push({
                    resolve,
                    reject
                });
            }).then((token)=>{
                if (originalRequest) {
                    if (originalRequest.headers) {
                        originalRequest.headers.Authorization = `Bearer ${token}`;
                    }
                    return apiClient(originalRequest);
                }
            }).catch((err)=>{
                return Promise.reject(err);
            });
        }
        // Get refresh token from localStorage
        const refreshTokenValue = ("TURBOPACK compile-time truthy", 1) ? localStorage.getItem("refresh_token") : "TURBOPACK unreachable";
        if (!refreshTokenValue) {
            // No refresh token available, logout
            const { logout } = await __turbopack_context__.A("[project]/utils/index.ts [app-client] (ecmascript, async loader)");
            await logout();
            const callbackUrl = currentPath || "/";
            if ("TURBOPACK compile-time truthy", 1) {
                window.location.href = `/signin?callbackUrl=${encodeURIComponent(callbackUrl)}`;
            }
            return Promise.reject(error);
        }
        // Start refresh process
        isRefreshing = true;
        try {
            const { refreshToken: refreshTokenFn } = await __turbopack_context__.A("[project]/services/auth.ts [app-client] (ecmascript, async loader)");
            const refreshResponse = await refreshTokenFn({
                refreshToken: refreshTokenValue
            });
            // Extract new token - handle different response structures
            const newToken = refreshResponse.token || refreshResponse.data?.token || refreshResponse.data?.data?.token;
            if (!newToken) {
                throw new Error("No new token received");
            }
            // Process queued requests
            failedQueue.forEach(({ resolve })=>{
                resolve(newToken);
            });
            failedQueue = [];
            // Retry original request with new token
            if (originalRequest) {
                originalRequest._retry = true;
                if (originalRequest.headers) {
                    originalRequest.headers.Authorization = `Bearer ${newToken}`;
                }
                return apiClient(originalRequest);
            }
            return Promise.reject(error);
        } catch (refreshError) {
            // Refresh failed, clear auth and logout
            failedQueue.forEach(({ reject })=>{
                reject(refreshError);
            });
            failedQueue = [];
            const { logout } = await __turbopack_context__.A("[project]/utils/index.ts [app-client] (ecmascript, async loader)");
            await logout();
            const callbackUrl = ("TURBOPACK compile-time truthy", 1) ? window.location.pathname : "TURBOPACK unreachable";
            if ("TURBOPACK compile-time truthy", 1) {
                window.location.href = `/signin?callbackUrl=${encodeURIComponent(callbackUrl)}`;
            }
            return Promise.reject(refreshError);
        } finally{
            isRefreshing = false;
        }
    }
    // Handle 503 Service Unavailable
    if (error.response?.status === 503) {
        const customError = new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        customError.is503 = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Handle timeout errors
    if (error.code === 'ECONNABORTED' || error.message?.includes('timeout')) {
        const customError = new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        customError.isTimeout = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Handle network errors (connection refused, DNS errors, etc.)
    if (error.code === 'ECONNREFUSED' || error.code === 'ENOTFOUND' || error.code === 'ERR_NETWORK' || error.message?.includes('Network Error') || error.message?.includes('getaddrinfo ENOTFOUND') || error.message?.includes('connect ECONNREFUSED')) {
        const customError = new Error("Unable to connect to the server. Please check your internet connection and ensure the API server is running.");
        customError.isNetworkError = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Helper function to safely extract error message from response data
    const getErrorMessage = (data, defaultMessage)=>{
        if (data && typeof data === 'object') {
            const errorData = data;
            if (typeof errorData.message === 'string') {
                return errorData.message;
            }
            if (typeof errorData.error === 'string') {
                return errorData.error;
            }
        }
        return defaultMessage;
    };
    // Handle 500 Internal Server Error
    if (error.response?.status === 500) {
        const customError = new Error(getErrorMessage(error.response.data, "Internal server error. Please try again later or contact support if the problem persists."));
        customError.is500 = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Handle 404 Not Found
    if (error.response?.status === 404) {
        const customError = new Error(getErrorMessage(error.response.data, "The requested resource was not found."));
        customError.is404 = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Handle 400 Bad Request
    if (error.response?.status === 400) {
        const customError = new Error(getErrorMessage(error.response.data, "Invalid request. Please check your input and try again."));
        customError.is400 = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Handle 429 Too Many Requests (rate limiting)
    if (error.response?.status === 429) {
        const customError = new Error(getErrorMessage(error.response.data, "Too many requests. Please wait a moment and try again."));
        customError.is429 = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Handle 502 Bad Gateway
    if (error.response?.status === 502) {
        const customError = new Error("Bad gateway. The server received an invalid response. Please try again later.");
        customError.is502 = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // Handle 504 Gateway Timeout
    if (error.response?.status === 504) {
        const customError = new Error("Gateway timeout. The server took too long to respond. Please try again.");
        customError.is504 = true;
        customError.originalError = error;
        return Promise.reject(customError);
    }
    // For other errors, try to extract a meaningful message
    if (error.response?.data) {
        const errorMessage = getErrorMessage(error.response.data, error.message || "An unexpected error occurred. Please try again.");
        const customError = new Error(errorMessage);
        customError.originalError = error;
        customError.status = error.response.status;
        return Promise.reject(customError);
    }
    return Promise.reject(error);
};
apiClient.interceptors.response.use((response)=>response, responseInterceptor);
client.interceptors.response.use((response)=>response, responseInterceptor);
const __TURBOPACK__default__export__ = apiClient;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$formatCurrency$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/formatCurrency.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/apiClient.ts [app-client] (ecmascript)");
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/Label.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
;
;
const Label = ({ htmlFor, label, className })=>{
    const isReactNode = typeof label !== 'string';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        htmlFor: htmlFor,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-label", isReactNode && "flex items-center gap-1", className),
        children: label
    }, void 0, false, {
        fileName: "[project]/components/ui/form/Label.tsx",
        lineNumber: 14,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Label;
const __TURBOPACK__default__export__ = Label;
var _c;
__turbopack_context__.k.register(_c, "Label");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
;
;
const ErrorMessage = ({ error })=>{
    if (!error) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-error text-xs mt-1.5 tracking-wide"),
        children: error
    }, void 0, false, {
        fileName: "[project]/components/ui/form/ErrorMessage.tsx",
        lineNumber: 10,
        columnNumber: 12
    }, ("TURBOPACK compile-time value", void 0));
};
_c = ErrorMessage;
const __TURBOPACK__default__export__ = ErrorMessage;
var _c;
__turbopack_context__.k.register(_c, "ErrorMessage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "controlRadiusClasses",
    ()=>controlRadiusClasses,
    "radiusClasses",
    ()=>radiusClasses,
    "sizeClasses",
    ()=>sizeClasses
]);
const sizeClasses = {
    sm: "h-10",
    md: "h-11",
    lg: "h-12"
};
const radiusClasses = {
    none: "rounded-none",
    sm: "rounded-small",
    md: "rounded-medium",
    lg: "rounded-large",
    xl: "rounded-large",
    full: "rounded-full"
};
const controlRadiusClasses = {
    none: "rounded-none",
    sm: "rounded-sm",
    md: "rounded-sm",
    lg: "rounded-md",
    xl: "rounded-md",
    full: "rounded-full"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
const formatCurrency = (value)=>{
    const number = parseFloat(value.replace(/,/g, ""));
    if (isNaN(number)) return "";
    return number.toLocaleString();
};
const unformatCurrency = (value)=>{
    return value.replace(/,/g, "");
};
const Input = /*#__PURE__*/ _s((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = _s(({ label, name, className, formGroupClass, labelClassName, startContent, endContent, fullWidth, inputSize = "md", radius = "md", innerShadow = false, error, value, onChange, onBlur, isCurrency = false, type = "text", ...props }, ref)=>{
    _s();
    const [displayValue, setDisplayValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        "Input.useState": ()=>{
            if (isCurrency && value) {
                return formatCurrency(String(value));
            }
            return value ?? "";
        }
    }["Input.useState"]);
    const handleChange = (e)=>{
        let rawValue = e.target.value;
        if (isCurrency) {
            rawValue = unformatCurrency(rawValue);
            const formattedValue = formatCurrency(rawValue);
            const syntheticEvent = {
                ...e,
                target: {
                    ...e.target,
                    value: rawValue,
                    name: name
                }
            };
            onChange?.(syntheticEvent);
            setDisplayValue(formattedValue);
        } else {
            onChange?.(e);
        }
    };
    const inputValue = isCurrency ? displayValue : value;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-group", formGroupClass, fullWidth && "w-full"),
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                htmlFor: name,
                label: label,
                className: labelClassName
            }, void 0, false, {
                fileName: "[project]/components/ui/form/Input.tsx",
                lineNumber: 96,
                columnNumber: 23
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full",
                children: [
                    startContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 inset-y-0 flex items-center",
                        children: startContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Input.tsx",
                        lineNumber: 100,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ...props,
                        ref: ref,
                        type: type,
                        id: name,
                        name: name,
                        value: type !== "file" ? inputValue : undefined,
                        onChange: handleChange,
                        onBlur: onBlur,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-control", __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClasses"][inputSize], __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radiusClasses"][radius], startContent ? "pl-9" : "", endContent ? "pr-9" : "", error && "is-invalid", className)
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Input.tsx",
                        lineNumber: 105,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    endContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-3 inset-y-0 flex items-center",
                        children: endContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Input.tsx",
                        lineNumber: 126,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/form/Input.tsx",
                lineNumber: 98,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                error: error
            }, void 0, false, {
                fileName: "[project]/components/ui/form/Input.tsx",
                lineNumber: 131,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/form/Input.tsx",
        lineNumber: 94,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
}, "Y3BxxNIA0722ux4nQt2+MeneyOc=")), "Y3BxxNIA0722ux4nQt2+MeneyOc=");
_c1 = Input;
Input.displayName = "Input";
const __TURBOPACK__default__export__ = Input;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/PasswordInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$EyeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/EyeIcon.js [app-client] (ecmascript) <export default as EyeIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$EyeSlashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeSlashIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/EyeSlashIcon.js [app-client] (ecmascript) <export default as EyeSlashIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/constants.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
const PasswordInput = ({ label, name, className, formGroupClass, labelClassName, startContent, endContent, fullWidth, inputSize = "md", radius = "md", innerShadow = false, error, value, onChange, onBlur, ...props })=>{
    _s();
    const [showPassword, setShowPassword] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-group", formGroupClass, fullWidth && "w-full"),
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                htmlFor: name,
                label: label,
                className: labelClassName
            }, void 0, false, {
                fileName: "[project]/components/ui/form/PasswordInput.tsx",
                lineNumber: 51,
                columnNumber: 23
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full",
                children: [
                    startContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 inset-y-0 flex items-center",
                        children: startContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/PasswordInput.tsx",
                        lineNumber: 55,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ...props,
                        id: name,
                        name: name,
                        type: showPassword ? "text" : "password",
                        value: value,
                        onChange: onChange,
                        onBlur: onBlur,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-control", __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClasses"][inputSize], __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radiusClasses"][radius], startContent ? "pl-9" : "", endContent ? "pr-9" : "pr-11", error && "is-invalid", className)
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/PasswordInput.tsx",
                        lineNumber: 60,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        "aria-label": showPassword ? "Hide password" : "Show password",
                        onClick: ()=>setShowPassword(!showPassword),
                        className: "absolute right-3 inset-y-0 flex items-center cursor-pointer text-gray-600 dark:text-gray-300",
                        children: showPassword ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$EyeSlashIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeSlashIcon$3e$__["EyeSlashIcon"], {
                            className: "size-[18px]"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/form/PasswordInput.tsx",
                            lineNumber: 85,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$EyeIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__EyeIcon$3e$__["EyeIcon"], {
                            className: "size-[18px]"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/form/PasswordInput.tsx",
                            lineNumber: 87,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/PasswordInput.tsx",
                        lineNumber: 79,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    endContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-9 inset-y-0 flex items-center",
                        children: endContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/PasswordInput.tsx",
                        lineNumber: 92,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/form/PasswordInput.tsx",
                lineNumber: 53,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                error: error
            }, void 0, false, {
                fileName: "[project]/components/ui/form/PasswordInput.tsx",
                lineNumber: 98,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/form/PasswordInput.tsx",
        lineNumber: 50,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_s(PasswordInput, "daguiRHWMFkqPgCh/ppD7CF5VuQ=");
_c = PasswordInput;
const __TURBOPACK__default__export__ = PasswordInput;
var _c;
__turbopack_context__.k.register(_c, "PasswordInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/PhoneInput.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$phone$2d$number$2d$input$2f$min$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-phone-number-input/min/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/constants.ts [app-client] (ecmascript)");
'use client';
;
;
;
;
;
;
;
const PhoneNumberInput = ({ label, name, className, formGroupClass, labelClassName, disabled, fullWidth, inputSize = "md", radius = "md", innerShadow = false, error, placeholder = "Enter phone number", country = "GB", value = "", onChange, onBlur, ...props })=>{
    const handleChange = (phoneValue)=>{
        onChange?.(phoneValue || "");
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-group", formGroupClass, fullWidth && "w-full"),
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                htmlFor: name,
                label: label,
                className: labelClassName
            }, void 0, false, {
                fileName: "[project]/components/ui/form/PhoneInput.tsx",
                lineNumber: 57,
                columnNumber: 23
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$phone$2d$number$2d$input$2f$min$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                ...props,
                international: true,
                value: value,
                onChange: handleChange,
                onBlur: onBlur,
                disabled: disabled,
                defaultCountry: country,
                placeholder: placeholder,
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-control py-1", __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClasses"][inputSize], __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radiusClasses"][radius], error && "is-invalid", className)
            }, void 0, false, {
                fileName: "[project]/components/ui/form/PhoneInput.tsx",
                lineNumber: 59,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                error: error
            }, void 0, false, {
                fileName: "[project]/components/ui/form/PhoneInput.tsx",
                lineNumber: 77,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/form/PhoneInput.tsx",
        lineNumber: 56,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PhoneNumberInput;
const __TURBOPACK__default__export__ = PhoneNumberInput;
var _c;
__turbopack_context__.k.register(_c, "PhoneNumberInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/CheckBox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
"use client";
;
;
;
const Checkbox = ({ label, name, className, formGroupClass, labelClassName, fullWidth, radius = "md", error, checked, onChange, onBlur, value, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mb-0 pb-0 text-light", formGroupClass, fullWidth && "w-full"),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-start cursor-pointer gap-2 text-xs", labelClassName),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ...props,
                        type: "checkbox",
                        name: name,
                        checked: checked,
                        onChange: onChange,
                        onBlur: onBlur,
                        value: value,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(`shrink-0 rounded-lg text-[#E6E9EF] pointer-events-none checked:bg-primary focus:ring-primary ring-1 size-4.5 ${className}`)
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/CheckBox.tsx",
                        lineNumber: 41,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-gray-600 max-w-md", labelClassName),
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/CheckBox.tsx",
                        lineNumber: 51,
                        columnNumber: 27
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/form/CheckBox.tsx",
                lineNumber: 40,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                error: error
            }, void 0, false, {
                fileName: "[project]/components/ui/form/CheckBox.tsx",
                lineNumber: 53,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/form/CheckBox.tsx",
        lineNumber: 39,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Checkbox;
const __TURBOPACK__default__export__ = Checkbox;
var _c;
__turbopack_context__.k.register(_c, "Checkbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/Radio.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/constants.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
const Radio = ({ label, name, className, formGroupClass, labelClassName, fullWidth, radius = "full", error, checked, onChange, onBlur, value, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("mb-0 pb-0 text-light", formGroupClass, fullWidth && "w-full"),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("inline-flex items-center cursor-pointer gap-2 text-xs", labelClassName),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ...props,
                        type: "radio",
                        name: name,
                        checked: checked,
                        onChange: onChange,
                        onBlur: onBlur,
                        value: value,
                        className: "peer hidden"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Radio.tsx",
                        lineNumber: 41,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("size-4 border flex items-center justify-center", "border-[#E6E9EF] peer-checked:border-[#DDC58F]", "peer-focus:ring-2 peer-focus:ring-[#DDC58F]/15 transition-all", "relative after:content-[''] after:absolute after:size-2", "after:bg-[#DDC58F] after:scale-0 peer-checked:after:scale-100", __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["controlRadiusClasses"][radius], error && "border-red-500", className)
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Radio.tsx",
                        lineNumber: 51,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-sm text-black", labelClassName),
                        children: label
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Radio.tsx",
                        lineNumber: 61,
                        columnNumber: 27
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/form/Radio.tsx",
                lineNumber: 40,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                error: error
            }, void 0, false, {
                fileName: "[project]/components/ui/form/Radio.tsx",
                lineNumber: 63,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/form/Radio.tsx",
        lineNumber: 39,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Radio;
const __TURBOPACK__default__export__ = Radio;
var _c;
__turbopack_context__.k.register(_c, "Radio");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/Select.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/constants.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const Select = ({ label, name, className, formGroupClass, labelClassName, startContent, endContent, fullWidth, error, inputSize = "md", radius = "md", innerShadow = false, children, value, onChange, onBlur, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-group", formGroupClass, fullWidth && "w-full"),
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                htmlFor: name,
                label: label,
                className: labelClassName
            }, void 0, false, {
                fileName: "[project]/components/ui/form/Select.tsx",
                lineNumber: 50,
                columnNumber: 23
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full",
                children: [
                    startContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 inset-y-0 flex items-center",
                        children: startContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Select.tsx",
                        lineNumber: 54,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                        ...props,
                        id: name,
                        name: name,
                        value: value,
                        onChange: onChange,
                        onBlur: onBlur,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-control appearance-none pr-8", __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClasses"][inputSize], __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radiusClasses"][radius], startContent ? "pl-9" : "", endContent ? "pr-9" : "", error && "is-invalid", className),
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Select.tsx",
                        lineNumber: 59,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    endContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-3 inset-y-0 flex items-center",
                        children: endContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/Select.tsx",
                        lineNumber: 79,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/form/Select.tsx",
                lineNumber: 52,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                error: error
            }, void 0, false, {
                fileName: "[project]/components/ui/form/Select.tsx",
                lineNumber: 85,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/form/Select.tsx",
        lineNumber: 49,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Select;
const __TURBOPACK__default__export__ = Select;
var _c;
__turbopack_context__.k.register(_c, "Select");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/TextArea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/constants.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
;
const TextArea = ({ label, name, className, formGroupClass, labelClassName, startContent, endContent, fullWidth, error, inputSize = "md", radius = "md", innerShadow = false, value, onChange, onBlur, ...props })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-group", formGroupClass, fullWidth && "w-full"),
        children: [
            label && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                htmlFor: name,
                label: label,
                className: labelClassName
            }, void 0, false, {
                fileName: "[project]/components/ui/form/TextArea.tsx",
                lineNumber: 47,
                columnNumber: 23
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative w-full",
                children: [
                    startContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute left-3 top-3 flex items-start",
                        children: startContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/TextArea.tsx",
                        lineNumber: 51,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
                        ...props,
                        id: name,
                        name: name,
                        value: value,
                        onChange: onChange,
                        onBlur: onBlur,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("form-control", __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["sizeClasses"][inputSize], __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["radiusClasses"][radius], startContent ? "pl-9" : "", endContent ? "pr-9" : "", error && "is-invalid", className)
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/TextArea.tsx",
                        lineNumber: 56,
                        columnNumber: 17
                    }, ("TURBOPACK compile-time value", void 0)),
                    endContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-3 top-3 flex items-start",
                        children: endContent
                    }, void 0, false, {
                        fileName: "[project]/components/ui/form/TextArea.tsx",
                        lineNumber: 75,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/form/TextArea.tsx",
                lineNumber: 49,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                error: error
            }, void 0, false, {
                fileName: "[project]/components/ui/form/TextArea.tsx",
                lineNumber: 81,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/form/TextArea.tsx",
        lineNumber: 46,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = TextArea;
const __TURBOPACK__default__export__ = TextArea;
var _c;
__turbopack_context__.k.register(_c, "TextArea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/labelHelpers.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createFileLabel",
    ()=>createFileLabel,
    "createInputLabel",
    ()=>createInputLabel
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
const createFileLabel = ({ name, fileTypes, required = false })=>{
    const fileTypesStr = fileTypes?.join(', ') || '';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: name
            }, void 0, false, {
                fileName: "[project]/components/ui/form/labelHelpers.tsx",
                lineNumber: 18,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            fileTypesStr && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-xs text-gray-500",
                children: [
                    "(",
                    fileTypesStr,
                    ") | not more than 500kb"
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/form/labelHelpers.tsx",
                lineNumber: 19,
                columnNumber: 30
            }, ("TURBOPACK compile-time value", void 0)),
            required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-red-500",
                children: "*"
            }, void 0, false, {
                fileName: "[project]/components/ui/form/labelHelpers.tsx",
                lineNumber: 20,
                columnNumber: 26
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
const createInputLabel = ({ name, required = false })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: name
            }, void 0, false, {
                fileName: "[project]/components/ui/form/labelHelpers.tsx",
                lineNumber: 28,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            required && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-red-500",
                children: "*"
            }, void 0, false, {
                fileName: "[project]/components/ui/form/labelHelpers.tsx",
                lineNumber: 29,
                columnNumber: 26
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true);
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/form/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$PasswordInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/PasswordInput.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$PhoneInput$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/PhoneInput.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$CheckBox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/CheckBox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Radio$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Radio.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Select$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Select.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$TextArea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/TextArea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$Label$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/Label.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/ErrorMessage.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$labelHelpers$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/form/labelHelpers.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/PopupModal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$TW2E3XVA$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_default__as__Modal$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-TW2E3XVA.mjs [app-client] (ecmascript) <export modal_default as Modal>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$NWAOTABO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_content_default__as__ModalContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-NWAOTABO.mjs [app-client] (ecmascript) <export modal_content_default as ModalContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$HNQZEMGR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_body_default__as__ModalBody$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-HNQZEMGR.mjs [app-client] (ecmascript) <export modal_body_default as ModalBody>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$5LXTSPS7$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_footer_default__as__ModalFooter$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-5LXTSPS7.mjs [app-client] (ecmascript) <export modal_footer_default as ModalFooter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$R7OT77UN$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_header_default__as__ModalHeader$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-R7OT77UN.mjs [app-client] (ecmascript) <export modal_header_default as ModalHeader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/button/dist/chunk-WBUKVQRU.mjs [app-client] (ecmascript) <export button_default as Button>");
'use client';
;
;
;
;
;
const PopupModal = ({ isOpen, onClose, size, backdrops, placement, className, name, children, showCloseButton = true, title, description, icon, footer, radius = "lg", isDismissable = true, headerClassName = "p-3", bodyClassName = "p-3", footerClassName = "p-3" })=>{
    // Map custom sizes to supported sizes and add custom width classes
    const getModalSize = ()=>{
        if (size === "6xl" || size === "7xl") {
            return "5xl"; // Use largest supported size
        }
        return size || "lg";
    };
    const getCustomSizeClass = ()=>{
        if (size === "6xl") {
            return "max-w-[72rem]"; // 1152px
        }
        if (size === "7xl") {
            return "max-w-[80rem]"; // 1280px
        }
        return "";
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$TW2E3XVA$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_default__as__Modal$3e$__["Modal"], {
        id: name ? name : `modal-${Date.now()}`,
        size: getModalSize(),
        isOpen: isOpen,
        onClose: onClose,
        isDismissable: isDismissable,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(className, getCustomSizeClass()),
        classNames: {
            closeButton: "hidden",
            base: `bg-white overflow-hidden rounded-${radius} shadow-lg`
        },
        placement: placement ? placement : "center",
        scrollBehavior: "inside",
        backdrop: backdrops ? backdrops : "opaque",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$NWAOTABO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_content_default__as__ModalContent$3e$__["ModalContent"], {
            children: (onClose)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$R7OT77UN$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_header_default__as__ModalHeader$3e$__["ModalHeader"], {
                            className: `bg-[#F6F8FA] border border-[#E2E4E9] relative 
                                flex items-center justify-between py-3 ${headerClassName}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 pr-10",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-2",
                                            children: [
                                                icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "shrink-0",
                                                    children: icon
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ui/PopupModal.tsx",
                                                    lineNumber: 95,
                                                    columnNumber: 50
                                                }, ("TURBOPACK compile-time value", void 0)),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "text-base font-medium text-text-color",
                                                    children: title
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ui/PopupModal.tsx",
                                                    lineNumber: 96,
                                                    columnNumber: 41
                                                }, ("TURBOPACK compile-time value", void 0))
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ui/PopupModal.tsx",
                                            lineNumber: 94,
                                            columnNumber: 37
                                        }, ("TURBOPACK compile-time value", void 0)),
                                        description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs font-normal text-gray-500 mt-0.5",
                                            children: description
                                        }, void 0, false, {
                                            fileName: "[project]/components/ui/PopupModal.tsx",
                                            lineNumber: 99,
                                            columnNumber: 41
                                        }, ("TURBOPACK compile-time value", void 0))
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ui/PopupModal.tsx",
                                    lineNumber: 93,
                                    columnNumber: 33
                                }, ("TURBOPACK compile-time value", void 0)),
                                showCloseButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                                    size: "sm",
                                    radius: "full",
                                    isIconOnly: true,
                                    onPress: onClose,
                                    variant: "light",
                                    className: "text-text-color bg-gray-200 shrink-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
                                        className: "size-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ui/PopupModal.tsx",
                                        lineNumber: 108,
                                        columnNumber: 41
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/PopupModal.tsx",
                                    lineNumber: 104,
                                    columnNumber: 37
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/PopupModal.tsx",
                            lineNumber: 91,
                            columnNumber: 29
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$HNQZEMGR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_body_default__as__ModalBody$3e$__["ModalBody"], {
                            className: `${bodyClassName} ${!title ? 'p-0' : ''} gap-0`,
                            children: children
                        }, void 0, false, {
                            fileName: "[project]/components/ui/PopupModal.tsx",
                            lineNumber: 114,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)),
                        footer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$5LXTSPS7$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_footer_default__as__ModalFooter$3e$__["ModalFooter"], {
                            className: `bg-[#F6F8FA] border border-[#E2E4E9] py-3 relative ${footerClassName}`,
                            children: footer
                        }, void 0, false, {
                            fileName: "[project]/components/ui/PopupModal.tsx",
                            lineNumber: 119,
                            columnNumber: 29
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true)
        }, void 0, false, {
            fileName: "[project]/components/ui/PopupModal.tsx",
            lineNumber: 87,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/ui/PopupModal.tsx",
        lineNumber: 73,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = PopupModal;
const __TURBOPACK__default__export__ = PopupModal;
var _c;
__turbopack_context__.k.register(_c, "PopupModal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/MenuDropdown.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$NOHW6RMX$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__dropdown_default__as__Dropdown$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/dropdown/dist/chunk-NOHW6RMX.mjs [app-client] (ecmascript) <export dropdown_default as Dropdown>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$4LJ2IKXJ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__dropdown_trigger_default__as__DropdownTrigger$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/dropdown/dist/chunk-4LJ2IKXJ.mjs [app-client] (ecmascript) <export dropdown_trigger_default as DropdownTrigger>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$UIQ4674R$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__dropdown_menu_default__as__DropdownMenu$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/dropdown/dist/chunk-UIQ4674R.mjs [app-client] (ecmascript) <export dropdown_menu_default as DropdownMenu>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$chunk$2d$BIY4SM4Z$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__menu_item_base_default__as__DropdownItem$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/menu/dist/chunk-BIY4SM4Z.mjs [app-client] (ecmascript) <export menu_item_base_default as DropdownItem>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/button/dist/chunk-WBUKVQRU.mjs [app-client] (ecmascript) <export button_default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$ChevronDownIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/solid/esm/ChevronDownIcon.js [app-client] (ecmascript) <export default as ChevronDownIcon>");
;
var _s = __turbopack_context__.k.signature();
'use client';
;
;
;
;
const MenuDropdown = ({ label, value, items = [], onChange, triggerClassName, startContent, endContent, showChevron = true, menuClassName, itemClassName, className, trigger })=>{
    _s();
    const [internalLabel, setInternalLabel] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(label || items[0]?.label || "Select");
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "MenuDropdown.useEffect": ()=>{
            if (value !== undefined) {
                const found = items.find({
                    "MenuDropdown.useEffect.found": (i)=>i.key === value
                }["MenuDropdown.useEffect.found"]);
                setInternalLabel(found ? found.label : label || "Select");
            }
        }
    }["MenuDropdown.useEffect"], [
        value,
        items,
        label
    ]);
    const handleSelect = (key, itemLabel)=>{
        if (value === undefined) {
            setInternalLabel(itemLabel);
        }
        if (onChange) onChange(key);
        setIsOpen(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$NOHW6RMX$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__dropdown_default__as__Dropdown$3e$__["Dropdown"], {
        className: className,
        onOpenChange: (open)=>setIsOpen(open),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$4LJ2IKXJ$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__dropdown_trigger_default__as__DropdownTrigger$3e$__["DropdownTrigger"], {
                children: trigger ? trigger : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                    "aria-label": `Select ${internalLabel}`,
                    startContent: startContent,
                    endContent: endContent ? endContent : showChevron && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$ChevronDownIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ChevronDownIcon$3e$__["ChevronDownIcon"], {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("size-3.5 transition-transform duration-300", isOpen ? "rotate-180" : "rotate-0")
                    }, void 0, false, {
                        fileName: "[project]/components/ui/MenuDropdown.tsx",
                        lineNumber: 82,
                        columnNumber: 37
                    }, void 0),
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("text-[12px] border-0 h-auto text-text-color rounded-lg p-2 bg-white", triggerClassName),
                    children: internalLabel
                }, void 0, false, {
                    fileName: "[project]/components/ui/MenuDropdown.tsx",
                    lineNumber: 76,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/MenuDropdown.tsx",
                lineNumber: 74,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$dropdown$2f$dist$2f$chunk$2d$UIQ4674R$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__dropdown_menu_default__as__DropdownMenu$3e$__["DropdownMenu"], {
                "aria-label": "Menu Dropdown",
                className: menuClassName,
                children: items.map(({ key, label: itemLabel, icon, className: itemClass })=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$menu$2f$dist$2f$chunk$2d$BIY4SM4Z$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__menu_item_base_default__as__DropdownItem$3e$__["DropdownItem"], {
                        startContent: icon,
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(itemClassName, itemClass),
                        classNames: {
                            base: "py-1",
                            title: "text-[12px] font-normal"
                        },
                        onPress: ()=>handleSelect(key, itemLabel),
                        children: itemLabel
                    }, key, false, {
                        fileName: "[project]/components/ui/MenuDropdown.tsx",
                        lineNumber: 101,
                        columnNumber: 21
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/components/ui/MenuDropdown.tsx",
                lineNumber: 97,
                columnNumber: 13
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/MenuDropdown.tsx",
        lineNumber: 70,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_s(MenuDropdown, "bUQltWwc6KbiIsP43T3e7LBJNd0=");
_c = MenuDropdown;
const __TURBOPACK__default__export__ = MenuDropdown;
var _c;
__turbopack_context__.k.register(_c, "MenuDropdown");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/button/dist/chunk-WBUKVQRU.mjs [app-client] (ecmascript) <export button_default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$spinner$2f$dist$2f$chunk$2d$S6CZL5JF$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__spinner_default__as__Spinner$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/spinner/dist/chunk-S6CZL5JF.mjs [app-client] (ecmascript) <export spinner_default as Spinner>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
"use client";
;
;
;
const CustomButton = ({ type = "button", isDisabled = false, onClick, onPress, color = "default", size = "md", className, loading = false, spinnerColor = "default", spinnerSize = "sm", children, startContent, endContent, bordered, variant = "solid", ...rest })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
        type: type,
        isDisabled: isDisabled || loading,
        onPress: onPress || onClick,
        color: color,
        size: size,
        variant: variant,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("flex items-center gap-1 text-xs font-medium transition-colors", className),
        bordered: bordered,
        ...rest,
        children: loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$spinner$2f$dist$2f$chunk$2d$S6CZL5JF$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__spinner_default__as__Spinner$3e$__["Spinner"], {
            color: spinnerColor,
            size: spinnerSize
        }, void 0, false, {
            fileName: "[project]/components/ui/button.tsx",
            lineNumber: 64,
            columnNumber: 17
        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: [
                startContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "mr-1",
                    children: startContent
                }, void 0, false, {
                    fileName: "[project]/components/ui/button.tsx",
                    lineNumber: 67,
                    columnNumber: 38
                }, ("TURBOPACK compile-time value", void 0)),
                children,
                endContent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "ml-1",
                    children: endContent
                }, void 0, false, {
                    fileName: "[project]/components/ui/button.tsx",
                    lineNumber: 69,
                    columnNumber: 36
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true)
    }, void 0, false, {
        fileName: "[project]/components/ui/button.tsx",
        lineNumber: 50,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = CustomButton;
const __TURBOPACK__default__export__ = CustomButton;
var _c;
__turbopack_context__.k.register(_c, "CustomButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/table.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Table",
    ()=>Table,
    "TableBody",
    ()=>TableBody,
    "TableCell",
    ()=>TableCell,
    "TableHead",
    ()=>TableHead,
    "TableHeader",
    ()=>TableHeader,
    "TableRow",
    ()=>TableRow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/classname.ts [app-client] (ecmascript)");
;
;
const Table = ({ children, className = '' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "-m-1.5 overflow-x-auto scrollbar-thin",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "p-1.5 min-w-full inline-block align-middle",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("table", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("min-w-full divide-y divide-gray-100 tracking-wide", className),
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/components/ui/table.tsx",
                        lineNumber: 14,
                        columnNumber: 25
                    }, ("TURBOPACK compile-time value", void 0))
                }, void 0, false, {
                    fileName: "[project]/components/ui/table.tsx",
                    lineNumber: 13,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/table.tsx",
                lineNumber: 12,
                columnNumber: 17
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/components/ui/table.tsx",
            lineNumber: 11,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 10,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Table;
const TableBody = ({ children, className = '' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tbody", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("divide-y divide-gray-100", className),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 29,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c1 = TableBody;
const TableHead = ({ children, className = '', scope = "col" })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("th", {
        scope: scope,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-6 py-3 bg-[#F4F6F8] text-left whitespace-nowrap font-normal", className),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 41,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c2 = TableHead;
const TableHeader = ({ children, className = '' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("thead", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("bg-white text-[#6B7280] border-t border-[#EAECF0] text-xs", className),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 52,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c3 = TableHeader;
const TableRow = ({ children, className = '', onClick, style })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("tr", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])(className, onClick && 'hover:bg-gray-50 transition-colors'),
        onClick: onClick,
        style: style,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 65,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c4 = TableRow;
const TableCell = ({ children, className = '', colSpan })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("td", {
        colSpan: colSpan,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$classname$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["cn"])("px-6 py-3 text-xs whitespace-nowrap", className),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/table.tsx",
        lineNumber: 81,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c5 = TableCell;
;
var _c, _c1, _c2, _c3, _c4, _c5;
__turbopack_context__.k.register(_c, "Table");
__turbopack_context__.k.register(_c1, "TableBody");
__turbopack_context__.k.register(_c2, "TableHead");
__turbopack_context__.k.register(_c3, "TableHeader");
__turbopack_context__.k.register(_c4, "TableRow");
__turbopack_context__.k.register(_c5, "TableCell");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/Drawer.tsx [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Drawer",
    ()=>Drawer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$drawer$2f$dist$2f$chunk$2d$I6N33TCU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__drawer_default__as__Drawer$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/drawer/dist/chunk-I6N33TCU.mjs [app-client] (ecmascript) <export drawer_default as Drawer>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$NWAOTABO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_content_default__as__DrawerContent$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-NWAOTABO.mjs [app-client] (ecmascript) <export modal_content_default as DrawerContent>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$R7OT77UN$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_header_default__as__DrawerHeader$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-R7OT77UN.mjs [app-client] (ecmascript) <export modal_header_default as DrawerHeader>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$HNQZEMGR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_body_default__as__DrawerBody$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-HNQZEMGR.mjs [app-client] (ecmascript) <export modal_body_default as DrawerBody>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$5LXTSPS7$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_footer_default__as__DrawerFooter$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/modal/dist/chunk-5LXTSPS7.mjs [app-client] (ecmascript) <export modal_footer_default as DrawerFooter>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroui/button/dist/chunk-WBUKVQRU.mjs [app-client] (ecmascript) <export button_default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$use$2d$disclosure$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@heroui/use-disclosure/dist/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/XMarkIcon.js [app-client] (ecmascript) <export default as XMarkIcon>");
'use client';
;
;
;
const Drawer = ({ isOpen, onOpenChange, placement = 'right', size = 'md', title, icon, children, footer, showCloseButton = true, className = '', contentClassName = '', headerClassName = 'p-3', bodyClassName = 'p-3', footerClassName = 'p-3' })=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$drawer$2f$dist$2f$chunk$2d$I6N33TCU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__drawer_default__as__Drawer$3e$__["Drawer"], {
        isOpen: isOpen,
        onOpenChange: onOpenChange,
        placement: placement,
        size: size,
        hideCloseButton: true,
        className: className,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$NWAOTABO$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_content_default__as__DrawerContent$3e$__["DrawerContent"], {
            className: contentClassName,
            children: [
                title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$R7OT77UN$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_header_default__as__DrawerHeader$3e$__["DrawerHeader"], {
                    className: `bg-[#F6F8FA] border border-[#E2E4E9] relative 
                    flex items-center justify-between py-3 ${headerClassName}`,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 pr-10",
                            children: [
                                icon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "shrink-0",
                                    children: icon
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/Drawer.tsx",
                                    lineNumber: 62,
                                    columnNumber: 38
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: "text-sm font-medium text-text-color",
                                    children: title
                                }, void 0, false, {
                                    fileName: "[project]/components/ui/Drawer.tsx",
                                    lineNumber: 63,
                                    columnNumber: 29
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ui/Drawer.tsx",
                            lineNumber: 61,
                            columnNumber: 25
                        }, ("TURBOPACK compile-time value", void 0)),
                        showCloseButton && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$button$2f$dist$2f$chunk$2d$WBUKVQRU$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__button_default__as__Button$3e$__["Button"], {
                            size: "sm",
                            radius: "full",
                            isIconOnly: true,
                            onPress: ()=>onOpenChange(false),
                            className: "text-text-color bg-gray-200 ",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XMarkIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XMarkIcon$3e$__["XMarkIcon"], {
                                className: "size-4"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/Drawer.tsx",
                                lineNumber: 73,
                                columnNumber: 33
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/components/ui/Drawer.tsx",
                            lineNumber: 67,
                            columnNumber: 29
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ui/Drawer.tsx",
                    lineNumber: 59,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$HNQZEMGR$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_body_default__as__DrawerBody$3e$__["DrawerBody"], {
                    className: bodyClassName,
                    children: children
                }, void 0, false, {
                    fileName: "[project]/components/ui/Drawer.tsx",
                    lineNumber: 80,
                    columnNumber: 17
                }, ("TURBOPACK compile-time value", void 0)),
                footer && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroui$2f$modal$2f$dist$2f$chunk$2d$5LXTSPS7$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__modal_footer_default__as__DrawerFooter$3e$__["DrawerFooter"], {
                    className: `bg-[#F6F8FA] border border-[#E2E4E9] py-3 relative ${footerClassName}`,
                    children: footer
                }, void 0, false, {
                    fileName: "[project]/components/ui/Drawer.tsx",
                    lineNumber: 85,
                    columnNumber: 21
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/ui/Drawer.tsx",
            lineNumber: 56,
            columnNumber: 13
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/components/ui/Drawer.tsx",
        lineNumber: 49,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0));
};
_c = Drawer;
;
var _c;
__turbopack_context__.k.register(_c, "Drawer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/ColorPicker.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ColorPicker",
    ()=>ColorPicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
const PRESET_COLORS = [
    {
        name: "Blue",
        value: "#3B82F6"
    },
    {
        name: "Purple",
        value: "#8B5CF6"
    },
    {
        name: "Pink",
        value: "#EC4899"
    },
    {
        name: "Red",
        value: "#EF4444"
    },
    {
        name: "Orange",
        value: "#F97316"
    },
    {
        name: "Yellow",
        value: "#EAB308"
    },
    {
        name: "Green",
        value: "#10B981"
    },
    {
        name: "Teal",
        value: "#14B8A6"
    },
    {
        name: "Cyan",
        value: "#06B6D4"
    },
    {
        name: "Indigo",
        value: "#6366F1"
    },
    {
        name: "Gray",
        value: "#6B7280"
    },
    {
        name: "Slate",
        value: "#64748B"
    }
];
const ColorPicker = ({ value, onChange, label = "Primary Color" })=>{
    _s();
    const [showPicker, setShowPicker] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                className: "block text-sm font-medium text-neutral-700",
                children: label
            }, void 0, false, {
                fileName: "[project]/components/ui/ColorPicker.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onClick: ()=>setShowPicker(!showPicker),
                                className: "w-16 h-16 rounded-lg border-2 border-neutral-300 shadow-sm hover:shadow-md transition-shadow",
                                style: {
                                    backgroundColor: value
                                },
                                "aria-label": "Color preview"
                            }, void 0, false, {
                                fileName: "[project]/components/ui/ColorPicker.tsx",
                                lineNumber: 43,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            showPicker && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute z-10 mt-2 p-4 bg-white rounded-lg shadow-xl border border-neutral-200",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "grid grid-cols-6 gap-2 mb-4",
                                        children: PRESET_COLORS.map((color)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                type: "button",
                                                onClick: ()=>{
                                                    onChange(color.value);
                                                    setShowPicker(false);
                                                },
                                                className: `w-10 h-10 rounded-lg border-2 transition-all ${value === color.value ? "border-neutral-900 scale-110" : "border-neutral-300 hover:border-neutral-500"}`,
                                                style: {
                                                    backgroundColor: color.value
                                                },
                                                title: color.name
                                            }, color.value, false, {
                                                fileName: "[project]/components/ui/ColorPicker.tsx",
                                                lineNumber: 55,
                                                columnNumber: 19
                                            }, ("TURBOPACK compile-time value", void 0)))
                                    }, void 0, false, {
                                        fileName: "[project]/components/ui/ColorPicker.tsx",
                                        lineNumber: 53,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "color",
                                                value: value,
                                                onChange: (e)=>onChange(e.target.value),
                                                className: "w-full h-10 rounded border border-neutral-300 cursor-pointer"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ui/ColorPicker.tsx",
                                                lineNumber: 74,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                type: "text",
                                                value: value,
                                                onChange: (e)=>{
                                                    if (/^#[0-9A-Fa-f]{0,6}$/.test(e.target.value)) {
                                                        onChange(e.target.value);
                                                    }
                                                },
                                                className: "w-24 px-2 py-1 text-sm border border-neutral-300 rounded",
                                                placeholder: "#000000"
                                            }, void 0, false, {
                                                fileName: "[project]/components/ui/ColorPicker.tsx",
                                                lineNumber: 80,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/ui/ColorPicker.tsx",
                                        lineNumber: 73,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ui/ColorPicker.tsx",
                                lineNumber: 51,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ui/ColorPicker.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                            type: "text",
                            value: value,
                            onChange: (e)=>{
                                if (/^#[0-9A-Fa-f]{0,6}$/.test(e.target.value)) {
                                    onChange(e.target.value);
                                }
                            },
                            className: "w-full px-3 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-primary-500 focus:border-primary-500",
                            placeholder: "#3B82F6"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/ColorPicker.tsx",
                            lineNumber: 98,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/ui/ColorPicker.tsx",
                        lineNumber: 97,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/ColorPicker.tsx",
                lineNumber: 40,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            showPicker && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "fixed inset-0 z-0",
                onClick: ()=>setShowPicker(false)
            }, void 0, false, {
                fileName: "[project]/components/ui/ColorPicker.tsx",
                lineNumber: 114,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/ColorPicker.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(ColorPicker, "PcDCImg70lXrYgxmpw3ewp/jgFc=");
_c = ColorPicker;
var _c;
__turbopack_context__.k.register(_c, "ColorPicker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/CaptivatingLoader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CaptivatingLoader",
    ()=>CaptivatingLoader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$SparklesIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SparklesIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/solid/esm/SparklesIcon.js [app-client] (ecmascript) <export default as SparklesIcon>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const DEFAULT_TEXTS = [
    "Analyzing your request...",
    "Gathering design inspiration...",
    "Crafting unique elements...",
    "Polishing the details...",
    "Almost there..."
];
const CaptivatingLoader = ({ loadingTexts = DEFAULT_TEXTS, subText = "This may take a few seconds", className = "" })=>{
    _s();
    const [currentTextIndex, setCurrentTextIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "CaptivatingLoader.useEffect": ()=>{
            const interval = setInterval({
                "CaptivatingLoader.useEffect.interval": ()=>{
                    setCurrentTextIndex({
                        "CaptivatingLoader.useEffect.interval": (prev)=>(prev + 1) % loadingTexts.length
                    }["CaptivatingLoader.useEffect.interval"]);
                }
            }["CaptivatingLoader.useEffect.interval"], 2000);
            return ({
                "CaptivatingLoader.useEffect": ()=>clearInterval(interval)
            })["CaptivatingLoader.useEffect"];
        }
    }["CaptivatingLoader.useEffect"], [
        loadingTexts.length
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `flex flex-col items-center justify-center p-8 text-center ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 bg-blue-500 rounded-full blur-xl opacity-20 animate-pulse"
                    }, void 0, false, {
                        fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                        lineNumber: 39,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative bg-white p-4 rounded-full shadow-lg border-2 border-blue-100",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$solid$2f$esm$2f$SparklesIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__SparklesIcon$3e$__["SparklesIcon"], {
                            className: "w-8 h-8 text-blue-600 animate-spin-slow"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                            lineNumber: 41,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                        lineNumber: 40,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 animate-spin-custom",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute top-0 left-1/2 -ml-1 w-2 h-2 bg-blue-400 rounded-full"
                        }, void 0, false, {
                            fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                            lineNumber: 46,
                            columnNumber: 11
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                        lineNumber: 45,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "text-xl font-semibold text-neutral-800 mb-2 min-h-[28px] transition-all duration-500",
                children: loadingTexts[currentTextIndex]
            }, void 0, false, {
                fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-neutral-500",
                children: subText
            }, void 0, false, {
                fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                lineNumber: 56,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-48 h-1.5 bg-neutral-100 rounded-full mt-6 overflow-hidden",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "h-full bg-blue-600 rounded-full animate-progress-indeterminate"
                }, void 0, false, {
                    fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/components/ui/CaptivatingLoader.tsx",
                lineNumber: 59,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/ui/CaptivatingLoader.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(CaptivatingLoader, "cmnTRYLsqEsvwtd9r3dK0eNZn0U=");
_c = CaptivatingLoader;
var _c;
__turbopack_context__.k.register(_c, "CaptivatingLoader");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/index.ts [app-client] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$form$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/form/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$PopupModal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/PopupModal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$MenuDropdown$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/MenuDropdown.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$table$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/table.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$Drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/Drawer.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$ColorPicker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/ColorPicker.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$CaptivatingLoader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/CaptivatingLoader.tsx [app-client] (ecmascript)");
;
;
;
;
;
;
;
;
;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ui/button.tsx [app-client] (ecmascript) <export default as Button>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript)");
}),
"[project]/components/editor/customBlocks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Custom GrapeJS Blocks Registration
 * Registers custom blocks with Tailwind CSS styling
 */ __turbopack_context__.s([
    "registerCustomBlocks",
    ()=>registerCustomBlocks
]);
const registerCustomBlocks = (editor)=>{
    const blockManager = editor.BlockManager;
    // Hero Section Block
    blockManager.add('hero-section', {
        label: 'Hero Section',
        category: 'Sections',
        content: `
      <section class="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div class="container mx-auto px-4 text-center">
          <h1 class="text-5xl font-bold mb-4">Welcome to Our Store</h1>
          <p class="text-xl mb-8">Discover amazing products at great prices</p>
          <button class="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
            Shop Now
          </button>
        </div>
      </section>
    `,
        attributes: {
            class: 'fa fa-star'
        }
    });
    // Feature Cards Block
    blockManager.add('feature-cards', {
        label: 'Feature Cards',
        category: 'Sections',
        content: `
      <section class="py-16 bg-gray-50">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold text-center mb-12">Our Features</h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
              <div class="text-blue-600 text-4xl mb-4">🚀</div>
              <h3 class="text-xl font-semibold mb-2">Fast Delivery</h3>
              <p class="text-gray-600">Get your orders delivered quickly and safely</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
              <div class="text-blue-600 text-4xl mb-4">💎</div>
              <h3 class="text-xl font-semibold mb-2">Premium Quality</h3>
              <p class="text-gray-600">Only the best products for our customers</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
              <div class="text-blue-600 text-4xl mb-4">🔒</div>
              <h3 class="text-xl font-semibold mb-2">Secure Payment</h3>
              <p class="text-gray-600">Your transactions are safe and encrypted</p>
            </div>
          </div>
        </div>
      </section>
    `,
        attributes: {
            class: 'fa fa-th'
        }
    });
    // Product Grid Block
    blockManager.add('product-grid', {
        label: 'Product Grid',
        category: 'E-commerce',
        content: `
      <section class="py-16">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold text-center mb-12">Featured Products</h2>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$99</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$149</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$79</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$199</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `,
        attributes: {
            class: 'fa fa-shopping-cart'
        }
    });
    // Testimonial Section Block
    blockManager.add('testimonials', {
        label: 'Testimonials',
        category: 'Sections',
        content: `
      <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div class="bg-gray-50 p-6 rounded-lg">
              <div class="flex items-center mb-4">
                <div class="w-12 h-12 bg-blue-600 rounded-full mr-4"></div>
                <div>
                  <h4 class="font-semibold">John Doe</h4>
                  <p class="text-sm text-gray-600">Verified Customer</p>
                </div>
              </div>
              <p class="text-gray-700 italic">"Amazing products and excellent service! Highly recommended."</p>
              <div class="mt-4 text-yellow-500">★★★★★</div>
            </div>
            <div class="bg-gray-50 p-6 rounded-lg">
              <div class="flex items-center mb-4">
                <div class="w-12 h-12 bg-blue-600 rounded-full mr-4"></div>
                <div>
                  <h4 class="font-semibold">Jane Smith</h4>
                  <p class="text-sm text-gray-600">Verified Customer</p>
                </div>
              </div>
              <p class="text-gray-700 italic">"Fast shipping and great quality. Will definitely order again!"</p>
              <div class="mt-4 text-yellow-500">★★★★★</div>
            </div>
            <div class="bg-gray-50 p-6 rounded-lg">
              <div class="flex items-center mb-4">
                <div class="w-12 h-12 bg-blue-600 rounded-full mr-4"></div>
                <div>
                  <h4 class="font-semibold">Mike Johnson</h4>
                  <p class="text-sm text-gray-600">Verified Customer</p>
                </div>
              </div>
              <p class="text-gray-700 italic">"Best online shopping experience I've had. Five stars!"</p>
              <div class="mt-4 text-yellow-500">★★★★★</div>
            </div>
          </div>
        </div>
      </section>
    `,
        attributes: {
            class: 'fa fa-comments'
        }
    });
    // CTA Section Block
    blockManager.add('cta-section', {
        label: 'Call to Action',
        category: 'Sections',
        content: `
      <section class="bg-blue-600 text-white py-16">
        <div class="container mx-auto px-4 text-center">
          <h2 class="text-4xl font-bold mb-4">Ready to Get Started?</h2>
          <p class="text-xl mb-8">Join thousands of satisfied customers today</p>
          <div class="flex gap-4 justify-center">
            <button class="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
              Get Started
            </button>
            <button class="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition">
              Learn More
            </button>
          </div>
        </div>
      </section>
    `,
        attributes: {
            class: 'fa fa-bullhorn'
        }
    });
    // Footer Block
    blockManager.add('footer', {
        label: 'Footer',
        category: 'Sections',
        content: `
      <footer class="bg-gray-900 text-white py-12">
        <div class="container mx-auto px-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 class="text-xl font-bold mb-4">About Us</h3>
              <p class="text-gray-400">Your trusted online store for quality products.</p>
            </div>
            <div>
              <h3 class="text-xl font-bold mb-4">Quick Links</h3>
              <ul class="space-y-2 text-gray-400">
                <li><a href="#" class="hover:text-white transition">Home</a></li>
                <li><a href="#" class="hover:text-white transition">Shop</a></li>
                <li><a href="#" class="hover:text-white transition">About</a></li>
                <li><a href="#" class="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 class="text-xl font-bold mb-4">Customer Service</h3>
              <ul class="space-y-2 text-gray-400">
                <li><a href="#" class="hover:text-white transition">FAQ</a></li>
                <li><a href="#" class="hover:text-white transition">Shipping</a></li>
                <li><a href="#" class="hover:text-white transition">Returns</a></li>
                <li><a href="#" class="hover:text-white transition">Support</a></li>
              </ul>
            </div>
            <div>
              <h3 class="text-xl font-bold mb-4">Newsletter</h3>
              <p class="text-gray-400 mb-4">Subscribe for updates and offers</p>
              <input type="email" placeholder="Your email" class="w-full px-4 py-2 rounded text-gray-900 mb-2">
              <button class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                Subscribe
              </button>
            </div>
          </div>
          <div class="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2026 Your Store. All rights reserved.</p>
          </div>
        </div>
      </footer>
    `,
        attributes: {
            class: 'fa fa-bars'
        }
    });
    // Container Block
    blockManager.add('container', {
        label: 'Container',
        category: 'Layout',
        content: `<div class="container mx-auto px-4 py-8"></div>`,
        attributes: {
            class: 'fa fa-square-o'
        }
    });
    // Grid 2 Columns
    blockManager.add('grid-2-col', {
        label: '2 Columns',
        category: 'Layout',
        content: `
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="p-4 bg-gray-100 rounded">Column 1</div>
        <div class="p-4 bg-gray-100 rounded">Column 2</div>
      </div>
    `,
        attributes: {
            class: 'fa fa-columns'
        }
    });
    // Grid 3 Columns
    blockManager.add('grid-3-col', {
        label: '3 Columns',
        category: 'Layout',
        content: `
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="p-4 bg-gray-100 rounded">Column 1</div>
        <div class="p-4 bg-gray-100 rounded">Column 2</div>
        <div class="p-4 bg-gray-100 rounded">Column 3</div>
      </div>
    `,
        attributes: {
            class: 'fa fa-th'
        }
    });
    // Button Block
    blockManager.add('button', {
        label: 'Button',
        category: 'Components',
        content: `
      <button class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-semibold">
        Click Me
      </button>
    `,
        attributes: {
            class: 'fa fa-hand-pointer-o'
        }
    });
    // Card Block
    blockManager.add('card', {
        label: 'Card',
        category: 'Components',
        content: `
      <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm">
        <h3 class="text-xl font-bold mb-2">Card Title</h3>
        <p class="text-gray-600 mb-4">Card description goes here. Add your content.</p>
        <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
          Learn More
        </button>
      </div>
    `,
        attributes: {
            class: 'fa fa-id-card-o'
        }
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/editor/ecommerceBlocks.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Custom E-commerce Blocks for GrapeJS
 * Reusable blocks with high-quality Tailwind CSS design
 */ __turbopack_context__.s([
    "customEcommerceBlocks",
    ()=>customEcommerceBlocks,
    "registerEcommerceBlocks",
    ()=>registerEcommerceBlocks
]);
const customEcommerceBlocks = [
    // 1. Category Design
    {
        label: "Category Grid",
        category: "E-commerce",
        content: `
      <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
          <h2 class="text-2xl font-bold mb-8 text-center text-gray-800">Shop by Category</h2>
          <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-blue-50 flex items-center justify-center mb-4 group-hover:bg-blue-100 transition-colors border border-blue-100 shadow-sm">
                <img src="/assets/img/categories/electronics.png" alt="Electronics" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3659/3659899.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-blue-600">Electronics</span>
            </div>
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-pink-50 flex items-center justify-center mb-4 group-hover:bg-pink-100 transition-colors border border-pink-100 shadow-sm">
                <img src="/assets/img/categories/fashion.png" alt="Fashion" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3050/3050239.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-pink-600">Fashion</span>
            </div>
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-green-50 flex items-center justify-center mb-4 group-hover:bg-green-100 transition-colors border border-green-100 shadow-sm">
                <img src="/assets/img/categories/home.png" alt="Home" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/2544/2544111.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-green-600">Home</span>
            </div>
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-yellow-50 flex items-center justify-center mb-4 group-hover:bg-yellow-100 transition-colors border border-yellow-100 shadow-sm">
                <img src="/assets/img/categories/beauty.png" alt="Beauty" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3163/3163212.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-yellow-600">Beauty</span>
            </div>
             <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-purple-50 flex items-center justify-center mb-4 group-hover:bg-purple-100 transition-colors border border-purple-100 shadow-sm">
                <img src="/assets/img/categories/sports.png" alt="Sports" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/857/857455.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-purple-600">Sports</span>
            </div>
             <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-indigo-50 flex items-center justify-center mb-4 group-hover:bg-indigo-100 transition-colors border border-indigo-100 shadow-sm">
                <img src="/assets/img/categories/toys.png" alt="Toys" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3082/3082045.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-indigo-600">Toys</span>
            </div>
          </div>
        </div>
      </section>
    `
    },
    // 2. Top Brands
    {
        label: "Top Brands",
        category: "E-commerce",
        content: `
      <section class="py-10 border-t border-b border-gray-100 bg-gray-50">
        <div class="container mx-auto px-4 text-center">
          <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Our Top Trusted Brands</p>
          <div class="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-60">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/a/a6/Logo_NIKE.svg" alt="Nike">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/2/20/Adidas_Logo.svg" alt="Adidas">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/5/53/H%26M-Logo.svg" alt="H&M">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/9/94/Zara_Logo.svg" alt="Zara">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/f/f9/Apple_logo_black.svg" alt="Apple">
          </div>
        </div>
      </section>
    `
    },
    // 3. Trending Products
    {
        label: "Trending Products",
        category: "E-commerce",
        content: `
      <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
          <div class="flex items-center justify-between mb-10">
            <div>
              <h2 class="text-3xl font-bold text-gray-900 mb-2">Trending Now</h2>
              <p class="text-gray-500">The most popular items this month</p>
            </div>
            <a href="#" class="text-blue-600 font-semibold flex items-center gap-1 hover:underline">
              View All <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
            </a>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- Product 1 -->
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <span class="absolute top-4 left-4 bg-orange-500 text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">Trending</span>
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">Premium Wireless Watch</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">High-performance smartwatch with health tracking and GPS connectivity.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$299.99</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(45)</span>
                  </div>
                </div>
              </div>
            </div>
            <!-- More products can be added here with same structure -->
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">UltraBass Headphones</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">Noise-canceling over-ear headphones with 40-hour battery life.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$189.00</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(128)</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">SpeedRun Sport Shoes</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">Lightweight running shoes designed for ultimate speed and stability.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$125.50</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(84)</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">Classic Aviators</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">Handcrafted sunglasses with UV400 protection and polarized lenses.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$75.00</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(32)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `
    },
    // 4. Flash Sales
    {
        label: "Flash Sales",
        category: "E-commerce",
        content: `
      <section class="py-12 bg-gradient-to-r from-red-600 to-orange-500">
        <div class="container mx-auto px-4">
          <div class="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-8">
            <div class="text-center md:text-left flex-1">
              <span class="inline-block bg-white text-red-600 text-xs font-black px-4 py-1 rounded-full mb-4 animate-pulse">FLASH SALE 🔥</span>
              <h2 class="text-4xl font-black text-white mb-4">Upto 70% Off!</h2>
              <p class="text-white/80 text-lg mb-6">Don't miss out on our biggest yearly clearance event.</p>
              <div class="flex items-center justify-center md:justify-start gap-4">
                 <div class="flex flex-col items-center">
                    <span class="w-12 h-12 flex items-center justify-center bg-white rounded-lg text-red-600 font-black text-xl">12</span>
                    <span class="text-[10px] text-white/70 mt-1 uppercase">hrs</span>
                 </div>
                 <span class="text-2xl text-white font-bold">:</span>
                 <div class="flex flex-col items-center">
                    <span class="w-12 h-12 flex items-center justify-center bg-white rounded-lg text-red-600 font-black text-xl">45</span>
                    <span class="text-[10px] text-white/70 mt-1 uppercase">min</span>
                 </div>
                 <span class="text-2xl text-white font-bold">:</span>
                 <div class="flex flex-col items-center">
                    <span class="w-12 h-12 flex items-center justify-center bg-white rounded-lg text-red-600 font-black text-xl">22</span>
                    <span class="text-[10px] text-white/70 mt-1 uppercase">sec</span>
                 </div>
              </div>
            </div>
            <div class="flex-1 flex justify-center">
               <div class="relative group">
                  <div class="absolute -inset-4 bg-white/20 blur-2xl group-hover:bg-white/30 transition-all rounded-full"></div>
                  <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80" alt="Flash Sale Product" class="w-72 md:w-96 drop-shadow-2xl translate-z-10 transform -rotate-12 group-hover:rotate-0 transition-transform duration-700">
               </div>
            </div>
            <div class="shrink-0">
               <button class="bg-white text-gray-900 px-10 py-4 rounded-xl font-black shadow-2xl hover:bg-gray-900 hover:text-white transition-all transform hover:scale-105">SHOP THE SALE</button>
            </div>
          </div>
        </div>
      </section>
    `
    },
    // 5. Product Carousel
    {
        label: "Product Carousel",
        category: "E-commerce",
        content: `
      <section class="py-16 bg-gray-50 overflow-hidden">
        <div class="container mx-auto px-4">
          <div class="text-center mb-12">
             <h2 class="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">Handpicked with ❤️</h2>
             <div class="w-20 h-1.5 bg-indigo-600 mx-auto mt-4 rounded-full"></div>
          </div>
          
          <div class="relative w-full max-w-5xl mx-auto">
            <!-- Navigation Buttons -->
            <button class="absolute top-1/2 -left-4 md:-left-12 -translate-y-1/2 w-10 h-10 md:w-14 md:h-14 bg-white rounded-full shadow-2xl flex items-center justify-center text-gray-900 hover:bg-gray-900 hover:text-white z-10 transition-all">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15 19l-7-7 7-7"></path></svg>
            </button>
            <button class="absolute top-1/2 -right-4 md:-right-12 -translate-y-1/2 w-10 h-10 md:w-14 md:h-14 bg-white rounded-full shadow-2xl flex items-center justify-center text-gray-900 hover:bg-gray-900 hover:text-white z-10 transition-all">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7"></path></svg>
            </button>

            <!-- Product Display Area -->
            <div class="flex gap-8 overflow-x-auto no-scrollbar scroll-smooth pb-10">
              <!-- Item 1 -->
              <div class="min-w-[280px] md:min-w-[320px] bg-white rounded-2xl shadow-sm border border-gray-100 p-6 transform hover:-translate-y-2 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80" class="w-full aspect-square object-contain mb-6 drop-shadow-lg" alt="Item">
                <div class="text-center">
                  <h4 class="font-bold text-lg text-gray-800">Air Zoom Pegasus 38</h4>
                  <p class="text-gray-400 text-sm mb-4">Unisex Running Shield</p>
                  <p class="text-2xl font-black text-indigo-600 mb-6">$120.00</p>
                  <button class="w-full py-3 bg-gray-50 hover:bg-gray-900 hover:text-white text-gray-900 border border-gray-100 font-bold rounded-xl transition-all">DETAILS</button>
                </div>
              </div>
              <div class="min-w-[280px] md:min-w-[320px] bg-white rounded-2xl shadow-sm border border-gray-100 p-6 transform hover:-translate-y-2 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80" class="w-full aspect-square object-contain mb-6 drop-shadow-lg" alt="Item">
                <div class="text-center">
                  <h4 class="font-bold text-lg text-gray-800">Premium White Watch</h4>
                  <p class="text-gray-400 text-sm mb-4">Smart Lifestyle Gear</p>
                  <p class="text-2xl font-black text-indigo-600 mb-6">$299.00</p>
                  <button class="w-full py-3 bg-gray-50 hover:bg-gray-900 hover:text-white text-gray-900 border border-gray-100 font-bold rounded-xl transition-all">DETAILS</button>
                </div>
              </div>
              <div class="min-w-[280px] md:min-w-[320px] bg-white rounded-2xl shadow-sm border border-gray-100 p-6 transform hover:-translate-y-2 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80" class="w-full aspect-square object-contain mb-6 drop-shadow-lg" alt="Item">
                <div class="text-center">
                  <h4 class="font-bold text-lg text-gray-800">Ultra High-Res Audio</h4>
                  <p class="text-gray-400 text-sm mb-4">Wireless Beats Experience</p>
                  <p class="text-2xl font-black text-indigo-600 mb-6">$189.00</p>
                  <button class="w-full py-3 bg-gray-50 hover:bg-gray-900 hover:text-white text-gray-900 border border-gray-100 font-bold rounded-xl transition-all">DETAILS</button>
                </div>
              </div>
            </div>

            <!-- Indicators -->
            <div class="flex justify-center gap-2 mt-4">
              <div class="w-8 h-2 bg-indigo-600 rounded-full transition-all"></div>
              <div class="w-2 h-2 bg-gray-300 rounded-full transition-all hover:bg-indigo-300"></div>
              <div class="w-2 h-2 bg-gray-300 rounded-full transition-all hover:bg-indigo-300"></div>
            </div>
          </div>
        </div>
      </section>
    `
    },
    // 5.2 Dynamic Live Product Grid
    {
        label: "Live Product Grid",
        category: "Dynamic Content",
        content: `
      <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
          <div class="flex items-center justify-between mb-10">
            <h2 class="text-3xl font-black text-gray-900 tracking-tight uppercase">Back-End Products</h2>
            <span class="px-4 py-1 bg-green-100 text-green-600 text-[10px] font-black rounded-full uppercase tracking-widest">Live Sync Alpha</span>
          </div>
          {{products}}
        </div>
      </section>
    `
    },
    // 5.3 Dynamic Featured Products
    {
        label: "Live Featured Slider",
        category: "Dynamic Content",
        content: `
      <section class="py-16 bg-gray-900 overflow-hidden">
        <div class="container mx-auto px-4">
          <div class="text-center mb-12">
            <h2 class="text-3xl font-black text-white tracking-tighter">FEATURED COLLECTIONS</h2>
            <p class="text-blue-400 font-bold text-sm tracking-widest mt-2 uppercase">Auto-populated from API</p>
          </div>
          {{featuredProducts}}
        </div>
      </section>
    `
    },
    // 6. Breadcrumb Design
    {
        label: "Breadcrumbs",
        category: "Breadcrumbs",
        content: `
      <nav class="flex py-4 bg-gray-50/50" aria-label="Breadcrumb">
        <div class="container mx-auto px-4 flex items-center space-x-1 md:space-x-3">
          <ol class="inline-flex items-center space-x-1 md:space-x-3">
            {{breadcrumbs}}
          </ol>
        </div>
      </nav>
    `
    },
    // 6.2 Centered Minimalist Breadcrumb
    {
        label: "Minimalist Breadcrumb",
        category: "Breadcrumbs",
        content: `
      <nav class="flex justify-center py-6 bg-transparent" aria-label="Breadcrumb">
        <ol class="flex items-center space-x-2 text-xs uppercase tracking-widest font-bold">
          {{breadcrumbs}}
        </ol>
      </nav>
    `
    },
    // 6.3 Solid Brand Accent Breadcrumb
    {
        label: "Brand Accent Breadcrumb",
        category: "Breadcrumbs",
        content: `
      <nav class="bg-blue-600 py-3" aria-label="Breadcrumb">
        <div class="container mx-auto px-4 flex items-center justify-between">
          <ol class="flex items-center space-x-2 text-sm font-medium text-blue-100">
            {{breadcrumbs}}
          </ol>
          <span class="text-[10px] text-blue-200 font-bold hidden sm:block">FREE SHIPPING ON ALL ORDERS OVER $100</span>
        </div>
      </nav>
    `
    },
    // 6.4 Bordered Pill Breadcrumb
    {
        label: "Pill Style Breadcrumb",
        category: "Breadcrumbs",
        content: `
      <nav class="py-8 bg-white" aria-label="Breadcrumb">
        <div class="container mx-auto px-4">
          <ol class="flex flex-wrap items-center gap-2">
            {{breadcrumbs}}
          </ol>
        </div>
      </nav>
    `
    },
    // 6.5 Dark Glassmorphism Breadcrumb
    {
        label: "Glass Breadcrumb",
        category: "Breadcrumbs",
        content: `
      <section class="py-12 bg-gray-900 relative">
        <div class="absolute inset-0 bg-gradient-to-r from-purple-900/40 to-blue-900/40 opacity-70"></div>
        <div class="container mx-auto px-4 relative z-10">
          <nav class="inline-flex px-5 py-3 text-white border border-white/10 rounded-2xl bg-white/5 backdrop-blur-xl shadow-2xl" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
              {{breadcrumbs}}
            </ol>
          </nav>
        </div>
      </section>
    `
    },
    // 7. Page Header (Jumbotron) Design
    {
        label: "Page Header",
        category: "Page Sections",
        content: `
      <section class="py-16 md:py-24 bg-gray-900 text-white relative overflow-hidden">
        <div class="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=1600&q=80')] bg-cover bg-center"></div>
        <div class="container mx-auto px-4 relative z-10 text-center">
          <h1 class="text-4xl md:text-6xl font-black mb-6 tracking-tight">Our Story</h1>
          <p class="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Discover the passion and purpose behind everything we do. We're committed to delivering excellence every single day.
          </p>
          <ol class="mt-8 flex justify-center items-center space-x-2 text-sm text-gray-400 font-medium">
             {{breadcrumbs}}
          </ol>
        </div>
      </section>
    `
    },
    // 7.2 Split Screen Header
    {
        label: "Split Image Header",
        category: "Page Sections",
        content: `
      <section class="bg-white overflow-hidden">
        <div class="flex flex-col md:flex-row">
          <div class="w-full md:w-1/2 p-12 md:p-24 flex flex-col justify-center">
            <h1 class="text-4xl md:text-5xl font-black text-gray-900 mb-6 leading-tight">Get in Touch <br><span class="text-blue-600">With Our Team</span></h1>
            <p class="text-gray-600 text-lg mb-8 max-w-md">Have questions? We're here to help you scaling your business to the next level with our expert support.</p>
            <ol class="flex items-center gap-4 text-sm font-bold text-gray-400">
               {{breadcrumbs}}
            </ol>
          </div>
          <div class="w-full md:w-1/2 h-[400px] md:h-auto bg-gray-100">
             <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&q=80" alt="Team" class="w-full h-full object-cover">
          </div>
        </div>
      </section>
    `
    },
    // 7.3 Gradient Wave Header
    {
        label: "Wave Header",
        category: "Page Sections",
        content: `
      <section class="pt-20 pb-0 bg-gradient-to-br from-indigo-700 via-purple-700 to-pink-600 relative overflow-hidden">
        <div class="container mx-auto px-4 text-center pb-20">
          <h1 class="text-5xl md:text-7xl font-black text-white mb-6 uppercase tracking-tight">Our Services</h1>
          <p class="text-white/80 text-lg md:text-xl max-w-xl mx-auto font-medium">Empowering your vision with cutting-edge technology and innovative solutions.</p>
        </div>
        <div class="w-full leading-[0]">
          <svg class="relative block w-full h-[150px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V95.8C58.05,117,133.27,125.13,203,111.45,251.52,101.9,294,83.05,321.39,56.44Z" class="fill-white"></path>
          </svg>
        </div>
      </section>
    `
    },
    // 7.4 Minimalist Center Header
    {
        label: "Minimalist Header",
        category: "Page Sections",
        content: `
      <section class="py-20 bg-white border-b border-gray-100">
        <div class="container mx-auto px-4 text-center">
          <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-8 transform rotate-3 hover:rotate-0 transition-transform shadow-xl">
             <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m4 0h1m-5 10h5m-5 4h5m-4-4h4m-4 4h4m-4-4h4m-4 4h4"></path></svg>
          </div>
          <h1 class="text-4xl md:text-5xl font-black text-gray-900 mb-4 tracking-tight uppercase">Company Profile</h1>
          <div class="flex items-center justify-center gap-2 text-xs font-black text-blue-600 tracking-[0.2em] mb-6">
             <span>ESTABLISHED 2024</span>
             <span class="w-1.5 h-1.5 bg-blue-600 rounded-full"></span>
             <span>CERTIFIED PARTNER</span>
          </div>
          <p class="text-gray-500 text-lg max-w-2xl mx-auto italic leading-relaxed">"Delivering value through integrity and innovation in every project we undertake."</p>
        </div>
      </section>
    `
    },
    // 7.5 Glass Overlay Header
    {
        label: "Glass Jumbotron",
        category: "Page Sections",
        content: `
      <section class="h-[500px] md:h-[600px] relative flex items-center justify-center overflow-hidden">
        <!-- Background Layer -->
        <div class="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1600&q=80" class="w-full h-full object-cover scale-105" alt="Building">
          <div class="absolute inset-0 bg-black/40 backdrop-blur-[2px]"></div>
        </div>
        
        <!-- Content Card -->
        <div class="container mx-auto px-4 relative z-10">
          <div class="max-w-3xl mx-auto bg-white/10 backdrop-blur-xl border border-white/20 p-10 md:p-16 rounded-[40px] shadow-2xl text-center">
             <h1 class="text-5xl md:text-7xl font-black text-white mb-6 drop-shadow-lg leading-tight">Join Our <br><span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">Mission</span></h1>
             <p class="text-white/80 text-lg md:text-xl mb-10 max-w-lg mx-auto">Be part of the future of digital commerce. We're looking for passionate individuals to join our global team.</p>
             <div class="flex flex-wrap justify-center gap-4">
                <button class="px-8 py-3 bg-white text-gray-900 rounded-full font-bold shadow-xl hover:bg-gray-900 hover:text-white transition-all transform hover:scale-105 uppercase text-sm tracking-widest">Apply Now</button>
                <button class="px-8 py-3 bg-transparent border border-white/50 text-white rounded-full font-bold hover:bg-white/10 transition-all uppercase text-sm tracking-widest">View Roles</button>
             </div>
          </div>
        </div>
      </section>
    `
    },
    // Legacy Blocks
    {
        label: "Top NavBar",
        category: "NavBar",
        content: `<nav class="bg-brand p-2"><div class="container flex items-center flex-wrap gap-y-2 gap-x-3 justify-center"><img class="w-5 md:w-6" src="/assets/img/gift.svg" alt="Gift Box" loading="lazy"><p class="text-white text-[12px] md:text-xs">Special Offer: 50% off - limited time only</p><button class="btn btn-outline !border-border btn-sm !text-[12px] !py-1.5">Buy Now</button></div></nav>`
    },
    {
        label: "Hero Banner One",
        category: "Hero Banner",
        content: `<div class="flex items-center justify-center h-full min-h-[60vh] lg:min-h-[90vh] relative w-full bg-[url('/assets/img/banner/1.jpg')] bg-cover bg-center">
        <div class="absolute inset-0 bg-black/50"></div>
        <div class="container relative flex flex-col justify-center items-center gap-y-6 text-center">
            <h1 class="text-white text-2xl sm:text-3xl md:text-4xl lg:text-5xl 2xl:text-6xl font-medium sm:leading-12 lg:leading-14 2xl:leading-[70px]">
                Discover Amazing Products, <br class="hidden md:block" /> Best Deals for You
            </h1>
            <p class="font-inter text-white text-sm md:text-base font-light tracking-wider">
                Explore our curated collection and find what you love
            </p>
            <button class="btn btn-brand text-white !px-12 rounded-lg">
                Shop Now
            </button>
        </div>
    </div>`
    }
];
const registerEcommerceBlocks = (editor)=>{
    const blockManager = editor.BlockManager;
    customEcommerceBlocks.forEach((block)=>{
        blockManager.add(block.label.toLowerCase().replace(/\s+/g, '-'), {
            label: block.label,
            category: block.category,
            content: block.content,
            attributes: {
                class: 'fa fa-cube'
            }
        });
    });
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/services/pageSettings.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Page Settings Service
 * 
 * Manages page settings and routing configuration for storefronts.
 * Handles both static and dynamic content pages.
 */ __turbopack_context__.s([
    "createDefaultPageSettings",
    ()=>createDefaultPageSettings,
    "deletePageSetting",
    ()=>deletePageSetting,
    "ensureAllPagesHaveSettings",
    ()=>ensureAllPagesHaveSettings,
    "getPageContent",
    ()=>getPageContent,
    "getPageSetting",
    ()=>getPageSetting,
    "getPageSettingByRoute",
    ()=>getPageSettingByRoute,
    "getPageSettingsByStorefront",
    ()=>getPageSettingsByStorefront,
    "savePageSetting",
    ()=>savePageSetting,
    "updatePageSetting",
    ()=>updatePageSetting
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm2017.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/firebaseConfig.ts [app-client] (ecmascript)");
;
;
const COLLECTION_NAME = "page_settings";
async function savePageSetting(setting) {
    try {
        const id = `${setting.userId}_${setting.storefrontId}_${setting.pageType}`;
        const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
        const pageSetting = {
            ...setting,
            id,
            createdAt: new Date(),
            updatedAt: new Date()
        };
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setDoc"])(pageSettingRef, pageSetting);
        return id;
    } catch (error) {
        console.error("Error saving page setting:", error);
        throw error;
    }
}
async function getPageSetting(storefrontId, pageType, userId) {
    try {
        // If userId is provided, use the new ID format. Otherwise, fallback to the old one or query.
        if (userId) {
            const id = `${userId}_${storefrontId}_${pageType}`;
            const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
            const pageSettingDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDoc"])(pageSettingRef);
            if (pageSettingDoc.exists()) {
                return pageSettingDoc.data();
            }
        }
        // Fallback search by storefrontId and pageType if userId is not known or for backward compatibility
        const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("storefrontId", "==", storefrontId), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("pageType", "==", pageType));
        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
        if (!querySnapshot.empty) {
            return querySnapshot.docs[0].data();
        }
        return null;
    } catch (error) {
        console.error("Error getting page setting:", error);
        return null;
    }
}
async function getPageSettingsByStorefront(storefrontId, onlyEnabled = true, userId) {
    try {
        let q;
        const conditions = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("storefrontId", "==", storefrontId)
        ];
        if (userId) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("userId", "==", userId));
        }
        if (onlyEnabled) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("settings.enabled", "==", true));
        }
        q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME), ...conditions);
        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
        const settings = [];
        querySnapshot.forEach((doc)=>{
            settings.push(doc.data());
        });
        return settings;
    } catch (error) {
        console.error("Error getting page settings:", error);
        return [];
    }
}
async function getPageSettingByRoute(storefrontId, route, onlyEnabled = true, userId) {
    try {
        let q;
        const conditions = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("storefrontId", "==", storefrontId),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("route", "==", route)
        ];
        if (userId) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("userId", "==", userId));
        }
        if (onlyEnabled) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["where"])("settings.enabled", "==", true));
        }
        q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME), ...conditions);
        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
        if (!querySnapshot.empty) {
            return querySnapshot.docs[0].data();
        }
        return null;
    } catch (error) {
        console.error("Error getting page setting by route:", error);
        return null;
    }
}
async function updatePageSetting(id, updates) {
    try {
        const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updateDoc"])(pageSettingRef, {
            ...updates,
            updatedAt: new Date()
        });
    } catch (error) {
        console.error("Error updating page setting:", error);
        throw error;
    }
}
async function deletePageSetting(id) {
    try {
        const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteDoc"])(pageSettingRef);
    } catch (error) {
        console.error("Error deleting page setting:", error);
        throw error;
    }
}
async function getPageContent(pageSetting) {
    try {
        if (pageSetting.contentType === 'static') {
            return pageSetting.dataSource?.staticData || null;
        }
        if (pageSetting.contentType === 'dynamic') {
            const { dataSource } = pageSetting;
            if (dataSource?.type === 'firebase' && dataSource.collection) {
                // Fetch from Firebase collection
                const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["db"], dataSource.collection));
                const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
                const data = [];
                querySnapshot.forEach((doc)=>{
                    data.push({
                        id: doc.id,
                        ...doc.data()
                    });
                });
                return data;
            }
            if (dataSource?.type === 'api' && dataSource.apiEndpoint) {
                // Fetch from API
                const response = await fetch(dataSource.apiEndpoint);
                if (response.ok) {
                    return await response.json();
                }
            }
        }
        return null;
    } catch (error) {
        console.error("Error getting page content:", error);
        return null;
    }
}
async function createDefaultPageSettings(storefrontId, userId) {
    const defaultPages = [
        {
            pageType: 'testimonial',
            route: '/testimonials',
            contentType: 'dynamic',
            parentId: null,
            order: 1,
            dataSource: {
                type: 'firebase',
                collection: `testimonials_${storefrontId}`
            },
            settings: {
                enabled: false,
                showInMenu: false,
                showInFooter: true,
                metaTitle: 'Testimonials',
                metaDescription: 'Customer testimonials and reviews'
            }
        },
        {
            pageType: 'about',
            route: '/about',
            contentType: 'static',
            parentId: null,
            order: 2,
            dataSource: {
                type: 'static',
                staticData: {
                    title: 'About Us',
                    content: 'Welcome to our store...'
                }
            },
            settings: {
                enabled: false,
                showInMenu: true,
                showInFooter: true,
                metaTitle: 'About Us',
                metaDescription: 'Learn more about our company'
            }
        },
        {
            pageType: 'contact',
            route: '/contact',
            contentType: 'static',
            parentId: null,
            order: 3,
            dataSource: {
                type: 'static',
                staticData: {
                    title: 'Contact Us',
                    content: 'Get in touch with us...'
                }
            },
            settings: {
                enabled: false,
                showInMenu: true,
                showInFooter: true,
                metaTitle: 'Contact Us',
                metaDescription: 'Get in touch with us'
            }
        }
    ];
    for (const page of defaultPages){
        try {
            await savePageSetting({
                storefrontId,
                userId,
                ...page
            });
        } catch (error) {
            console.error(`Error creating default page ${page.pageType}:`, error);
        }
    }
}
async function ensureAllPagesHaveSettings(storefrontId, userId, availablePageTypes) {
    for (const pageType of availablePageTypes){
        try {
            const existing = await getPageSetting(storefrontId, pageType);
            if (!existing) {
                console.log(`Creating missing setting for page: ${pageType}`);
                // Map common routes
                let route = `/${pageType}`;
                if (pageType === 'home') route = '/';
                await savePageSetting({
                    storefrontId,
                    userId,
                    pageType,
                    parentId: null,
                    order: 0,
                    route,
                    contentType: 'static',
                    settings: {
                        enabled: true,
                        showInMenu: pageType === 'home' ? false : true,
                        showInFooter: true,
                        metaTitle: pageType.charAt(0).toUpperCase() + pageType.slice(1)
                    }
                });
            }
        } catch (error) {
            console.error(`Error ensuring setting for ${pageType}:`, error);
        }
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/editor/PageEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PageEditor",
    ()=>PageEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/contexts/AuthContext.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$firebase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/firebase.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ui/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__ = __turbopack_context__.i("[project]/components/ui/button.tsx [app-client] (ecmascript) <export default as Button>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/ArrowLeftIcon.js [app-client] (ecmascript) <export default as ArrowLeftIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$FolderIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/FolderIcon.js [app-client] (ecmascript) <export default as FolderIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/DocumentIcon.js [app-client] (ecmascript) <export default as DocumentIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CheckCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/CheckCircleIcon.js [app-client] (ecmascript) <export default as CheckCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircleIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/XCircleIcon.js [app-client] (ecmascript) <export default as XCircleIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CloudArrowUpIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CloudArrowUpIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/CloudArrowUpIcon.js [app-client] (ecmascript) <export default as CloudArrowUpIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__ = __turbopack_context__.i("[project]/node_modules/@heroicons/react/24/outline/esm/Cog6ToothIcon.js [app-client] (ecmascript) <export default as Cog6ToothIcon>");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$editor$2f$customBlocks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/editor/customBlocks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$editor$2f$ecommerceBlocks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/editor/ecommerceBlocks.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/pageSettings.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
/**
 * Recursive Menu Item for hierarchical drag and drop
 */ const NestedMenuItem = ({ setting, allSettings, onToggle, onMove, depth = 0 })=>{
    _s();
    const [isOver, setIsOver] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const children = allSettings.filter((s)=>s.parentId === setting.id).sort((a, b)=>a.order - b.order);
    const handleDragStart = (e)=>{
        e.dataTransfer.setData("text/plain", setting.id);
        e.dataTransfer.effectAllowed = "move";
        // Set a class on the body to style the dragged item globally if needed
        document.body.classList.add("dragging-menu-item");
    };
    const handleDragOver = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const rect = e.currentTarget.getBoundingClientRect();
        const y = e.clientY - rect.top;
        if (y < rect.height * 0.25) {
            setIsOver('before');
        } else if (y > rect.height * 0.75) {
            setIsOver('after');
        } else {
            setIsOver('inside');
        }
    };
    const handleDrop = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        const draggedId = e.dataTransfer.getData("text/plain");
        if (draggedId === setting.id) {
            setIsOver(null);
            return;
        }
        if (isOver) {
            onMove(draggedId, setting.id, isOver);
        }
        setIsOver(null);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                draggable: true,
                onDragStart: handleDragStart,
                onDragOver: handleDragOver,
                onDragLeave: ()=>setIsOver(null),
                onDrop: handleDrop,
                onDragEnd: ()=>document.body.classList.remove("dragging-menu-item"),
                className: `relative p-3 rounded-xl border transition-all cursor-move group ${isOver === 'inside' ? 'bg-blue-50 border-blue-400 scale-[1.02] shadow-md z-10' : isOver === 'before' ? 'border-t-blue-500 border-t-2 bg-gray-50' : isOver === 'after' ? 'border-b-blue-500 border-b-2 bg-gray-50' : 'bg-white border-gray-100 hover:border-blue-200 hover:shadow-sm'}`,
                style: {
                    marginLeft: `${depth * 16}px`
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "p-1.5 bg-gray-50 rounded-lg text-gray-400 group-hover:text-blue-500 transition-colors",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-4 h-4",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M4 6h16M4 12h16M4 18h16"
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 107,
                                                columnNumber: 17
                                            }, ("TURBOPACK compile-time value", void 0))
                                        }, void 0, false, {
                                            fileName: "[project]/components/editor/PageEditor.tsx",
                                            lineNumber: 106,
                                            columnNumber: 15
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 105,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-xs font-black text-gray-900 uppercase tracking-tighter block",
                                                children: setting.settings.metaTitle || setting.pageType
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 111,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-[10px] text-gray-400 font-mono tracking-tighter",
                                                children: setting.route
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 112,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 110,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 104,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>onToggle(setting.id, 'showInMenu', !setting.settings.showInMenu),
                                        className: `px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest transition-all ${setting.settings.showInMenu ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-400 hover:bg-gray-200'}`,
                                        title: "Show in Menu",
                                        children: setting.settings.showInMenu ? 'In Menu' : 'Hidden'
                                    }, void 0, false, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 116,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: `w-2 h-2 rounded-full ${setting.settings.enabled ? 'bg-green-500' : 'bg-gray-300 shadow-inner'}`,
                                        title: setting.settings.enabled ? 'Live' : 'Draft'
                                    }, void 0, false, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 124,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 115,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 103,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    isOver === 'inside' && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute -bottom-2 right-4 bg-blue-600 text-white text-[8px] font-black uppercase px-2 py-0.5 rounded-full shadow-lg animate-bounce",
                        children: "Make Child"
                    }, void 0, false, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 130,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/editor/PageEditor.tsx",
                lineNumber: 89,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            children.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-1",
                children: children.map((child)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedMenuItem, {
                        setting: child,
                        allSettings: allSettings,
                        onToggle: onToggle,
                        onMove: onMove,
                        depth: depth + 1
                    }, child.id, false, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 140,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0)))
            }, void 0, false, {
                fileName: "[project]/components/editor/PageEditor.tsx",
                lineNumber: 138,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/editor/PageEditor.tsx",
        lineNumber: 88,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s(NestedMenuItem, "6pPFwQ39jmJK4Dz6/0CHqmPB2kQ=");
_c = NestedMenuItem;
const PageEditor = ({ subdomain, initialPage = "homepage" })=>{
    _s1();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const { user, isAuthenticated } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    const { showSuccess, showError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"])();
    const editorRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const containerRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [editor, setEditor] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [siteData, setSiteData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [currentPage, setCurrentPage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(initialPage);
    const [rightPanelOpen, setRightPanelOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("blocks");
    const [pageSettings, setPageSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [settingsLoading, setSettingsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Drag and drop state for menu reordering
    const [dragId, setDragId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Re-render blocks when the tab becomes active
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PageEditor.useEffect": ()=>{
            if (editor && activeTab === "blocks") {
                setTimeout({
                    "PageEditor.useEffect": ()=>{
                        editor.BlockManager.render();
                        const bmContainer = document.getElementById('blocks-container');
                        if (bmContainer) {
                            const firstCat = bmContainer.querySelector('.gjs-category');
                            if (firstCat && !firstCat.classList.contains('gjs-open')) {
                                firstCat.classList.add('gjs-open');
                            }
                        }
                    }
                }["PageEditor.useEffect"], 100);
            }
        }
    }["PageEditor.useEffect"], [
        activeTab,
        editor
    ]);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [retryCount, setRetryCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    // Load site data from Firebase
    const loadSiteData = async (isRetry = false)=>{
        if (!user || !isAuthenticated) {
            setError("Not authenticated. Please sign in to access the editor.");
            setLoading(false);
            // Don't redirect - let user see the error and navigate manually
            return;
        }
        try {
            setLoading(true);
            setError(null);
            console.log("🔄 Loading site data from Firebase...", {
                userId: user.user_id || user.uid,
                isRetry
            });
            const site = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$firebase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadGeneratedSiteFromFirebase"])(user);
            if (!site) {
                // Check if it's likely a Firebase offline issue vs. no storefront
                const isLikelyOffline = retryCount === 0; // First attempt suggests offline
                if (isLikelyOffline) {
                    setError("Unable to connect to Firebase. Please check your internet connection.");
                } else {
                    setError("No storefront found. Please create a storefront first.");
                }
                setLoading(false);
                // Don't redirect immediately - let user see the error and retry option
                return;
            }
            console.log("✅ Site data loaded:", {
                companyName: site.companyName,
                subdomain: site.subdomain,
                pagesCount: Object.keys(site.pages || {}).length
            });
            setSiteData(site);
            setError(null);
            setLoading(false);
            // Set initial page if provided
            if (initialPage && site.pages[initialPage]) {
                setCurrentPage(initialPage);
            } else if (site.pages && Object.keys(site.pages).length > 0) {
                // Use first available page if initialPage not found
                const firstPage = Object.keys(site.pages)[0];
                setCurrentPage(firstPage);
            }
        } catch (error) {
            console.error("❌ Error loading site:", error);
            setError(error.message || "Failed to load storefront");
            showError("Failed to load storefront. Please try again.");
            setLoading(false);
        }
    };
    // Load page settings
    const loadPageSettings = async ()=>{
        if (!subdomain || !user) return;
        try {
            setSettingsLoading(true);
            // Pass false to include disabled pages
            let settings = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPageSettingsByStorefront"])(subdomain, false);
            // Ensure all actual pages have settings
            if (siteData) {
                const availablePages = Object.keys(siteData.pages);
                const userId = user.user_id?.toString() || user.uid || "";
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureAllPagesHaveSettings"])(subdomain, userId, availablePages);
                // Refresh settings after sync
                settings = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getPageSettingsByStorefront"])(subdomain, false);
            }
            setPageSettings(settings);
        } catch (error) {
            console.error("Error loading page settings:", error);
        } finally{
            setSettingsLoading(false);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PageEditor.useEffect": ()=>{
            loadSiteData();
            loadPageSettings();
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["PageEditor.useEffect"], [
        user,
        isAuthenticated
    ]);
    // Initialize GrapesJS editor
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PageEditor.useEffect": ()=>{
            // Wait for siteData to load
            if (!siteData || loading) {
                return;
            }
            let editorInstance = null;
            let isMounted = true;
            // Use a small delay to ensure DOM is ready and container ref is set
            const initTimer = setTimeout({
                "PageEditor.useEffect.initTimer": ()=>{
                    // Check if container exists after delay
                    if (!containerRef.current) {
                        console.error("Container ref is null - editor container not found in DOM");
                        showError("Editor container not found. Please refresh the page.");
                        return;
                    }
                    const container = containerRef.current;
                    // Import GrapesJS modules dynamically
                    Promise.all([
                        __turbopack_context__.A("[project]/node_modules/grapesjs/dist/grapes.mjs [app-client] (ecmascript, async loader)"),
                        __turbopack_context__.A("[project]/node_modules/grapesjs-preset-webpage/dist/index.js [app-client] (ecmascript, async loader)"),
                        __turbopack_context__.A("[project]/node_modules/grapesjs-blocks-basic/dist/index.js [app-client] (ecmascript, async loader)")
                    ]).then({
                        "PageEditor.useEffect.initTimer": ([GrapesJS, gjsPresetWebpage, gjsBlocksBasic])=>{
                            // Check if component is still mounted and container still exists
                            if (!isMounted || !containerRef.current) {
                                console.warn("Component unmounted or container removed before GrapesJS initialization");
                                return;
                            }
                            try {
                                editorInstance = GrapesJS.default.init({
                                    container: containerRef.current,
                                    height: "100%",
                                    width: "100%",
                                    storageManager: false,
                                    fromElement: true,
                                    canvas: {
                                        styles: [
                                            "https://cdn.jsdelivr.net/npm/tailwindcss@3.4.1/dist/tailwind.min.css",
                                            "https://fold-html.netlify.app/assets/css/global.css"
                                        ],
                                        scripts: [
                                            "https://cdn.tailwindcss.com"
                                        ]
                                    },
                                    plugins: [
                                        gjsPresetWebpage.default,
                                        gjsBlocksBasic.default
                                    ],
                                    pluginsOpts: {
                                        [gjsPresetWebpage.default]: {
                                            modalImportTitle: "Import Template",
                                            modalImportLabel: "<div style='margin-bottom: 10px; font-size: 13px;'>Paste here your HTML/CSS and click Import</div>",
                                            modalImportContent: {
                                                "PageEditor.useEffect.initTimer": (editor)=>{
                                                    const textarea = document.createElement("textarea");
                                                    textarea.value = `<div class="container mx-auto px-4 py-8">
  <h1 class="text-3xl font-bold mb-4">Your Content</h1>
  <p class="text-gray-600">Start editing...</p>
</div>`;
                                                    return textarea;
                                                }
                                            }["PageEditor.useEffect.initTimer"]
                                        }
                                    },
                                    blockManager: {
                                    },
                                    layerManager: {
                                        appendTo: "#layers-container"
                                    },
                                    styleManager: {
                                        appendTo: "#styles-container",
                                        sectors: [
                                            {
                                                name: "Background",
                                                open: true,
                                                properties: [
                                                    {
                                                        name: "Background Image",
                                                        property: "background-image"
                                                    },
                                                    {
                                                        name: "Size",
                                                        property: "background-size"
                                                    },
                                                    {
                                                        name: "Position",
                                                        property: "background-position"
                                                    },
                                                    {
                                                        name: "Repeat",
                                                        property: "background-repeat"
                                                    },
                                                    {
                                                        name: "Attachment",
                                                        property: "background-attachment"
                                                    }
                                                ]
                                            },
                                            {
                                                name: "Dimensions",
                                                open: false,
                                                buildProps: [
                                                    "width",
                                                    "height",
                                                    "min-height",
                                                    "padding",
                                                    "margin"
                                                ]
                                            },
                                            {
                                                name: "Typography",
                                                open: false,
                                                buildProps: [
                                                    "font-family",
                                                    "font-size",
                                                    "font-weight",
                                                    "letter-spacing",
                                                    "color",
                                                    "line-height",
                                                    "text-align"
                                                ]
                                            },
                                            {
                                                name: "Tailwind Classes",
                                                open: true,
                                                buildProps: [
                                                    "class"
                                                ]
                                            }
                                        ]
                                    },
                                    deviceManager: {
                                        devices: [
                                            {
                                                name: "Desktop",
                                                width: ""
                                            },
                                            {
                                                name: "Tablet",
                                                width: "768px",
                                                widthMedia: "992px"
                                            },
                                            {
                                                name: "Mobile",
                                                width: "320px",
                                                widthMedia: "768px"
                                            }
                                        ]
                                    }
                                });
                                // Register custom blocks
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$editor$2f$customBlocks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerCustomBlocks"])(editorInstance);
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$editor$2f$ecommerceBlocks$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["registerEcommerceBlocks"])(editorInstance);
                                // Load initial page content
                                if (siteData.pages[currentPage]) {
                                    const page = siteData.pages[currentPage];
                                    editorInstance.setComponents(page.html);
                                    editorInstance.setStyle(page.css);
                                }
                                // Listen for editor updates to auto-save
                                editorInstance.on("update", {
                                    "PageEditor.useEffect.initTimer": ()=>{
                                        if (!siteData || !currentPage) return;
                                    // Auto-save logic could go here
                                    }
                                }["PageEditor.useEffect.initTimer"]);
                                // Handle collapsible categories
                                editorInstance.on('load', {
                                    "PageEditor.useEffect.initTimer": ()=>{
                                        const categories = editorInstance.BlockManager.getCategories();
                                        categories.each({
                                            "PageEditor.useEffect.initTimer": (cat, index)=>{
                                                cat.set('open', index === 0); // Open the first category by default
                                            }
                                        }["PageEditor.useEffect.initTimer"]);
                                    }
                                }["PageEditor.useEffect.initTimer"]);
                                // Add click listener and initial render
                                setTimeout({
                                    "PageEditor.useEffect.initTimer": ()=>{
                                        const bmContainer = document.getElementById('blocks-container');
                                        if (bmContainer && editorInstance) {
                                            const bm = editorInstance.BlockManager;
                                            const bmView = bm.getContainer();
                                            if (!bmContainer.contains(bmView)) {
                                                bmContainer.appendChild(bmView);
                                            }
                                            bm.render();
                                            console.log("🛠️ Block Manager initialized and rendered");
                                            // Force first category open visually
                                            const firstCat = bmContainer.querySelector('.gjs-category');
                                            if (firstCat) firstCat.classList.add('gjs-open');
                                            // Delegate click events for collapsibility
                                            if (!bmContainer.hasAttribute('data-listener-attached')) {
                                                bmContainer.addEventListener('click', {
                                                    "PageEditor.useEffect.initTimer": (e)=>{
                                                        const title = e.target.closest('.gjs-category-title');
                                                        if (title) {
                                                            const category = title.closest('.gjs-category');
                                                            if (category) {
                                                                category.classList.toggle('gjs-open');
                                                            }
                                                        }
                                                    }
                                                }["PageEditor.useEffect.initTimer"]);
                                                bmContainer.setAttribute('data-listener-attached', 'true');
                                            }
                                        }
                                    }
                                }["PageEditor.useEffect.initTimer"], 1000);
                                if (isMounted) {
                                    setEditor(editorInstance);
                                    editorRef.current = editorInstance;
                                }
                            } catch (initError) {
                                console.error("Error initializing GrapesJS:", initError);
                                if (isMounted) {
                                    const errorMessage = initError.message || "Failed to initialize editor";
                                    if (errorMessage.includes("Content Security Policy") || errorMessage.includes("eval")) {
                                        showError("Editor requires additional permissions. Please check browser settings or contact support.");
                                    } else {
                                        showError("Failed to initialize editor. Redirecting to dashboard...");
                                        setTimeout({
                                            "PageEditor.useEffect.initTimer": ()=>{
                                                router.push("/dashboard");
                                            }
                                        }["PageEditor.useEffect.initTimer"], 2000);
                                    }
                                }
                            }
                        }
                    }["PageEditor.useEffect.initTimer"]).catch({
                        "PageEditor.useEffect.initTimer": (error)=>{
                            console.error("Error loading GrapesJS modules:", error);
                            if (isMounted) {
                                showError("Failed to load editor. Redirecting to dashboard...");
                                setTimeout({
                                    "PageEditor.useEffect.initTimer": ()=>{
                                        router.push("/dashboard");
                                    }
                                }["PageEditor.useEffect.initTimer"], 2000);
                            }
                        }
                    }["PageEditor.useEffect.initTimer"]);
                }
            }["PageEditor.useEffect.initTimer"], 100); // Small delay to ensure DOM is ready
            return ({
                "PageEditor.useEffect": ()=>{
                    isMounted = false;
                    if (initTimer) {
                        clearTimeout(initTimer);
                    }
                    if (editorRef.current) {
                        try {
                            editorRef.current.destroy();
                        } catch (error) {
                            console.error("Error destroying editor:", error);
                        }
                        editorRef.current = null;
                        setEditor(null);
                    }
                }
            })["PageEditor.useEffect"];
        }
    }["PageEditor.useEffect"], [
        siteData,
        loading,
        showError
    ]);
    // Handle page change
    const handlePageChange = (pageName)=>{
        if (!editor || !siteData || !siteData.pages[pageName]) return;
        // Save current page before switching
        if (siteData.pages[currentPage]) {
            const html = editor.getHtml();
            const css = editor.getCss();
            setSiteData({
                ...siteData,
                pages: {
                    ...siteData.pages,
                    [currentPage]: {
                        ...siteData.pages[currentPage],
                        html,
                        css
                    }
                }
            });
        }
        // Load new page
        const newPage = siteData.pages[pageName];
        editor.setComponents(newPage.html);
        editor.setStyle(newPage.css);
        setCurrentPage(pageName);
        // Refresh block manager state if needed
        setTimeout(()=>{
            editor.BlockManager.render();
        }, 100);
    };
    // Save page to Firebase
    const handleSave = async ()=>{
        if (!editor || !siteData || !user) return;
        try {
            setSaving(true);
            // Get current HTML and CSS
            const html = editor.getHtml();
            const css = editor.getCss();
            // Update site data
            const updatedSite = {
                ...siteData,
                pages: {
                    ...siteData.pages,
                    [currentPage]: {
                        ...siteData.pages[currentPage],
                        html,
                        css
                    }
                }
            };
            // Save to Firebase
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$firebase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["saveGeneratedSiteToFirebase"])(updatedSite, user);
            setSiteData(updatedSite);
            showSuccess("Page saved successfully!");
        } catch (error) {
            console.error("Error saving page:", error);
            showError("Failed to save page");
        } finally{
            setSaving(false);
        }
    };
    // Toggle page setting
    const handleToggleSetting = async (id, field, value)=>{
        try {
            const current = pageSettings.find((s)=>s.id === id);
            if (!current) return;
            const updatedSettings = {
                ...current.settings,
                [field]: value
            };
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updatePageSetting"])(id, {
                settings: updatedSettings
            });
            // Update local state
            setPageSettings((prev)=>prev.map((s)=>s.id === id ? {
                        ...s,
                        settings: updatedSettings
                    } : s));
            showSuccess("Setting updated!");
        } catch (error) {
            console.error("Error updating setting:", error);
            showError("Failed to update setting");
        }
    };
    if (loading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center h-screen bg-gray-50",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"
                }, void 0, false, {
                    fileName: "[project]/components/editor/PageEditor.tsx",
                    lineNumber: 606,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-gray-600",
                    children: "Loading editor..."
                }, void 0, false, {
                    fileName: "[project]/components/editor/PageEditor.tsx",
                    lineNumber: 607,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-sm text-gray-500 mt-2",
                    children: "Fetching storefront data..."
                }, void 0, false, {
                    fileName: "[project]/components/editor/PageEditor.tsx",
                    lineNumber: 608,
                    columnNumber: 9
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/components/editor/PageEditor.tsx",
            lineNumber: 605,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    if (!siteData) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col items-center justify-center h-screen bg-gray-50 px-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-w-md w-full bg-white rounded-lg shadow-lg p-6 text-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$XCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__XCircleIcon$3e$__["XCircleIcon"], {
                            className: "w-16 h-16 text-red-500 mx-auto"
                        }, void 0, false, {
                            fileName: "[project]/components/editor/PageEditor.tsx",
                            lineNumber: 618,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 617,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold text-gray-900 mb-2",
                        children: error || "Unable to Load Editor"
                    }, void 0, false, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 620,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-gray-600 mb-6",
                        children: error?.includes("connect") || error?.includes("offline") || error?.includes("Unable to connect") ? "Unable to connect to Firebase. This is usually due to network connectivity issues. Please check your internet connection and try again." : error ? error : "No storefront found. Please create a storefront first."
                    }, void 0, false, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 623,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col sm:flex-row gap-3 justify-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: ()=>{
                                    setRetryCount((prev)=>prev + 1);
                                    loadSiteData(true);
                                },
                                className: "bg-blue-600 hover:bg-blue-700 text-white",
                                loading: loading,
                                children: retryCount > 0 ? `Retry (${retryCount})` : "Retry"
                            }, void 0, false, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 631,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: ()=>router.push("/dashboard"),
                                variant: "bordered",
                                className: "border-gray-300 text-gray-700 hover:bg-gray-50",
                                children: "Go to Dashboard"
                            }, void 0, false, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 641,
                                columnNumber: 13
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 630,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-4",
                        children: "If this persists, check your internet connection and Firebase configuration."
                    }, void 0, false, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 650,
                        columnNumber: 13
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/editor/PageEditor.tsx",
                lineNumber: 616,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/components/editor/PageEditor.tsx",
            lineNumber: 615,
            columnNumber: 7
        }, ("TURBOPACK compile-time value", void 0));
    }
    const pages = Object.keys(siteData.pages || {});
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "h-screen flex flex-col bg-gray-100",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
                children: `
        .gjs-blocks-c, .gjs-sm-c, .gjs-layers-c {
          display: grid !important;
          grid-template-columns: repeat(3, 1fr) !important;
          gap: 8px !important;
          padding: 10px !important;
          background: transparent !important;
        }
        #blocks-container, #styles-container, #layers-container {
          min-height: 100% !important;
          padding-bottom: 40px !important;
        }
        /* Style Manager and Layers should be single column, only Blocks is 3-column */
        .gjs-sm-c, .gjs-layers-c {
          display: block !important;
        }
        .gjs-block {
          width: auto !important;
          min-height: 80px !important;
          color: white !important;
          border: 1px solid #efefef !important;
          padding: 8px !important;
          margin: 0 !important;
          display: flex !important;
          flex-direction: column !important;
          align-items: center !important;
          justify-content: center !important;
          transition: all 0.2s ease !important;
          cursor: pointer !important;
          background: rgba(255, 255, 255, 0.1) !important;
          border-radius: 4px !important;
        }
        .gjs-block:hover {
          border-color: #6366f1 !important;
          background: rgba(99, 102, 241, 0.2) !important;
          transform: translateY(-1px) !important;
        }
        .gjs-block-label, .gjs-block svg {
          color: white !important;
          fill: white !important;
          font-size: 13px !important;
          text-align: center !important;
          word-break: break-all !important;
          font-weight: 600 !important;
        }
        /* SECTION TITLES: Bold and White */
        .gjs-category-title, .gjs-sm-sector-title, .gjs-sm-title {
          background-color: #111827 !important;
          color: white !important;
          font-weight: 800 !important;
          padding: 10px 12px !important;
          margin: 12px 0 6px 0 !important;
          font-size: 12px !important;
          text-transform: uppercase !important;
          letter-spacing: 0.05em !important;
          border-bottom: 2px solid rgba(255,255,255,0.2) !important;
          display: flex !important;
          align-items: center !important;
          justify-content: space-between !important;
          cursor: pointer !important;
        }
        .gjs-category-title::after {
          content: '▼';
          font-size: 8px;
          transition: transform 0.3s ease;
        }
        .gjs-category.gjs-open .gjs-category-title::after {
          transform: rotate(-180deg);
        }
        /* Ensure categories are visible if they have the open class */
        .gjs-category:not(.gjs-open) .gjs-blocks-c {
          display: none !important;
        }
        .gjs-category.gjs-open .gjs-blocks-c {
          display: grid !important;
        }
        .gjs-blocks-c {
          transition: all 0.3s ease-out !important;
        }
        /* Style Manager Inner Labels */
        .gjs-sm-label, .gjs-sm-field, .gjs-sm-property {
          color: #e5e7eb !important;
        }
      `
            }, void 0, false, {
                fileName: "[project]/components/editor/PageEditor.tsx",
                lineNumber: 663,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-gradient-to-r from-white via-blue-50 to-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: ()=>router.push("/dashboard"),
                                className: "flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white border-none shadow-sm transition-all",
                                size: "sm",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$ArrowLeftIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__ArrowLeftIcon$3e$__["ArrowLeftIcon"], {
                                        className: "w-4 h-4 font-bold"
                                    }, void 0, false, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 755,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    "Dashboard"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 750,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "text-lg font-semibold text-gray-800",
                                children: [
                                    "Editing: ",
                                    siteData.companyName
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 759,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center bg-gray-100/50 p-1 rounded-xl border border-gray-200",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: ()=>{
                                            setActiveTab("pages");
                                            setRightPanelOpen(true);
                                        },
                                        variant: "bordered",
                                        size: "sm",
                                        className: `min-w-[100px] flex items-center justify-center gap-2 transition-all rounded-lg border-none ${activeTab === "pages" && rightPanelOpen ? "bg-white text-orange-600 shadow-sm" : "text-gray-500 hover:text-gray-700 hover:bg-white/50"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$FolderIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderIcon$3e$__["FolderIcon"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 774,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Pages"
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 775,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 764,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: ()=>{
                                            setActiveTab("blocks");
                                            setRightPanelOpen(true);
                                        },
                                        variant: "bordered",
                                        size: "sm",
                                        className: `min-w-[100px] flex items-center justify-center gap-2 transition-all rounded-lg border-none ${activeTab === "blocks" && rightPanelOpen ? "bg-white text-purple-600 shadow-sm" : "text-gray-500 hover:text-gray-700 hover:bg-white/50"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                className: "w-4 h-4",
                                                fill: "none",
                                                stroke: "currentColor",
                                                viewBox: "0 0 24 24",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                    strokeLinecap: "round",
                                                    strokeLinejoin: "round",
                                                    strokeWidth: 2,
                                                    d: "M4 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1V5z"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/editor/PageEditor.tsx",
                                                    lineNumber: 789,
                                                    columnNumber: 17
                                                }, ("TURBOPACK compile-time value", void 0))
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 788,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Blocks"
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 791,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 778,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: ()=>{
                                            setActiveTab("settings");
                                            setRightPanelOpen(true);
                                        },
                                        variant: "bordered",
                                        size: "sm",
                                        className: `min-w-[100px] flex items-center justify-center gap-2 transition-all rounded-lg border-none ${activeTab === "settings" && rightPanelOpen ? "bg-white text-blue-600 shadow-sm" : "text-gray-500 hover:text-gray-700 hover:bg-white/50"}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__["Cog6ToothIcon"], {
                                                className: "w-4 h-4"
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 804,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Settings"
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 805,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 794,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 763,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 749,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-sm text-gray-600",
                                children: [
                                    "Current: ",
                                    currentPage
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 811,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                onClick: handleSave,
                                isDisabled: saving,
                                className: "bg-primary-500 hover:bg-primary-600 text-white",
                                children: saving ? "Saving..." : "Save Page"
                            }, void 0, false, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 814,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 810,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/editor/PageEditor.tsx",
                lineNumber: 748,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex-1 flex overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex-1 relative flex flex-col h-full overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                ref: containerRef,
                                className: "flex-1 bg-white"
                            }, void 0, false, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 827,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute bottom-8 right-8 z-40 group",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "absolute -top-12 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs py-1.5 px-3 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none",
                                        children: "Save changes to Cloud"
                                    }, void 0, false, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 831,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                        onClick: handleSave,
                                        isDisabled: saving,
                                        className: `w-14 h-14 rounded-full shadow-2xl flex items-center justify-center p-0 transition-all transform hover:scale-110 active:scale-95 ${saving ? "bg-gray-400" : "bg-primary-500 hover:bg-primary-600"}`,
                                        children: saving ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"
                                        }, void 0, false, {
                                            fileName: "[project]/components/editor/PageEditor.tsx",
                                            lineNumber: 841,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CloudArrowUpIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CloudArrowUpIcon$3e$__["CloudArrowUpIcon"], {
                                            className: "w-7 h-7 text-white"
                                        }, void 0, false, {
                                            fileName: "[project]/components/editor/PageEditor.tsx",
                                            lineNumber: 843,
                                            columnNumber: 17
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 834,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 830,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 826,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `relative transition-all duration-300 ease-in-out ${rightPanelOpen ? "w-96" : "w-0"} bg-white border-l border-gray-200 shadow-xl flex flex-col z-30`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setRightPanelOpen(!rightPanelOpen),
                                className: `absolute top-1/2 -translate-y-1/2 -left-7 w-10 h-10 bg-white border border-gray-200 rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-all z-50 hover:scale-110 active:scale-95`,
                                title: rightPanelOpen ? "Collapse Panel" : "Expand Panel",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: `w-5 h-5 text-gray-500 transition-transform duration-300 ${rightPanelOpen ? "rotate-180" : "rotate-0"}`,
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M15 19l-7-7 7-7"
                                    }, void 0, false, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 860,
                                        columnNumber: 15
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/components/editor/PageEditor.tsx",
                                    lineNumber: 859,
                                    columnNumber: 13
                                }, ("TURBOPACK compile-time value", void 0))
                            }, void 0, false, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 854,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-96 h-full flex flex-col overflow-hidden",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex border-b border-gray-200 bg-gray-50 shrink-0",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setActiveTab("blocks"),
                                                className: `flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${activeTab === "blocks" ? "bg-white text-purple-600 border-b-2 border-purple-600" : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,
                                                title: "Blocks",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-4 h-4",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M4 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1V5z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/editor/PageEditor.tsx",
                                                            lineNumber: 876,
                                                            columnNumber: 19
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 875,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "scale-90",
                                                        children: "Blocks"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 878,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 867,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setActiveTab("styles"),
                                                className: `flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${activeTab === "styles" ? "bg-white text-green-600 border-b-2 border-green-600" : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,
                                                title: "Styles",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-4 h-4",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/editor/PageEditor.tsx",
                                                            lineNumber: 889,
                                                            columnNumber: 19
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 888,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "scale-90",
                                                        children: "Styles"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 891,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 880,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setActiveTab("layers"),
                                                className: `flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${activeTab === "layers" ? "bg-white text-blue-600 border-b-2 border-blue-600" : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,
                                                title: "Layers",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-4 h-4",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/editor/PageEditor.tsx",
                                                            lineNumber: 902,
                                                            columnNumber: 19
                                                        }, ("TURBOPACK compile-time value", void 0))
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 901,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "scale-90",
                                                        children: "Layers"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 904,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 893,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setActiveTab("pages"),
                                                className: `flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${activeTab === "pages" ? "bg-white text-orange-600 border-b-2 border-orange-600" : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,
                                                title: "Pages",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$FolderIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderIcon$3e$__["FolderIcon"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 914,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "scale-90",
                                                        children: "Pages"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 915,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 906,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                onClick: ()=>setActiveTab("settings"),
                                                className: `flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${activeTab === "settings" ? "bg-white text-indigo-600 border-b-2 border-indigo-600" : "text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,
                                                title: "Settings",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__["Cog6ToothIcon"], {
                                                        className: "w-4 h-4"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 925,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "scale-90",
                                                        children: "Settings"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 926,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 917,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 866,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex-1 overflow-y-auto",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                id: "blocks-container",
                                                className: `p-4 ${activeTab === "blocks" ? "" : "hidden"}`
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 933,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                id: "styles-container",
                                                className: `p-4 ${activeTab === "styles" ? "" : "hidden"}`
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 936,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                id: "layers-container",
                                                className: `p-4 ${activeTab === "layers" ? "" : "hidden"}`
                                            }, void 0, false, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 939,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `p-4 ${activeTab === "pages" ? "" : "hidden"}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        className: "text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$FolderIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__FolderIcon$3e$__["FolderIcon"], {
                                                                className: "w-5 h-5 text-orange-600"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                                lineNumber: 944,
                                                                columnNumber: 19
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            "Your Pages"
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 943,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-2",
                                                        children: pages.map((pageName)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                                onClick: ()=>handlePageChange(pageName),
                                                                className: `w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition ${currentPage === pageName ? "bg-orange-50 text-orange-700 border-2 border-orange-200 shadow-sm" : "text-gray-700 hover:bg-gray-50 border-2 border-transparent"}`,
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$DocumentIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__DocumentIcon$3e$__["DocumentIcon"], {
                                                                        className: "w-5 h-5"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 957,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "capitalize font-medium",
                                                                        children: pageName.replace(/-/g, " ")
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 958,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    currentPage === pageName && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$CheckCircleIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__CheckCircleIcon$3e$__["CheckCircleIcon"], {
                                                                        className: "w-5 h-5 ml-auto text-orange-600"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 960,
                                                                        columnNumber: 25
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, pageName, true, {
                                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                                lineNumber: 949,
                                                                columnNumber: 21
                                                            }, ("TURBOPACK compile-time value", void 0)))
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 947,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 942,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0)),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: `p-4 ${activeTab === "settings" ? "" : "hidden"}`,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center justify-between mb-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                                className: "text-sm font-semibold text-gray-700 flex items-center gap-2",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$heroicons$2f$react$2f$24$2f$outline$2f$esm$2f$Cog6ToothIcon$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Cog6ToothIcon$3e$__["Cog6ToothIcon"], {
                                                                        className: "w-5 h-5 text-blue-600"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 971,
                                                                        columnNumber: 21
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    "Storefront Settings"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                                lineNumber: 970,
                                                                columnNumber: 19
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__default__as__Button$3e$__["Button"], {
                                                                variant: "ghost",
                                                                size: "xs",
                                                                onClick: loadPageSettings,
                                                                className: "text-gray-400 hover:text-gray-600",
                                                                isDisabled: settingsLoading,
                                                                children: "Refresh"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                                lineNumber: 974,
                                                                columnNumber: 19
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 969,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "space-y-4",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "bg-blue-50 border border-blue-100 rounded-lg p-3",
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                        className: "text-xs font-black text-blue-800 uppercase tracking-widest mb-1",
                                                                        children: "Navigation Menu"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 987,
                                                                        columnNumber: 21
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                        className: "text-[10px] text-blue-600 font-medium font-mono leading-tight",
                                                                        children: "DRAG TO REORDER. DRAG OVER TO NEST."
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 988,
                                                                        columnNumber: 21
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                                lineNumber: 986,
                                                                columnNumber: 19
                                                            }, ("TURBOPACK compile-time value", void 0)),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "space-y-2",
                                                                children: [
                                                                    pageSettings.filter((s)=>!s.parentId).sort((a, b)=>(a.order || 0) - (b.order || 0)).map((setting)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NestedMenuItem, {
                                                                            setting: setting,
                                                                            allSettings: pageSettings,
                                                                            onToggle: handleToggleSetting,
                                                                            onMove: async (draggedId, targetId, position)=>{
                                                                                const dragged = pageSettings.find((s)=>s.id === draggedId);
                                                                                if (!dragged) return;
                                                                                let newParentId = null;
                                                                                let newOrder = 0;
                                                                                if (position === 'inside') {
                                                                                    newParentId = targetId;
                                                                                    const siblings = pageSettings.filter((s)=>s.parentId === targetId);
                                                                                    newOrder = siblings.length > 0 ? Math.max(...siblings.map((s)=>s.order || 0)) + 1 : 0;
                                                                                } else {
                                                                                    const target = pageSettings.find((s)=>s.id === targetId);
                                                                                    newParentId = target?.parentId || null;
                                                                                    if (position === 'before') {
                                                                                        newOrder = (target?.order || 0) - 0.5;
                                                                                    } else {
                                                                                        newOrder = (target?.order || 0) + 0.5;
                                                                                    }
                                                                                }
                                                                                try {
                                                                                    setSettingsLoading(true);
                                                                                    await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["updatePageSetting"])(draggedId, {
                                                                                        parentId: newParentId,
                                                                                        order: newOrder
                                                                                    });
                                                                                    await loadPageSettings();
                                                                                    showSuccess("Menu updated");
                                                                                } catch (error) {
                                                                                    showError("Failed to move item");
                                                                                    console.error(error);
                                                                                } finally{
                                                                                    setSettingsLoading(false);
                                                                                }
                                                                            }
                                                                        }, setting.id, false, {
                                                                            fileName: "[project]/components/editor/PageEditor.tsx",
                                                                            lineNumber: 993,
                                                                            columnNumber: 23
                                                                        }, ("TURBOPACK compile-time value", void 0))),
                                                                    pageSettings.length === 0 && !settingsLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "p-8 text-center text-gray-400 text-xs italic bg-gray-50 rounded-2xl border border-dashed border-gray-200",
                                                                        children: "No pages found."
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 1038,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0)),
                                                                    settingsLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                        className: "space-y-2 animate-pulse mt-4",
                                                                        children: [
                                                                            1,
                                                                            2,
                                                                            3
                                                                        ].map((i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                                className: "h-12 bg-gray-100 rounded-xl w-full"
                                                                            }, i, false, {
                                                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                                                lineNumber: 1046,
                                                                                columnNumber: 27
                                                                            }, ("TURBOPACK compile-time value", void 0)))
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                                        lineNumber: 1044,
                                                                        columnNumber: 23
                                                                    }, ("TURBOPACK compile-time value", void 0))
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                                lineNumber: 991,
                                                                columnNumber: 19
                                                            }, ("TURBOPACK compile-time value", void 0))
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                                        lineNumber: 985,
                                                        columnNumber: 17
                                                    }, ("TURBOPACK compile-time value", void 0))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/editor/PageEditor.tsx",
                                                lineNumber: 968,
                                                columnNumber: 15
                                            }, ("TURBOPACK compile-time value", void 0))
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/editor/PageEditor.tsx",
                                        lineNumber: 931,
                                        columnNumber: 13
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/editor/PageEditor.tsx",
                                lineNumber: 864,
                                columnNumber: 11
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/editor/PageEditor.tsx",
                        lineNumber: 850,
                        columnNumber: 9
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/components/editor/PageEditor.tsx",
                lineNumber: 824,
                columnNumber: 7
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/components/editor/PageEditor.tsx",
        lineNumber: 662,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
};
_s1(PageEditor, "aUsZrlc/kN+aGF7+EkLNmEI+hzw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$contexts$2f$AuthContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useToast"]
    ];
});
_c1 = PageEditor;
var _c, _c1;
__turbopack_context__.k.register(_c, "NestedMenuItem");
__turbopack_context__.k.register(_c1, "PageEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/editor/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EditorPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$editor$2f$PageEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/editor/PageEditor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function EditorPageContent() {
    _s();
    const searchParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"])();
    const subdomain = searchParams.get("subdomain") || undefined;
    const page = searchParams.get("page") || undefined;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$editor$2f$PageEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["PageEditor"], {
        subdomain: subdomain,
        initialPage: page
    }, void 0, false, {
        fileName: "[project]/app/editor/page.tsx",
        lineNumber: 12,
        columnNumber: 10
    }, this);
}
_s(EditorPageContent, "a+DZx9DY26Zf8FVy1bxe3vp9l1w=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSearchParams"]
    ];
});
_c = EditorPageContent;
function EditorPage() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center justify-center h-screen",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"
            }, void 0, false, {
                fileName: "[project]/app/editor/page.tsx",
                lineNumber: 19,
                columnNumber: 9
            }, void 0)
        }, void 0, false, {
            fileName: "[project]/app/editor/page.tsx",
            lineNumber: 18,
            columnNumber: 7
        }, void 0),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(EditorPageContent, {}, void 0, false, {
            fileName: "[project]/app/editor/page.tsx",
            lineNumber: 22,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/editor/page.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
_c1 = EditorPage;
var _c, _c1;
__turbopack_context__.k.register(_c, "EditorPageContent");
__turbopack_context__.k.register(_c1, "EditorPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=_95df1464._.js.map