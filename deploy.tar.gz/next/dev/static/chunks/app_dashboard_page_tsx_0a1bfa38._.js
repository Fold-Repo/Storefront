(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_firebase_firestore_dist_esm_index_esm_2c9157b6.js",
  "static/chunks/_d90bd1ee._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_9bd96616._.js",
  "static/chunks/node_modules_next_a62874fb._.js",
  "static/chunks/node_modules_recharts_es6_util_dcb70efd._.js",
  "static/chunks/node_modules_recharts_es6_state_30b26513._.js",
  "static/chunks/node_modules_recharts_es6_component_fa68ed5e._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_e91c787d._.js",
  "static/chunks/node_modules_recharts_es6_d29e9b32._.js",
  "static/chunks/node_modules_99a706b3._.js"
],
    source: "dynamic"
});
