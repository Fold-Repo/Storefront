(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/utils/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InternetCheck",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$internetCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
    "debounce",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$debounce$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["debounce"],
    "getCurrentSubdomain",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$domain$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentSubdomain"],
    "getMainDomain",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$domain$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMainDomain"],
    "getSubdomainUrl",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$domain$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSubdomainUrl"],
    "getSubdomainWithDomain",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$domain$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getSubdomainWithDomain"],
    "logout",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["logout"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/utils/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$internetCheck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/internetCheck.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$debounce$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/debounce.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$utils$2f$domain$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/utils/domain.ts [app-client] (ecmascript)");
}),
]);