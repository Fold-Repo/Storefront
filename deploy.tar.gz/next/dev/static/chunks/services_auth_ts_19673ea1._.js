(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/services/auth.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "forgotPassword",
    ()=>forgotPassword,
    "generateSecurePassword",
    ()=>generateSecurePassword,
    "googleLogin",
    ()=>googleLogin,
    "googleSignup",
    ()=>googleSignup,
    "login",
    ()=>login,
    "refreshToken",
    ()=>refreshToken,
    "resendOtp",
    ()=>resendOtp,
    "resetPassword",
    ()=>resetPassword,
    "signup",
    ()=>signup,
    "uploadFile",
    ()=>uploadFile,
    "verifyAccount",
    ()=>verifyAccount
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/apiClient.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/axios/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/constants/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/api.ts [app-client] (ecmascript)");
;
;
;
const generateSecurePassword = ()=>{
    // Generate a secure random password that won't be used for authentication
    // Format: GOOGLE_AUTH_ + random secure string
    const randomPart = crypto.getRandomValues(new Uint8Array(32));
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    const randomString = Array.from(randomPart, (x)=>charset[x % charset.length]).join("");
    return `GOOGLE_AUTH_${randomString}`;
};
const uploadFile = async (file)=>{
    const formData = new FormData();
    formData.append("file", file);
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].UPLOADS.MULTIPLE, formData, {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        });
        return response.data.data.url;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.message || "File upload failed";
            throw new Error(errorMessage);
        }
        throw error;
    }
};
// Clean payload - remove undefined values and convert null to appropriate values
const cleanPayload = (payload)=>{
    const cleaned = {};
    Object.entries(payload).forEach(([key, value])=>{
        // Skip undefined values
        if (value !== undefined) {
            // Convert null to null (keep it for fields that accept null)
            if (value === null) {
                cleaned[key] = null;
            } else {
                cleaned[key] = value;
            }
        }
    });
    return cleaned;
};
const signup = async (payload)=>{
    try {
        // Clean the payload before sending
        const cleanedPayload = cleanPayload(payload);
        // Log request for debugging (remove in production)
        if ("TURBOPACK compile-time truthy", 1) {
            console.log("Signup payload:", JSON.stringify(cleanedPayload, null, 2));
        }
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.SIGNUP, cleanedPayload);
        // Store auth token if provided (some APIs return token immediately)
        if (response.data?.token || response.data?.data?.token) {
            const token = response.data?.token || response.data?.data?.token;
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("auth_token", token);
                // Also set as cookie for axios interceptor
                const { setCookie } = await __turbopack_context__.A("[project]/utils/cookies.ts [app-client] (ecmascript, async loader)");
                const { AUTH_TOKEN_KEY } = await __turbopack_context__.A("[project]/types/index.ts [app-client] (ecmascript, async loader)");
                setCookie(AUTH_TOKEN_KEY, token, 7);
            }
        }
        return response.data;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle field-specific validation errors
            if (error.response?.data?.fields) {
                const errorMessage = JSON.stringify({
                    message: error.response.data.error || error.response.data.message || "Validation errors",
                    fields: error.response.data.fields
                });
                throw new Error(errorMessage);
            }
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            // Handle other API errors
            const errorMessage = error.response?.data?.error || error.response?.data?.message || error.message || "Signup failed";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection and API URL configuration.");
        }
        throw error;
    }
};
const googleSignup = async (payload)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.GOOGLE_SIGNUP, {
            idToken: payload.idToken,
            role: payload.role || 'business',
            phone: payload.phone || undefined,
            altphone: payload.altphone || undefined,
            position: payload.position || undefined
        });
        // Return response data
        return response.data;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle field-specific validation errors
            if (error.response?.data?.fields) {
                const errorMessage = JSON.stringify({
                    message: error.response.data.error || error.response.data.message || "Validation errors",
                    fields: error.response.data.fields
                });
                throw new Error(errorMessage);
            }
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Google signup failed";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection and API URL configuration.");
        }
        throw error;
    }
};
const googleLogin = async (payload)=>{
    try {
        // Log the request URL in development
        if ("TURBOPACK compile-time truthy", 1) {
            console.log("[Google Login] Calling endpoint:", `${__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}${__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.GOOGLE_SIGNIN}`);
            console.log("[Google Login] Payload:", {
                idToken: payload.idToken.substring(0, 20) + "..." // Show first 20 chars only for security
            });
        }
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.GOOGLE_SIGNIN, {
            idToken: payload.idToken
        });
        // Log successful response in development
        if ("TURBOPACK compile-time truthy", 1) {
            console.log("[Google Login] Response status:", response.status);
            console.log("[Google Login] Response data structure:", {
                hasData: !!response.data,
                hasToken: !!(response.data?.token || response.data?.data?.token),
                hasUser: !!(response.data?.user || response.data?.data?.user),
                hasRefreshToken: !!(response.data?.refreshToken || response.data?.data?.refreshToken)
            });
        }
        // Return response data - storage will be handled by AuthContext via LoginModal
        return response.data;
    } catch (error) {
        // Log error details in development
        if ("TURBOPACK compile-time truthy", 1) {
            console.error("[Google Login] Error occurred:", {
                message: error.message,
                status: error.response?.status,
                statusText: error.response?.statusText,
                data: error.response?.data,
                code: error.code
            });
        }
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Google login failed";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection.");
        }
        throw error;
    }
};
const login = async (email, password)=>{
    try {
        // Log the request URL in development
        if ("TURBOPACK compile-time truthy", 1) {
            console.log("[Login] Calling endpoint:", `${__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}${__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.LOGIN}`);
            console.log("[Login] Payload:", {
                email,
                password: "***"
            });
        }
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.LOGIN, {
            email,
            password
        });
        // Return response data - storage will be handled by AuthContext via LoginModal
        return response.data;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Login failed";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection.");
        }
        throw error;
    }
};
const resendOtp = async (payload)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.REQUEST_OTP, payload);
        return response.data;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Failed to resend verification code";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection.");
        }
        throw error;
    }
};
const verifyAccount = async (payload)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.VERIFY_ACCOUNT, payload);
        // Store auth token and user data if provided after verification
        if (response.data?.data) {
            const { token, refreshToken, user } = response.data.data;
            if (token && ("TURBOPACK compile-time value", "object") !== "undefined") {
                // Store token
                localStorage.setItem("auth_token", token);
                if (refreshToken) {
                    localStorage.setItem("refresh_token", refreshToken);
                }
                // Also set as cookie for axios interceptor
                const { setCookie } = await __turbopack_context__.A("[project]/utils/cookies.ts [app-client] (ecmascript, async loader)");
                const { AUTH_TOKEN_KEY } = await __turbopack_context__.A("[project]/types/index.ts [app-client] (ecmascript, async loader)");
                setCookie(AUTH_TOKEN_KEY, token, 7);
                // Store user data
                if (user) {
                    localStorage.setItem("user_data", JSON.stringify(user));
                }
            }
        } else if (response.data?.token) {
            // Fallback for different response structure
            const token = response.data.token;
            if ("TURBOPACK compile-time truthy", 1) {
                localStorage.setItem("auth_token", token);
                const { setCookie } = await __turbopack_context__.A("[project]/utils/cookies.ts [app-client] (ecmascript, async loader)");
                const { AUTH_TOKEN_KEY } = await __turbopack_context__.A("[project]/types/index.ts [app-client] (ecmascript, async loader)");
                setCookie(AUTH_TOKEN_KEY, token, 7);
            }
        }
        return response.data;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle field-specific validation errors
            if (error.response?.data?.fields) {
                const errorMessage = JSON.stringify({
                    message: error.response.data.error || error.response.data.message || "Validation errors",
                    fields: error.response.data.fields
                });
                throw new Error(errorMessage);
            }
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Account verification failed";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection.");
        }
        throw error;
    }
};
const forgotPassword = async (payload)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.RESET_PASSWORD, payload);
        return response.data;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Failed to send password reset email";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection.");
        }
        throw error;
    }
};
const resetPassword = async (payload)=>{
    try {
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$apiClient$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].patch(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.RESET_PASSWORD, payload);
        return response.data;
    } catch (error) {
        // Handle 503 Service Unavailable
        if (error.is503 || error.response?.status === 503) {
            throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
        }
        // Handle timeout errors
        if (error.isTimeout || error.code === 'ECONNABORTED') {
            throw new Error("Request timeout. The server is taking too long to respond. Please check your connection and try again.");
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            // Handle field-specific validation errors
            if (error.response?.data?.fields) {
                const errorMessage = JSON.stringify({
                    message: error.response.data.error || error.response.data.message || "Validation errors",
                    fields: error.response.data.fields
                });
                throw new Error(errorMessage);
            }
            // Handle 503 from response
            if (error.response?.status === 503) {
                throw new Error("Service temporarily unavailable. The server is currently down or overloaded. Please try again in a few moments.");
            }
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Failed to reset password";
            throw new Error(errorMessage);
        }
        // Handle network errors
        if (error.message?.includes("Network Error") || error.code === "ERR_NETWORK") {
            throw new Error("Network error: Unable to reach the server. Please check your internet connection.");
        }
        throw error;
    }
};
const refreshToken = async (payload)=>{
    try {
        // Use a separate axios instance without interceptors to avoid infinite loops
        // API_BASE_URL defaults to 'https://shorp-epos-backend.onrender.com/api/v1' or from NEXT_PUBLIC_API_URL env var
        const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].post(`${__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["API_BASE_URL"]}${__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ENDPOINT"].AUTH.REFRESH_TOKEN}`, payload);
        // Store new tokens
        let token = null;
        let newRefreshToken = null;
        if (response.data?.data) {
            token = response.data.data.token;
            newRefreshToken = response.data.data.refreshToken;
        } else if (response.data?.token) {
            token = response.data.token;
            newRefreshToken = response.data.refreshToken;
        }
        if (token && ("TURBOPACK compile-time value", "object") !== "undefined") {
            localStorage.setItem("auth_token", token);
            const { setCookie } = await __turbopack_context__.A("[project]/utils/cookies.ts [app-client] (ecmascript, async loader)");
            const { AUTH_TOKEN_KEY } = await __turbopack_context__.A("[project]/types/index.ts [app-client] (ecmascript, async loader)");
            setCookie(AUTH_TOKEN_KEY, token, 7);
            if (newRefreshToken) {
                localStorage.setItem("refresh_token", newRefreshToken);
            }
        }
        return {
            token,
            refreshToken: newRefreshToken,
            data: response.data
        };
    } catch (error) {
        // If refresh token fails, clear all auth and throw error
        if ("TURBOPACK compile-time truthy", 1) {
            const { logout } = await __turbopack_context__.A("[project]/utils/index.ts [app-client] (ecmascript, async loader)");
            await logout();
        }
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["AxiosError"]) {
            const errorMessage = error.response?.data?.message || error.response?.data?.error || error.message || "Token refresh failed";
            throw new Error(errorMessage);
        }
        throw error;
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=services_auth_ts_19673ea1._.js.map