(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_globals_71f961d1.css",
  "static/chunks/node_modules_7ed4c00c._.js",
  "static/chunks/node_modules_framer-motion_dist_es_795dc174._.js",
  "static/chunks/node_modules_@heroui_theme_dist_eb4b49e3._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_@react-aria_interactions_dist_ad4f6f3a._.js",
  "static/chunks/node_modules_@tanstack_query-devtools_build_736394b3._.js",
  "static/chunks/node_modules_5dff79a7._.js",
  "static/chunks/_2168da6e._.js"
],
    source: "dynamic"
});
