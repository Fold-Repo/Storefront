(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2ec4af7d._.js",
  "static/chunks/services_auth_ts_19673ea1._.js"
],
    source: "dynamic"
});
