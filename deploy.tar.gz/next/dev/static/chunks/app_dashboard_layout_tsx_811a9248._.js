(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_1895dffb._.js",
  "static/chunks/_2bd60c82._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_libphonenumber-js_4fa29673._.js",
  "static/chunks/node_modules_react-phone-number-input_073edee2._.js",
  "static/chunks/node_modules_@react-aria_overlays_dist_0ad9b9ce._.js",
  "static/chunks/node_modules_43bf8c86._.js",
  "static/chunks/node_modules_react-phone-number-input_style_e1f21a86.css"
],
    source: "dynamic"
});
