(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/utils/cookies.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/utils/cookies.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/types/index.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/types_index_ts_b4e48a2c._.js",
  "static/chunks/types_index_ts_0dbbe8a2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/types/index.ts [app-client] (ecmascript)");
    });
});
}),
"[project]/utils/index.ts [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/utils_index_ts_a944a9eb._.js",
  "static/chunks/utils_index_ts_0dbbe8a2._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/utils/index.ts [app-client] (ecmascript)");
    });
});
}),
]);