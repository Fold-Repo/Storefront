(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_firebase_firestore_dist_esm_index_esm_64fe165f.js",
  "static/chunks/_9937fa50._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_9bd96616._.js",
  "static/chunks/node_modules_7ba1e9c8._.js"
],
    source: "dynamic"
});
