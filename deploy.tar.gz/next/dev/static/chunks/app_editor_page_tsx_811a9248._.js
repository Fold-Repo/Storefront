(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d3744548._.js",
  "static/chunks/_95df1464._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_9bd96616._.js",
  "static/chunks/node_modules_axios_lib_99e19c7d._.js",
  "static/chunks/node_modules_libphonenumber-js_4fa29673._.js",
  "static/chunks/node_modules_react-phone-number-input_073edee2._.js",
  "static/chunks/node_modules_@react-aria_overlays_dist_0ad9b9ce._.js",
  "static/chunks/node_modules_cf40c4e2._.js",
  "static/chunks/node_modules_078c6460._.css"
],
    source: "dynamic"
});
