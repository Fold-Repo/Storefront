(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_2bf5ca1a._.js",
  "static/chunks/_e8080162._.js",
  "static/chunks/node_modules_next_533d9400._.js",
  "static/chunks/node_modules_axios_3c0c0f8e._.js",
  "static/chunks/node_modules_libphonenumber-js_4fa29673._.js",
  "static/chunks/node_modules_react-phone-number-input_073edee2._.js",
  "static/chunks/node_modules_@react-aria_overlays_dist_0ad9b9ce._.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm2017_9bd96616._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_d9c36ae7.js",
  "static/chunks/node_modules_92657aab._.js",
  "static/chunks/node_modules_react-phone-number-input_style_e1f21a86.css"
],
    source: "dynamic"
});
