(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push(["chunks/[root-of-the-server]__f2b15f93._.js",
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[project]/middleware.ts [middleware-edge] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Next.js Proxy for Subdomain/Domain Routing
 * 
 * This proxy:
 * 1. Detects subdomain or custom domain
 * 2. Loads the appropriate storefront configuration
 * 3. Routes to the storefront pages
 */ __turbopack_context__.s([
    "config",
    ()=>config,
    "default",
    ()=>middleware,
    "proxy",
    ()=>proxy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$api$2f$server$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/api/server.js [middleware-edge] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/esm/server/web/exports/index.js [middleware-edge] (ecmascript)");
;
// Main domain (your platform domain)
// Use NEXT_PUBLIC_ prefix for client-side access, fallback to dfoldlab.co.uk
const MAIN_DOMAIN = ("TURBOPACK compile-time value", "localhost") || process.env.MAIN_DOMAIN || 'dfoldlab.co.uk';
const STOREFRONT_DOMAIN = process.env.NEXT_PUBLIC_STOREFRONT_DOMAIN || process.env.STOREFRONT_DOMAIN || MAIN_DOMAIN;
async function middleware(request) {
    return proxy(request);
}
async function proxy(request) {
    const url = request.nextUrl.clone();
    const hostname = request.headers.get('host') || '';
    // Log for debugging (remove in production)
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('🔍 Proxy check:', {
            hostname,
            pathname: url.pathname,
            MAIN_DOMAIN
        });
    }
    // Skip proxy for:
    // - API routes
    // - Static files
    // - _next files
    if (url.pathname.startsWith('/api') || url.pathname.startsWith('/_next') || url.pathname.startsWith('/static') || url.pathname.includes('.')) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    }
    // Skip for main platform routes (dashboard, auth, etc.)
    const platformRoutes = [
        '/dashboard',
        '/signin',
        '/signup',
        '/forgot-password',
        '/reset-password',
        '/verify',
        '/editor'
    ];
    if (platformRoutes.some((route)=>url.pathname.startsWith(route))) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    }
    // Extract subdomain or check if it's a custom domain
    const hostWithoutPort = hostname.split(':')[0];
    const isLocalhost = hostWithoutPort === 'localhost' || hostWithoutPort === '127.0.0.1';
    // Check for subdomain.localhost pattern (e.g., bukaxp.localhost)
    const isSubdomainLocalhost = hostWithoutPort.endsWith('.localhost');
    const localhostSubdomain = isSubdomainLocalhost ? hostWithoutPort.replace('.localhost', '') : null;
    // Improved subdomain extraction: handle localhost and production domains
    // For subdomain.localhost pattern in development, extract the subdomain
    const subdomain = localhostSubdomain || (isLocalhost ? null : extractSubdomain(hostname, MAIN_DOMAIN));
    // Also treat .netlify.app technical domains as the main domain to avoid misrouting
    // We also check a hardcoded fallback if MAIN_DOMAIN is missing or set to localhost
    const isMainDomain = hostWithoutPort === MAIN_DOMAIN || hostWithoutPort === `www.${MAIN_DOMAIN}` || hostWithoutPort === 'dfoldlab.co.uk' || hostWithoutPort === 'www.dfoldlab.co.uk' || hostWithoutPort.endsWith('.netlify.app');
    // Log for debugging
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('🔍 Subdomain extraction:', {
            hostname,
            hostWithoutPort,
            MAIN_DOMAIN,
            subdomain,
            isLocalhost,
            isSubdomainLocalhost,
            localhostSubdomain,
            isMainDomain
        });
    }
    // If it's localhost or main domain with no subdomain, it's the main platform
    if ((isLocalhost || isMainDomain) && !subdomain) {
        if ("TURBOPACK compile-time truthy", 1) {
            console.log('✅ Main platform route, skipping proxy');
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    }
    // Check if it's a custom domain (not localhost, not main domain, no subdomain pattern)
    const isCustomDomain = !isLocalhost && !isMainDomain && !subdomain && hostWithoutPort !== MAIN_DOMAIN && hostWithoutPort !== 'dfoldlab.co.uk' && !hostWithoutPort.endsWith('.netlify.app') && !hostWithoutPort.includes(STOREFRONT_DOMAIN);
    // If no subdomain and not a custom domain, it's the main platform
    if (!subdomain && !isCustomDomain) {
        if ("TURBOPACK compile-time truthy", 1) {
            console.log('✅ No subdomain found, skipping proxy');
        }
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].next();
    }
    // Determine storefront identifier
    const storefrontId = subdomain || hostname;
    // Log storefront routing
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('🚀 Routing to storefront:', {
            storefrontId,
            subdomain,
            isCustomDomain,
            pathname: url.pathname
        });
    }
    // Add storefront context to request headers
    const requestHeaders = new Headers(request.headers);
    requestHeaders.set('x-storefront-id', storefrontId);
    requestHeaders.set('x-storefront-subdomain', subdomain || '');
    requestHeaders.set('x-is-custom-domain', isCustomDomain ? 'true' : 'false');
    // Rewrite to storefront route
    url.pathname = `/storefront${url.pathname === '/' ? '' : url.pathname}`;
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('📝 Rewriting to:', url.pathname);
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$esm$2f$server$2f$web$2f$exports$2f$index$2e$js__$5b$middleware$2d$edge$5d$__$28$ecmascript$29$__["NextResponse"].rewrite(url, {
        request: {
            headers: requestHeaders
        }
    });
}
/**
 * Extract subdomain from hostname
 */ function extractSubdomain(hostname, mainDomain) {
    // Remove port if present
    const host = hostname.split(':')[0];
    // Check against configured MAIN_DOMAIN
    if (mainDomain !== 'localhost' && host.endsWith(`.${mainDomain}`)) {
        const subdomain = host.replace(`.${mainDomain}`, '');
        if (subdomain && subdomain !== 'www' && subdomain !== 'app' && subdomain !== 'api') {
            return subdomain;
        }
    }
    // Hardcoded fallback for production domain
    if (host.endsWith('.dfoldlab.co.uk')) {
        const subdomain = host.replace('.dfoldlab.co.uk', '');
        if (subdomain && subdomain !== 'www' && subdomain !== 'app' && subdomain !== 'api') {
            return subdomain;
        }
    }
    return null;
}
const config = {
    matcher: [
        /*
         * Match all request paths except for the ones starting with:
         * - api (API routes)
         * - _next/static (static files)
         * - _next/image (image optimization files)
         * - favicon.ico (favicon file)
         */ '/((?!api|_next/static|_next/image|favicon.ico).*)'
    ]
};
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__f2b15f93._.js.map