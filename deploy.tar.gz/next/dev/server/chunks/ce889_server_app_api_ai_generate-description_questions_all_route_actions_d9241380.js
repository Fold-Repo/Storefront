module.exports = [
"[project]/.next-internal/server/app/api/ai/generate-description/questions/all/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_api_ai_generate-description_questions_all_route_actions_d9241380.js.map