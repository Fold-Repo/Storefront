module.exports = [
"[project]/.next-internal/server/app/dashboard/whatsapp/campaigns/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_whatsapp_campaigns_page_actions_83e9e37d.js.map