module.exports = [
"[project]/constants/seo.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "APP_AUTHORS",
    ()=>APP_AUTHORS,
    "APP_KEYWORDS",
    ()=>APP_KEYWORDS,
    "APP_OPEN_GRAPH",
    ()=>APP_OPEN_GRAPH,
    "APP_ROBOTS",
    ()=>APP_ROBOTS,
    "APP_THEME_COLOR",
    ()=>APP_THEME_COLOR,
    "APP_TWITTER",
    ()=>APP_TWITTER,
    "SEO_DESCRIPTION",
    ()=>SEO_DESCRIPTION,
    "SEO_TITLE",
    ()=>SEO_TITLE,
    "SITE_URL",
    ()=>SITE_URL
]);
const SITE_URL = 'https://dfoldlab.co.uk';
const SEO_TITLE = 'StoreFront — Build Your Dream Online Store';
const SEO_DESCRIPTION = 'StoreFront is the ultimate platform for creating stunning, professional online stores in minutes. Launch your business with powerful tools, custom themes, and AI-driven design recommendations.';
const APP_KEYWORDS = [
    'StoreFront',
    'ecommerce builder',
    'online store',
    'website builder',
    'sell online',
    'shop builder',
    'business',
    'ecommerce platform',
    'startup',
    'entrepreneur'
];
const APP_AUTHORS = [
    {
        name: 'StoreFront'
    }
];
const APP_OPEN_GRAPH = {
    title: 'StoreFront — Build Your Dream Online Store',
    description: 'StoreFront is the ultimate platform for creating stunning, professional online stores in minutes. Launch your business with powerful tools, custom themes, and AI-driven design recommendations.',
    url: SITE_URL,
    siteName: 'StoreFront',
    locale: 'en_US',
    type: 'website'
};
const APP_TWITTER = {
    card: 'summary_large_image',
    title: 'StoreFront — Build Your Dream Online Store',
    description: 'Create stunning, professional online stores in minutes with StoreFront. Launch your business with powerful tools and AI-driven design.'
};
const APP_ROBOTS = {
    index: true,
    follow: true
};
const APP_THEME_COLOR = [
    {
        media: '(prefers-color-scheme: light)',
        color: '#ffffff'
    },
    {
        media: '(prefers-color-scheme: dark)',
        color: '#030712'
    }
];
}),
"[project]/constants/logo.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LOGO",
    ()=>LOGO
]);
const LOGO = {
    black: '/img/logo/logo.svg',
    white: '/img/logo/logo.svg',
    mini: '/favicon.svg',
    alt: 'StoreFront'
};
}),
"[project]/constants/nav.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LOGOS",
    ()=>LOGOS,
    "NAV_BUTTONS",
    ()=>NAV_BUTTONS,
    "NAV_CONSTANT",
    ()=>NAV_CONSTANT,
    "NAV_ITEMS",
    ()=>NAV_ITEMS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/logo.ts [app-rsc] (ecmascript)");
;
const NAV_ITEMS = [
    {
        label: "Features",
        href: "#features"
    },
    {
        label: "How it works",
        href: "#how-it-works"
    },
    {
        label: "Pricing",
        href: "#pricing"
    }
];
const NAV_BUTTONS = [
    {
        label: "Log in",
        href: "/signin",
        variant: "link",
        showOnMobile: false
    },
    {
        label: "Get Started",
        href: "/signup",
        variant: "solid",
        radius: "full",
        showOnMobile: false
    }
];
const LOGOS = {
    light: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LOGO"].white,
    dark: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["LOGO"].black
};
const NAV_CONSTANT = {
    NAV_ITEMS,
    NAV_BUTTONS,
    LOGOS
};
}),
"[project]/constants/api.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_BASE_URL",
    ()=>API_BASE_URL,
    "ENDPOINT",
    ()=>ENDPOINT
]);
const DEFAULT_API_URL = "https://shorp-epos-backend.onrender.com/api/v1";
const API_BASE_URL = ("TURBOPACK compile-time value", "https://api.dfoldlab.co.uk/api/v1") || DEFAULT_API_URL;
const ENDPOINT = {
    AUTH: {
        ROLE_PERMISSIONS: '/role-permissions',
        LOGIN: '/auth/login',
        GOOGLE_SIGNIN: '/auth/google/signin',
        GOOGLE_SIGNUP: '/auth/google/signup',
        SIGNUP: '/auth/signup',
        LOGOUT: '/auth/signout',
        REQUEST_OTP: '/auth/reset',
        VERIFY_ACCOUNT: '/auth/verify-account',
        RESET_PASSWORD: '/auth/reset',
        VERIFY_OTP: '/auth/verify-account',
        REFRESH_TOKEN: '/auth/refresh-token',
        PERMISSIONS: '/roles/me/permission',
        ROLES: '/roles',
        ROLE_PERMISSION_DETAILS: '/roles'
    },
    ADDRESS: {
        AUTOCOMPLETE: '/autocomplete',
        GET: '/get'
    },
    STORES: {
        BASE: '/stores'
    },
    UPLOADS: {
        MULTIPLE: '/uploads/mulitple',
        DELETE: '/uploads/delete'
    },
    SUBSCRIPTION: {
        PLANS: '/subscription-plans'
    },
    VARIATIONS: '/variations',
    UNITS: '/units',
    CATEGORIES: '/categories',
    BRANDS: '/brands',
    SUPPLIERS: '/suppliers',
    PRODUCTS: '/products',
    SALES: '/sales',
    ADJUSTMENTS: '/adjustments',
    ANALYTICS: {
        TRENDS: (businessId)=>`/analytics/business/${businessId}/trends`,
        SUMMARY: (businessId)=>`/analytics/business/${businessId}/summary`
    },
    WHATSAPP: {
        BASE: '/whatsapp',
        OVERVIEW: (businessId)=>`/whatsapp/business/${businessId}/overview`,
        NUMBERS: {
            LIST: (businessId)=>`/whatsapp/business/${businessId}/numbers`,
            CONNECT: (businessId)=>`/whatsapp/business/${businessId}/numbers/connect`,
            UPDATE_TOKEN: (businessId, id)=>`/whatsapp/business/${businessId}/numbers/${id}/token`,
            DELETE: (businessId, id)=>`/whatsapp/business/${businessId}/numbers/${id}`
        },
        SETTINGS: {
            GET: (businessId)=>`/whatsapp/business/${businessId}/settings`,
            UPDATE: (businessId)=>`/whatsapp/business/${businessId}/settings`
        },
        SESSIONS: {
            LIST: (businessId)=>`/whatsapp/business/${businessId}/sessions`,
            GET: (sessionId)=>`/whatsapp/sessions/${sessionId}`,
            CART: (sessionId)=>`/whatsapp/sessions/${sessionId}/cart`
        },
        MARKETING: {
            SUBSCRIBERS: {
                LIST: (businessId)=>`/whatsapp/marketing/business/${businessId}/subscribers`,
                CREATE: (businessId)=>`/whatsapp/marketing/business/${businessId}/subscribers`,
                UPDATE: (businessId, phone)=>`/whatsapp/marketing/business/${businessId}/subscribers/${phone}`,
                DELETE: (businessId, phone)=>`/whatsapp/marketing/business/${businessId}/subscribers/${phone}`,
                IMPORT: (businessId)=>`/whatsapp/marketing/business/${businessId}/subscribers/import`
            },
            CAMPAIGNS: {
                LIST: (businessId)=>`/whatsapp/marketing/business/${businessId}/campaigns`,
                CREATE: (businessId)=>`/whatsapp/marketing/business/${businessId}/campaigns`,
                GET: (businessId, campaignId)=>`/whatsapp/marketing/business/${businessId}/campaigns/${campaignId}`,
                UPDATE: (businessId, campaignId)=>`/whatsapp/marketing/business/${businessId}/campaigns/${campaignId}`,
                RUN: (businessId, campaignId)=>`/whatsapp/marketing/business/${businessId}/campaigns/${campaignId}/run`
            }
        },
        SERVICE_TOKENS: {
            LIST: '/whatsapp/service-tokens',
            CREATE: '/whatsapp/service-tokens',
            SCOPES: '/whatsapp/service-tokens/scopes',
            REVOKE: (id)=>`/whatsapp/service-tokens/${id}/revoke`,
            DELETE: (id)=>`/whatsapp/service-tokens/${id}`
        }
    }
};
}),
"[project]/constants/index.ts [app-rsc] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/seo.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$logo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/logo.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$nav$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/nav.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$api$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/api.ts [app-rsc] (ecmascript)");
;
;
;
;
}),
"[project]/app/providers/index.tsx [app-rsc] (client reference proxy) <module evaluation>", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Providers",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Providers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Providers() from the server but Providers is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/providers/index.tsx <module evaluation>", "Providers");
}),
"[project]/app/providers/index.tsx [app-rsc] (client reference proxy)", ((__turbopack_context__) => {
"use strict";

// This file is generated by next-core EcmascriptClientReferenceModule.
__turbopack_context__.s([
    "Providers",
    ()=>Providers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const Providers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call Providers() from the server but Providers is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/app/providers/index.tsx", "Providers");
}),
"[project]/app/providers/index.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$providers$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/app/providers/index.tsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$providers$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/app/providers/index.tsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$providers$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>RootLayout,
    "metadata",
    ()=>metadata,
    "viewport",
    ()=>viewport
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$index$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/constants/index.ts [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/constants/seo.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$providers$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/providers/index.tsx [app-rsc] (ecmascript)");
;
;
;
;
const metadata = {
    metadataBase: new URL(__TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SITE_URL"]),
    title: {
        template: "%s | StoreFront",
        default: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEO_TITLE"]
    },
    description: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SEO_DESCRIPTION"],
    keywords: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APP_KEYWORDS"],
    authors: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APP_AUTHORS"],
    alternates: {
        canonical: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SITE_URL"]
    },
    openGraph: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APP_OPEN_GRAPH"],
    twitter: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APP_TWITTER"],
    robots: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APP_ROBOTS"],
    manifest: "/favicon.svg",
    icons: {
        icon: [
            {
                url: "/favicon.svg",
                type: "image/svg+xml"
            }
        ],
        apple: [
            {
                url: "/favicon.svg",
                type: "image/svg+xml"
            }
        ],
        shortcut: [
            {
                url: "/favicon.svg",
                type: "image/svg+xml"
            }
        ]
    }
};
const viewport = {
    themeColor: __TURBOPACK__imported__module__$5b$project$5d2f$constants$2f$seo$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["APP_THEME_COLOR"],
    width: "device-width",
    initialScale: 1,
    maximumScale: 5,
    userScalable: true,
    viewportFit: "cover",
    colorScheme: "light dark"
};
function RootLayout({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("html", {
        lang: "en",
        suppressHydrationWarning: true,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("body", {
            className: "font-sans debug-screens",
            suppressHydrationWarning: true,
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$providers$2f$index$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Providers"], {
                children: children
            }, void 0, false, {
                fileName: "[project]/app/layout.tsx",
                lineNumber: 57,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/layout.tsx",
            lineNumber: 53,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/layout.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
}),
"[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = __turbopack_context__.r("[project]/node_modules/next/dist/server/route-modules/app-page/module.compiled.js [app-rsc] (ecmascript)").vendored['react-rsc'].ReactJsxDevRuntime; //# sourceMappingURL=react-jsx-dev-runtime.js.map
}),
];

//# sourceMappingURL=_68dd49b2._.js.map