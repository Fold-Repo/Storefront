module.exports = [
"[project]/.next-internal/server/app/(auth)/signin/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_signin_page_actions_5f1ac7e6.js.map