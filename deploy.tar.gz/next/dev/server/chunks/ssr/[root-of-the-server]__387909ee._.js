module.exports = [
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/layout.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/layout.tsx [app-rsc] (ecmascript)"));
}),
"[project]/services/storefront.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Storefront Service
 * 
 * Handles loading storefront pages and configuration from storage
 * Supports both Firebase and Supabase (with migration path)
 */ __turbopack_context__.s([
    "loadStorefrontConfig",
    ()=>loadStorefrontConfig,
    "loadStorefrontPage",
    ()=>loadStorefrontPage
]);
// Get storage backend from environment
const STORAGE_BACKEND = process.env.NEXT_PUBLIC_STORAGE_BACKEND || 'firebase';
async function loadStorefrontConfig(identifier) {
    switch(STORAGE_BACKEND){
        case 'firebase':
            return await loadStorefrontConfigFromFirebase(identifier);
        case 'supabase':
            return await loadStorefrontConfigFromSupabase(identifier);
        case 's3':
            return await loadStorefrontConfigFromS3(identifier);
        default:
            return await loadStorefrontConfigFromFirebase(identifier);
    }
}
async function loadStorefrontPage(storefrontId, pageType) {
    switch(STORAGE_BACKEND){
        case 'firebase':
            return await loadStorefrontPageFromFirebase(storefrontId, pageType);
        case 'supabase':
            return await loadStorefrontPageFromSupabase(storefrontId, pageType);
        case 's3':
            return await loadStorefrontPageFromS3(storefrontId, pageType);
        default:
            return await loadStorefrontPageFromFirebase(storefrontId, pageType);
    }
}
// Firebase implementations
async function loadStorefrontConfigFromFirebase(identifier) {
    try {
        const { db } = await __turbopack_context__.A("[project]/lib/firebaseConfig.ts [app-rsc] (ecmascript, async loader)");
        const { collection, query, where, getDocs, limit } = await __turbopack_context__.A("[project]/node_modules/firebase/firestore/dist/index.mjs [app-rsc] (ecmascript, async loader)");
        // Query by subdomain (identifier could be subdomain or userId)
        const sitesRef = collection(db, 'storefront_sites');
        // Try to find by subdomain first
        const subdomainQuery = query(sitesRef, where('subdomain', '==', identifier), limit(1));
        const subdomainSnapshot = await getDocs(subdomainQuery);
        if (!subdomainSnapshot.empty) {
            const doc = subdomainSnapshot.docs[0];
            const data = doc.data();
            return {
                userId: data.userId,
                userEmail: data.userEmail,
                subdomain: data.subdomain,
                customDomain: data.customDomain,
                companyName: data.companyName,
                businessNiche: data.businessNiche,
                theme: data.theme,
                layout: data.layout || 'multi-page',
                logoUrl: data.logoUrl,
                status: data.status || 'active',
                createdAt: data.createdAt?.toDate() || new Date(),
                updatedAt: data.updatedAt?.toDate() || new Date()
            };
        }
        // If not found by subdomain, try by userId
        const userIdQuery = query(sitesRef, where('userId', '==', identifier), limit(1));
        const userIdSnapshot = await getDocs(userIdQuery);
        if (!userIdSnapshot.empty) {
            const doc = userIdSnapshot.docs[0];
            const data = doc.data();
            return {
                userId: data.userId,
                userEmail: data.userEmail,
                subdomain: data.subdomain,
                customDomain: data.customDomain,
                companyName: data.companyName,
                businessNiche: data.businessNiche,
                theme: data.theme,
                layout: data.layout || 'multi-page',
                logoUrl: data.logoUrl,
                status: data.status || 'active',
                createdAt: data.createdAt?.toDate() || new Date(),
                updatedAt: data.updatedAt?.toDate() || new Date()
            };
        }
        // 3. Try by customDomain (for custom domain routing)
        const customDomainQuery = query(sitesRef, where('customDomain', '==', identifier), limit(1));
        const customDomainSnapshot = await getDocs(customDomainQuery);
        if (!customDomainSnapshot.empty) {
            const doc = customDomainSnapshot.docs[0];
            const data = doc.data();
            return {
                userId: data.userId,
                userEmail: data.userEmail,
                subdomain: data.subdomain,
                customDomain: data.customDomain,
                companyName: data.companyName,
                businessNiche: data.businessNiche,
                theme: data.theme,
                layout: data.layout || 'multi-page',
                logoUrl: data.logoUrl,
                status: data.status || 'active',
                createdAt: data.createdAt?.toDate() || new Date(),
                updatedAt: data.updatedAt?.toDate() || new Date()
            };
        }
        return null;
    } catch (error) {
        console.error('Error loading storefront config from Firebase:', error);
        return null;
    }
}
async function loadStorefrontPageFromFirebase(storefrontId, pageType) {
    try {
        const { db } = await __turbopack_context__.A("[project]/lib/firebaseConfig.ts [app-rsc] (ecmascript, async loader)");
        const { collection, query, where, getDocs, limit, doc, getDoc } = await __turbopack_context__.A("[project]/node_modules/firebase/firestore/dist/index.mjs [app-rsc] (ecmascript, async loader)");
        // First, find the storefront by subdomain or userId
        const sitesRef = collection(db, 'storefront_sites');
        // Try by subdomain first
        let siteDoc = null;
        const subdomainQuery = query(sitesRef, where('subdomain', '==', storefrontId), limit(1));
        const subdomainSnapshot = await getDocs(subdomainQuery);
        if (!subdomainSnapshot.empty) {
            siteDoc = subdomainSnapshot.docs[0].data();
        } else {
            // Try by userId
            const userIdQuery = query(sitesRef, where('userId', '==', storefrontId), limit(1));
            const userIdSnapshot = await getDocs(userIdQuery);
            if (!userIdSnapshot.empty) {
                siteDoc = userIdSnapshot.docs[0].data();
            }
        }
        if (!siteDoc || !siteDoc.pages) {
            return null;
        }
        // Extract the requested page
        const page = siteDoc.pages[pageType];
        if (!page) {
            return null;
        }
        return {
            html: page.html || '',
            css: page.css || '',
            js: page.js,
            metadata: page.metadata || {
                title: `${siteDoc.companyName} - ${pageType}`,
                description: ''
            }
        };
    } catch (error) {
        console.error('Error loading page from Firebase:', error);
        return null;
    }
}
// Supabase implementations (placeholder)
async function loadStorefrontConfigFromSupabase(identifier) {
    // TODO: Implement Supabase query
    return null;
}
async function loadStorefrontPageFromSupabase(storefrontId, pageType) {
    // TODO: Implement Supabase query
    return null;
}
// S3 implementations (placeholder)
async function loadStorefrontConfigFromS3(identifier) {
    // TODO: Implement S3 config loading
    return null;
}
async function loadStorefrontPageFromS3(storefrontId, pageType) {
    // TODO: Implement S3 page loading
    return null;
}
}),
"[project]/lib/dataInjector.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Data Injector for Dynamic Content
 * 
 * Replaces placeholders in HTML with actual data from API calls
 */ __turbopack_context__.s([
    "injectDynamicData",
    ()=>injectDynamicData
]);
function injectDynamicData(html, data, config) {
    let injected = html;
    // Inject site-wide data
    injected = injectSiteData(injected, config);
    // Inject menu
    if (data.menu) {
        injected = injectMenu(injected, data.menu);
    }
    // Inject footer links
    if (data.footerLinks) {
        injected = injectFooterLinks(injected, data.footerLinks);
    }
    // Inject products
    injected = injectProducts(injected, data.products || []);
    // Inject single product
    if (data.product) {
        injected = injectProduct(injected, data.product);
    }
    // Inject categories
    injected = injectCategories(injected, data.categories || []);
    // Inject category
    if (data.category) {
        injected = injectCategory(injected, data.category);
    }
    // Inject featured products
    injected = injectFeaturedProducts(injected, data.featuredProducts || []);
    // Inject related products
    injected = injectRelatedProducts(injected, data.relatedProducts || []);
    // Inject breadcrumbs
    injected = injectBreadcrumbs(injected, data.breadcrumbs);
    // Inject testimonials
    if (data.testimonials) {
        injected = injectTestimonials(injected, data.testimonials);
    }
    // Inject generic content (for custom pages)
    if (data.content) {
        injected = injectContent(injected, data.content);
    }
    // Inject any custom data
    Object.keys(data).forEach((key)=>{
        if (![
            'menu',
            'footerLinks',
            'products',
            'product',
            'categories',
            'category',
            'featuredProducts',
            'relatedProducts',
            'testimonials',
            'content'
        ].includes(key)) {
            injected = injectCustomData(injected, key, data[key]);
        }
    });
    return injected;
}
/**
 * Inject site-wide data (company name, logo, etc.)
 */ function injectSiteData(html, config) {
    let injected = html;
    // Replace placeholders
    injected = injected.replace(/\{\{companyName\}\}/g, config.companyName);
    injected = injected.replace(/\{\{primaryColor\}\}/g, config.theme.primaryColor);
    injected = injected.replace(/\{\{fontFamily\}\}/g, config.theme.fontFamily);
    if (config.logoUrl) {
        injected = injected.replace(/\{\{logoUrl\}\}/g, config.logoUrl);
    }
    return injected;
}
/**
 * Inject menu items
 */ function injectMenu(html, menu) {
    const menuHTML = typeof menu === 'string' ? menu : generateMenuHTML(menu);
    // Try to replace placeholders first
    if (html.includes('{{menu}}') || html.includes('{{menuItems}}')) {
        html = html.replace(/\{\{\s*(menu|menuItems)\s*\}\}/g, menuHTML);
    } else {
        // If no placeholder, force inject at the top of body or top of string
        if (html.includes('<body')) {
            html = html.replace(/(<body[^>]*>)/i, `$1${menuHTML}`);
        } else {
            html = menuHTML + html;
        }
    }
    return html;
}
/**
 * Generate menu HTML from menu data
 */ function generateMenuHTML(menu) {
    if (!menu || menu.length === 0) {
        return '<nav><ul></ul></nav>';
    }
    const items = menu.map((item)=>`
    <li>
      <a href="${item.url || '#'}" ${item.external ? 'target="_blank" rel="noopener"' : ''}>
        ${item.label || item.name}
      </a>
    </li>
  `).join('');
    return `
    <nav class="main-menu">
      <ul>
        ${items}
      </ul>
    </nav>
  `;
}
/**
 * Inject footer links
 */ function injectFooterLinks(html, footerLinks) {
    const footerHTML = typeof footerLinks === 'string' ? footerLinks : generateFooterHTML(footerLinks);
    html = html.replace(/\{\{\s*footerLinks\s*\}\}/g, footerHTML);
    return html;
}
/**
 * Generate footer HTML from footer links data
 */ function generateFooterHTML(footerLinks) {
    if (!footerLinks || footerLinks.length === 0) {
        return '';
    }
    const links = footerLinks.map((link)=>`
    <a href="${link.url || '#'}" ${link.external ? 'target="_blank" rel="noopener"' : ''}>
      ${link.label || link.name}
    </a>
  `).join('');
    return `<div class="footer-links">${links}</div>`;
}
/**
 * Inject products list
 */ function injectProducts(html, products) {
    const productsHTML = generateProductsHTML(products);
    html = html.replace(/\{\{\s*products\s*\}\}/g, productsHTML);
    return html;
}
/**
 * Generate products HTML from products data
 */ function generateProductsHTML(products) {
    if (!products || products.length === 0) {
        return '<div class="no-products py-20 text-center border-2 border-dashed border-gray-100 rounded-3xl"><p class="text-gray-400 font-medium italic">No live products found in this category.</p></div>';
    }
    const items = products.map((product)=>{
        const productUrl = `/products/${product.slug || product.id}`;
        const productImage = product.image || '';
        const productPrice = product.price || '0.00';
        return `
    <div class="group bg-white border border-gray-100 rounded-2xl overflow-hidden hover:shadow-2xl hover:shadow-blue-500/5 transition-all duration-500 flex flex-col h-full" data-product-id="${product.id}">
      <div class="aspect-square bg-gray-50 relative overflow-hidden p-8">
        <a href="${productUrl}" class="block h-full">
          ${productImage ? `<img src="${productImage}" alt="${product.name}" class="w-full h-full object-contain group-hover:scale-110 transition-transform duration-700" />` : ''}
          <div class="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-500"></div>
        </a>
        <button 
          class="absolute bottom-6 left-6 right-6 translate-y-32 group-hover:translate-y-0 bg-gray-900 text-white py-4 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-2lx transition-all duration-500 hover:bg-blue-600 add-to-cart" 
          data-add-to-cart
          data-product-id="${product.id}"
          data-product-name="${product.name}"
          data-product-price="${productPrice}"
          data-product-image="${productImage}"
          data-product-sku="${product.sku || ''}"
        >
          Add to Cart
        </button>
      </div>
      <div class="p-6 flex-1 flex flex-col justify-between">
        <div>
          <a href="${productUrl}" class="block group/title">
            <h3 class="font-black text-gray-900 text-base mb-2 group-hover/title:text-blue-600 transition-colors line-clamp-2 leading-tight uppercase tracking-tight">${product.name}</h3>
          </a>
          <p class="text-[12px] font-medium text-gray-400 mb-4 line-clamp-2 leading-relaxed">${product.description || ''}</p>
        </div>
        <div class="flex items-center justify-between mt-auto pt-5 border-t border-gray-50">
          <div class="flex flex-col">
            <span class="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-0.5">Price</span>
            <span class="text-2xl font-black text-gray-900 tracking-tighter">$${productPrice}</span>
          </div>
          <button 
            class="w-10 h-10 rounded-xl bg-gray-50 hover:bg-blue-600 hover:text-white flex items-center justify-center text-gray-400 transition-all duration-500"
            data-add-to-cart
            data-product-id="${product.id}"
            data-product-name="${product.name}"
            data-product-price="${productPrice}"
            data-product-image="${productImage}"
          >
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"></path></svg>
          </button>
        </div>
      </div>
    </div>
  `;
    }).join('');
    return `<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 products-grid mb-10">${items}</div>`;
}
/**
 * Inject single product
 */ function injectProduct(html, product) {
    if (!product) {
        return html;
    }
    // Replace product placeholders
    html = html.replace(/\{\{\s*product\.name\s*\}\}/g, product.name || '');
    html = html.replace(/\{\{\s*product\.price\s*\}\}/g, product.price || '0.00');
    html = html.replace(/\{\{\s*product\.description\s*\}\}/g, product.description || '');
    html = html.replace(/\{\{\s*product\.image\s*\}\}/g, product.image || '');
    return html;
}
/**
 * Inject categories
 */ function injectCategories(html, categories) {
    const categoriesHTML = generateCategoriesHTML(categories);
    html = html.replace(/\{\{\s*categories\s*\}\}/g, categoriesHTML);
    return html;
}
/**
 * Generate categories HTML
 */ function generateCategoriesHTML(categories) {
    if (!categories || categories.length === 0) {
        return '';
    }
    const items = categories.map((category)=>`
    <div class="category-card">
      <a href="/categories/${category.slug || category.id}">
        ${category.image ? `<img src="${category.image}" alt="${category.name}" />` : ''}
        <h3>${category.name}</h3>
      </a>
    </div>
  `).join('');
    return `<div class="categories-grid">${items}</div>`;
}
/**
 * Inject category
 */ function injectCategory(html, category) {
    if (!category) {
        return html;
    }
    html = html.replace(/\{\{\s*category\.name\s*\}\}/g, category.name || '');
    html = html.replace(/\{\{\s*category\.description\s*\}\}/g, category.description || '');
    return html;
}
/**
 * Inject featured products
 */ function injectFeaturedProducts(html, products) {
    if (!/\{\{\s*featuredProducts\s*\}\}/.test(html)) return html;
    const productsHTML = generateFeaturedSliderHTML(products);
    return html.replace(/\{\{\s*featuredProducts\s*\}\}/g, productsHTML);
}
/**
 * Generate a premium glassmorphic slider for featured products
 */ function generateFeaturedSliderHTML(products) {
    if (!products || products.length === 0) {
        return '<div class="no-products py-20 text-center bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl text-white"><p class="font-medium italic">Finding amazing items for you...</p></div>';
    }
    const sliderId = `slider-${Math.random().toString(36).substr(2, 9)}`;
    const items = products.map((product)=>`
    <div class="min-w-[280px] md:min-w-[320px] bg-white/10 backdrop-blur-xl border border-white/20 p-6 rounded-[32px] shadow-2xl transition-all duration-500 hover:-translate-y-2 hover:bg-white/20 group select-none" data-product-id="${product.id}">
      <div class="aspect-square rounded-2xl bg-white/5 flex items-center justify-center p-8 mb-6 relative overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
        ${product.image ? `<img src="${product.image}" alt="${product.name}" class="w-full h-full object-contain drop-shadow-2xl transition-transform duration-700 group-hover:scale-110" />` : ''}
      </div>
      <div class="space-y-4 text-left">
        <h4 class="font-black text-white text-lg tracking-tight uppercase line-clamp-1 group-hover:text-blue-300 transition-colors">${product.name}</h4>
        <div class="flex items-center justify-between">
          <div class="flex flex-col">
            <span class="text-[10px] font-black text-blue-400 uppercase tracking-widest">Limited Deal</span>
            <span class="text-2xl font-black text-white tracking-tighter">$${product.price}</span>
          </div>
          <button class="w-12 h-12 rounded-full bg-white text-gray-900 flex items-center justify-center shadow-xl hover:bg-blue-600 hover:text-white transition-all transform active:scale-95 add-to-cart" data-product-id="${product.id}">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M12 4v16m8-8H4"></path></svg>
          </button>
        </div>
      </div>
    </div>
  `).join('');
    return `
    <div class="relative w-full group/slider">
      <!-- Navigation Buttons -->
      <button onclick="document.getElementById('${sliderId}').scrollBy({left: -350, behavior: 'smooth'})" class="absolute top-1/2 -left-4 md:-left-8 -translate-y-1/2 w-12 h-12 md:w-16 md:h-16 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full flex items-center justify-center text-white shadow-2xl z-20 hover:bg-white hover:text-gray-900 transition-all opacity-0 group-hover/slider:opacity-100">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15 19l-7-7 7-7"></path></svg>
      </button>
      <button onclick="document.getElementById('${sliderId}').scrollBy({left: 350, behavior: 'smooth'})" class="absolute top-1/2 -right-4 md:-right-8 -translate-y-1/2 w-12 h-12 md:w-16 md:h-16 bg-white/10 backdrop-blur-xl border border-white/20 rounded-full flex items-center justify-center text-white shadow-2xl z-20 hover:bg-white hover:text-gray-900 transition-all opacity-0 group-hover/slider:opacity-100">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7"></path></svg>
      </button>

      <!-- Slider Area -->
      <div id="${sliderId}" class="flex gap-8 overflow-x-auto no-scrollbar scroll-smooth snap-x snap-mandatory pt-4 pb-12 px-4 md:px-0">
        ${items}
      </div>

      <style>
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        [data-product-id] { snap-align: start; }
      </style>
    </div>
  `;
}
/**
 * Inject related products
 */ function injectRelatedProducts(html, products) {
    const productsHTML = generateProductsHTML(products);
    html = html.replace(/\{\{\s*relatedProducts\s*\}\}/g, productsHTML);
    return html;
}
/**
 * Inject testimonials
 */ function injectTestimonials(html, testimonials) {
    const testimonialsHTML = generateTestimonialsHTML(testimonials);
    html = html.replace(/\{\{\s*testimonials\s*\}\}/g, testimonialsHTML);
    return html;
}
/**
 * Generate testimonials HTML
 */ function generateTestimonialsHTML(testimonials) {
    if (!testimonials || testimonials.length === 0) {
        return '<div class="no-testimonials">No testimonials yet</div>';
    }
    const items = testimonials.map((testimonial, index)=>`
    <div class="testimonial-card" data-testimonial-id="${testimonial.id || index}">
      ${testimonial.avatar ? `<img src="${testimonial.avatar}" alt="${testimonial.name || 'Customer'}" class="testimonial-avatar" />` : ''}
      <div class="testimonial-content">
        <p class="testimonial-text">"${testimonial.text || testimonial.content || testimonial.message || ''}"</p>
        <div class="testimonial-author">
          <strong>${testimonial.name || 'Anonymous'}</strong>
          ${testimonial.role ? `<span class="testimonial-role">${testimonial.role}</span>` : ''}
          ${testimonial.rating ? `<div class="testimonial-rating">${'★'.repeat(testimonial.rating)}</div>` : ''}
        </div>
      </div>
    </div>
  `).join('');
    return `<div class="testimonials-grid">${items}</div>`;
}
/**
 * Inject generic content (for custom pages like about, contact)
 */ function injectContent(html, content) {
    let contentHTML = '';
    if (typeof content === 'string') {
        // Simple string content
        contentHTML = `<div class="page-content">${content}</div>`;
    } else if (typeof content === 'object') {
        // Object with title, content, etc.
        if (content.title) {
            contentHTML += `<h1>${content.title}</h1>`;
        }
        if (content.content || content.text) {
            contentHTML += `<div class="page-content">${content.content || content.text}</div>`;
        }
        if (content.sections && Array.isArray(content.sections)) {
            contentHTML += content.sections.map((section)=>`
        <section class="content-section">
          ${section.title ? `<h2>${section.title}</h2>` : ''}
          ${section.content ? `<div>${section.content}</div>` : ''}
        </section>
      `).join('');
        }
    }
    if (contentHTML) {
        html = html.replace(/\{\{\s*content\s*\}\}/g, contentHTML);
    }
    return html;
}
/**
 * Inject breadcrumbs
 */ function injectBreadcrumbs(html, breadcrumbs) {
    if (!/\{\{\s*breadcrumbs\s*\}\}/.test(html)) return html;
    const breadcrumbsHTML = generateBreadcrumbsHTML(breadcrumbs);
    return html.replace(/\{\{\s*breadcrumbs\s*\}\}/g, breadcrumbsHTML);
}
/**
 * Generate Breadcrumbs HTML
 * Provides static fallback if no data is provided
 */ function generateBreadcrumbsHTML(breadcrumbs) {
    const items = breadcrumbs && breadcrumbs.length > 0 ? breadcrumbs : [
        {
            label: 'Home',
            url: '/'
        },
        {
            label: 'Shop',
            url: '/products'
        },
        {
            label: 'Category',
            url: '#'
        }
    ];
    return items.map((item, index)=>{
        const isLast = index === items.length - 1;
        const colorClass = isLast ? 'text-gray-900 font-bold' : 'text-gray-500 hover:text-blue-600';
        return `
      <li class="flex items-center">
        ${index > 0 ? `<svg class="w-4 h-4 mx-2 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>` : ''}
        ${isLast ? `
          <span class="${colorClass}">${item.label}</span>
        ` : `
          <a href="${item.url}" class="${colorClass} transition-colors">${item.label}</a>
        `}
      </li>
    `;
    }).join('');
}
/**
 * Inject custom data by key
 */ function injectCustomData(html, key, value) {
    const placeholder = `{{${key}}}`;
    if (typeof value === 'string' || typeof value === 'number') {
        html = html.replace(new RegExp(placeholder, 'g'), String(value));
    } else if (Array.isArray(value)) {
        // For arrays, generate HTML (simplified)
        html = html.replace(new RegExp(placeholder, 'g'), JSON.stringify(value));
    } else if (typeof value === 'object') {
        // For objects, replace nested placeholders
        Object.keys(value).forEach((subKey)=>{
            const nestedPlaceholder = `{{${key}.${subKey}}}`;
            html = html.replace(new RegExp(nestedPlaceholder, 'g'), String(value[subKey] || ''));
        });
    }
    return html;
}
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/process [external] (process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("process", () => require("process"));

module.exports = mod;
}),
"[externals]/tls [external] (tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tls", () => require("tls"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/net [external] (net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("net", () => require("net"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/dns [external] (dns, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("dns", () => require("dns"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/node:assert [external] (node:assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:assert", () => require("node:assert"));

module.exports = mod;
}),
"[externals]/node:http [external] (node:http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:http", () => require("node:http"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/node:net [external] (node:net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:net", () => require("node:net"));

module.exports = mod;
}),
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:util [external] (node:util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:util", () => require("node:util"));

module.exports = mod;
}),
"[externals]/node:querystring [external] (node:querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:querystring", () => require("node:querystring"));

module.exports = mod;
}),
"[externals]/node:events [external] (node:events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:events", () => require("node:events"));

module.exports = mod;
}),
"[externals]/node:zlib [external] (node:zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:zlib", () => require("node:zlib"));

module.exports = mod;
}),
"[externals]/node:perf_hooks [external] (node:perf_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:perf_hooks", () => require("node:perf_hooks"));

module.exports = mod;
}),
"[externals]/node:util/types [external] (node:util/types, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:util/types", () => require("node:util/types"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/node:diagnostics_channel [external] (node:diagnostics_channel, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:diagnostics_channel", () => require("node:diagnostics_channel"));

module.exports = mod;
}),
"[externals]/node:tls [external] (node:tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:tls", () => require("node:tls"));

module.exports = mod;
}),
"[externals]/node:http2 [external] (node:http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:http2", () => require("node:http2"));

module.exports = mod;
}),
"[externals]/string_decoder [external] (string_decoder, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("string_decoder", () => require("string_decoder"));

module.exports = mod;
}),
"[externals]/node:worker_threads [external] (node:worker_threads, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:worker_threads", () => require("node:worker_threads"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[externals]/node:console [external] (node:console, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:console", () => require("node:console"));

module.exports = mod;
}),
"[project]/lib/firebaseConfig.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "app",
    ()=>app,
    "auth",
    ()=>auth,
    "checkFirebaseConnection",
    ()=>checkFirebaseConnection,
    "db",
    ()=>db,
    "ensureFirebaseOnline",
    ()=>ensureFirebaseOnline
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$app$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/app/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/app/dist/esm/index.esm2017.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.node.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$auth$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/auth/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$node$2d$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/auth/dist/node-esm/index.js [app-rsc] (ecmascript)");
;
;
;
const firebaseConfig = {
    apiKey: ("TURBOPACK compile-time value", "AIzaSyDp_EH2NNsSWJ-o_wUT2wzFOiLQUQ8Mewk") || "",
    authDomain: ("TURBOPACK compile-time value", "storefront-64d56.firebaseapp.com") || "storefront-64d56.firebaseapp.com",
    projectId: ("TURBOPACK compile-time value", "storefront-64d56") || "storefront-64d56",
    storageBucket: ("TURBOPACK compile-time value", "storefront-64d56.firebasestorage.app") || "storefront-64d56.firebasestorage.app",
    messagingSenderId: ("TURBOPACK compile-time value", "695330621735") || "695330621735",
    appId: ("TURBOPACK compile-time value", "1:695330621735:web:6dbc73154a74c7ae1c8102") || "1:695330621735:web:6dbc73154a74c7ae1c8102",
    measurementId: ("TURBOPACK compile-time value", "G-Z851FP9YGC") || "G-Z851FP9YGC"
};
// Validate that required config is present
if (!firebaseConfig.apiKey) {
    if ("TURBOPACK compile-time truthy", 1) {
        console.warn("Firebase API key is missing. Please set NEXT_PUBLIC_FIREBASE_API_KEY in your .env.local file");
    }
}
// Initialize Firebase only if API key is present, otherwise use a placeholder config for build
let app;
let db;
let auth;
try {
    if (firebaseConfig.apiKey) {
        app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["initializeApp"])(firebaseConfig);
        db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getFirestore"])(app);
        auth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$node$2d$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAuth"])(app);
    } else {
        // Use placeholder config for build time when API key is missing
        const placeholderConfig = {
            apiKey: "placeholder-key-for-build",
            authDomain: firebaseConfig.authDomain,
            projectId: firebaseConfig.projectId,
            storageBucket: firebaseConfig.storageBucket,
            messagingSenderId: firebaseConfig.messagingSenderId,
            appId: firebaseConfig.appId,
            measurementId: firebaseConfig.measurementId
        };
        app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["initializeApp"])(placeholderConfig, 'placeholder');
        db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getFirestore"])(app);
        auth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$node$2d$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAuth"])(app);
    }
} catch (error) {
    // During build, if Firebase initialization fails, try with placeholder
    // This allows the build to complete even without valid Firebase config
    if (("TURBOPACK compile-time value", "development") === 'production' || process.env.NEXT_PHASE === 'phase-production-build') {
        console.warn("Firebase initialization failed during build. Using placeholder config.");
        const placeholderConfig = {
            apiKey: "placeholder-key-for-build",
            authDomain: firebaseConfig.authDomain,
            projectId: firebaseConfig.projectId,
            storageBucket: firebaseConfig.storageBucket,
            messagingSenderId: firebaseConfig.messagingSenderId,
            appId: firebaseConfig.appId,
            measurementId: firebaseConfig.measurementId
        };
        try {
            app = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$app$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["initializeApp"])(placeholderConfig, 'placeholder');
            db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getFirestore"])(app);
            auth = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$auth$2f$dist$2f$node$2d$esm$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAuth"])(app);
        } catch (placeholderError) {
            // If even placeholder fails, we need to provide defaults
            // This should rarely happen, but ensures build doesn't fail
            throw new Error("Firebase initialization failed. Please check your Firebase configuration.");
        }
    } else {
        throw error;
    }
}
;
const ensureFirebaseOnline = async ()=>{
    try {
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["enableNetwork"])(db);
        return true;
    } catch (error) {
        // Silently fail - network might already be enabled or unavailable
        return false;
    }
};
const checkFirebaseConnection = async ()=>{
    try {
        // Try a simple read operation to check connectivity
        const { doc, getDoc } = await __turbopack_context__.A("[project]/node_modules/firebase/firestore/dist/index.mjs [app-rsc] (ecmascript, async loader)");
        const testRef = doc(db, "_test", "connection");
        await Promise.race([
            getDoc(testRef),
            new Promise((_, reject)=>setTimeout(()=>reject(new Error('timeout')), 5000))
        ]);
        return true;
    } catch (error) {
        // If it's a timeout or unavailable error, Firebase is likely offline
        if (error.message === 'timeout' || error.code === 'unavailable') {
            return false;
        }
        // Other errors (like permission-denied) mean Firebase is online but we don't have access
        return true;
    }
};
;
}),
"[project]/services/pageSettings.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Page Settings Service
 * 
 * Manages page settings and routing configuration for storefronts.
 * Handles both static and dynamic content pages.
 */ __turbopack_context__.s([
    "createDefaultPageSettings",
    ()=>createDefaultPageSettings,
    "deletePageSetting",
    ()=>deletePageSetting,
    "ensureAllPagesHaveSettings",
    ()=>ensureAllPagesHaveSettings,
    "getPageContent",
    ()=>getPageContent,
    "getPageSetting",
    ()=>getPageSetting,
    "getPageSettingByRoute",
    ()=>getPageSettingByRoute,
    "getPageSettingsByStorefront",
    ()=>getPageSettingsByStorefront,
    "savePageSetting",
    ()=>savePageSetting,
    "updatePageSetting",
    ()=>updatePageSetting
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.node.mjs [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/firebaseConfig.ts [app-rsc] (ecmascript)");
;
;
const COLLECTION_NAME = "page_settings";
async function savePageSetting(setting) {
    try {
        const id = `${setting.userId}_${setting.storefrontId}_${setting.pageType}`;
        const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
        const pageSetting = {
            ...setting,
            id,
            createdAt: new Date(),
            updatedAt: new Date()
        };
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["setDoc"])(pageSettingRef, pageSetting);
        return id;
    } catch (error) {
        console.error("Error saving page setting:", error);
        throw error;
    }
}
async function getPageSetting(storefrontId, pageType, userId) {
    try {
        // If userId is provided, use the new ID format. Otherwise, fallback to the old one or query.
        if (userId) {
            const id = `${userId}_${storefrontId}_${pageType}`;
            const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
            const pageSettingDoc = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getDoc"])(pageSettingRef);
            if (pageSettingDoc.exists()) {
                return pageSettingDoc.data();
            }
        }
        // Fallback search by storefrontId and pageType if userId is not known or for backward compatibility
        const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("storefrontId", "==", storefrontId), (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("pageType", "==", pageType));
        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getDocs"])(q);
        if (!querySnapshot.empty) {
            return querySnapshot.docs[0].data();
        }
        return null;
    } catch (error) {
        console.error("Error getting page setting:", error);
        return null;
    }
}
async function getPageSettingsByStorefront(storefrontId, onlyEnabled = true, userId) {
    try {
        let q;
        const conditions = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("storefrontId", "==", storefrontId)
        ];
        if (userId) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("userId", "==", userId));
        }
        if (onlyEnabled) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("settings.enabled", "==", true));
        }
        q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME), ...conditions);
        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getDocs"])(q);
        const settings = [];
        querySnapshot.forEach((doc)=>{
            settings.push(doc.data());
        });
        return settings;
    } catch (error) {
        console.error("Error getting page settings:", error);
        return [];
    }
}
async function getPageSettingByRoute(storefrontId, route, onlyEnabled = true, userId) {
    try {
        let q;
        const conditions = [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("storefrontId", "==", storefrontId),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("route", "==", route)
        ];
        if (userId) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("userId", "==", userId));
        }
        if (onlyEnabled) {
            conditions.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["where"])("settings.enabled", "==", true));
        }
        q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME), ...conditions);
        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getDocs"])(q);
        if (!querySnapshot.empty) {
            return querySnapshot.docs[0].data();
        }
        return null;
    } catch (error) {
        console.error("Error getting page setting by route:", error);
        return null;
    }
}
async function updatePageSetting(id, updates) {
    try {
        const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["updateDoc"])(pageSettingRef, {
            ...updates,
            updatedAt: new Date()
        });
    } catch (error) {
        console.error("Error updating page setting:", error);
        throw error;
    }
}
async function deletePageSetting(id) {
    try {
        const pageSettingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["doc"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], COLLECTION_NAME, id);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["deleteDoc"])(pageSettingRef);
    } catch (error) {
        console.error("Error deleting page setting:", error);
        throw error;
    }
}
async function getPageContent(pageSetting) {
    try {
        if (pageSetting.contentType === 'static') {
            return pageSetting.dataSource?.staticData || null;
        }
        if (pageSetting.contentType === 'dynamic') {
            const { dataSource } = pageSetting;
            if (dataSource?.type === 'firebase' && dataSource.collection) {
                // Fetch from Firebase collection
                const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["collection"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$firebaseConfig$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["db"], dataSource.collection));
                const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$node$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getDocs"])(q);
                const data = [];
                querySnapshot.forEach((doc)=>{
                    data.push({
                        id: doc.id,
                        ...doc.data()
                    });
                });
                return data;
            }
            if (dataSource?.type === 'api' && dataSource.apiEndpoint) {
                // Fetch from API
                const response = await fetch(dataSource.apiEndpoint);
                if (response.ok) {
                    return await response.json();
                }
            }
        }
        return null;
    } catch (error) {
        console.error("Error getting page content:", error);
        return null;
    }
}
async function createDefaultPageSettings(storefrontId, userId) {
    const defaultPages = [
        {
            pageType: 'testimonial',
            route: '/testimonials',
            contentType: 'dynamic',
            parentId: null,
            order: 1,
            dataSource: {
                type: 'firebase',
                collection: `testimonials_${storefrontId}`
            },
            settings: {
                enabled: false,
                showInMenu: false,
                showInFooter: true,
                metaTitle: 'Testimonials',
                metaDescription: 'Customer testimonials and reviews'
            }
        },
        {
            pageType: 'about',
            route: '/about',
            contentType: 'static',
            parentId: null,
            order: 2,
            dataSource: {
                type: 'static',
                staticData: {
                    title: 'About Us',
                    content: 'Welcome to our store...'
                }
            },
            settings: {
                enabled: false,
                showInMenu: true,
                showInFooter: true,
                metaTitle: 'About Us',
                metaDescription: 'Learn more about our company'
            }
        },
        {
            pageType: 'contact',
            route: '/contact',
            contentType: 'static',
            parentId: null,
            order: 3,
            dataSource: {
                type: 'static',
                staticData: {
                    title: 'Contact Us',
                    content: 'Get in touch with us...'
                }
            },
            settings: {
                enabled: false,
                showInMenu: true,
                showInFooter: true,
                metaTitle: 'Contact Us',
                metaDescription: 'Get in touch with us'
            }
        }
    ];
    for (const page of defaultPages){
        try {
            await savePageSetting({
                storefrontId,
                userId,
                ...page
            });
        } catch (error) {
            console.error(`Error creating default page ${page.pageType}:`, error);
        }
    }
}
async function ensureAllPagesHaveSettings(storefrontId, userId, availablePageTypes) {
    for (const pageType of availablePageTypes){
        try {
            const existing = await getPageSetting(storefrontId, pageType);
            if (!existing) {
                console.log(`Creating missing setting for page: ${pageType}`);
                // Map common routes
                let route = `/${pageType}`;
                if (pageType === 'home') route = '/';
                await savePageSetting({
                    storefrontId,
                    userId,
                    pageType,
                    parentId: null,
                    order: 0,
                    route,
                    contentType: 'static',
                    settings: {
                        enabled: true,
                        showInMenu: pageType === 'home' ? false : true,
                        showInFooter: true,
                        metaTitle: pageType.charAt(0).toUpperCase() + pageType.slice(1)
                    }
                });
            }
        } catch (error) {
            console.error(`Error ensuring setting for ${pageType}:`, error);
        }
    }
}
}),
"[project]/app/storefront/[[...path]]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Dynamic Storefront Page Route
 * 
 * This route handles all storefront pages (homepage, products, cart, etc.)
 * It loads the page HTML from storage and injects dynamic data.
 */ __turbopack_context__.s([
    "default",
    ()=>StorefrontPage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/headers.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$storefront$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/storefront.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$dataInjector$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/dataInjector.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/services/pageSettings.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
async function StorefrontPage({ params }) {
    const promisedParams = await params;
    const headersList = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$headers$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["headers"])();
    const storefrontId = headersList.get('x-storefront-id');
    const isCustomDomain = headersList.get('x-is-custom-domain') === 'true';
    // Log for debugging
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('🏪 Storefront page request:', {
            storefrontId,
            isCustomDomain,
            path: promisedParams.path,
            headers: {
                'x-storefront-id': storefrontId,
                'x-storefront-subdomain': headersList.get('x-storefront-subdomain')
            }
        });
    }
    if (!storefrontId) {
        console.error('❌ No storefront ID in headers');
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    // Determine page path (pretty URL - no .html extension)
    const pagePath = promisedParams.path && promisedParams.path.length > 0 ? `/${promisedParams.path.join('/')}` : '/';
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('📄 Resolved page path:', {
            pagePath,
            rawPath: promisedParams.path
        });
    }
    // Load storefront configuration
    const config = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$storefront$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["loadStorefrontConfig"])(storefrontId);
    if (!config) {
        console.error('❌ Storefront config not found for:', storefrontId);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    if ("TURBOPACK compile-time truthy", 1) {
        console.log('✅ Storefront config loaded:', {
            companyName: config.companyName,
            subdomain: config.subdomain
        });
    }
    // Check if this is a custom page (testimonial, about, contact, etc.)
    const pageSetting = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getPageSettingByRoute"])(storefrontId, pagePath, true, config.userId);
    let pageType;
    let pageData;
    let customPageContent = null;
    if (pageSetting) {
        // Custom page (testimonial, about, etc.)
        pageType = pageSetting.pageType;
        // Try to load custom page HTML, fallback to default page type
        pageData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$storefront$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["loadStorefrontPage"])(storefrontId, pageType);
        // If custom page HTML doesn't exist, try to load from default pages
        if (!pageData) {
            // Try common page types as fallback
            const fallbackTypes = [
                'testimonial',
                'about',
                'contact'
            ];
            for (const fallbackType of fallbackTypes){
                if (pageType.includes(fallbackType)) {
                    pageData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$storefront$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["loadStorefrontPage"])(storefrontId, fallbackType);
                    if (pageData) break;
                }
            }
        }
        // If still no page data, use a generic template
        if (!pageData) {
            pageData = {
                html: generateGenericPageHTML(pageType, pageSetting),
                css: '',
                metadata: {
                    title: pageSetting.settings.metaTitle || pageType,
                    description: pageSetting.settings.metaDescription || ''
                }
            };
        }
        // Fetch content for custom page
        if (pageSetting.contentType === 'dynamic') {
            customPageContent = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getPageContent"])(pageSetting);
        } else if (pageSetting.contentType === 'static') {
            customPageContent = pageSetting.dataSource?.staticData || null;
        }
    } else {
        // Standard page (homepage, products, cart, etc.)
        pageType = getPageTypeFromPath(pagePath);
        pageData = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$storefront$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["loadStorefrontPage"])(storefrontId, pageType);
        if (!pageData) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
        }
    }
    // Fetch dynamic data based on page type
    const dynamicData = await fetchDynamicDataForPage(storefrontId, pageType, pagePath, customPageContent);
    // Inject dynamic data into HTML
    const finalData = {
        ...dynamicData
    };
    finalData.menu = generateMenuHTML(dynamicData.menu || [], config);
    const renderedHTML = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$dataInjector$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["injectDynamicData"])(pageData.html, finalData, config);
    // Return rendered HTML
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        dangerouslySetInnerHTML: {
            __html: renderedHTML
        },
        suppressHydrationWarning: true
    }, void 0, false, {
        fileName: "[project]/app/storefront/[[...path]]/page.tsx",
        lineNumber: 142,
        columnNumber: 5
    }, this);
}
/**
 * Get page type from URL path
 * Handles pretty URLs without .html extension
 */ function getPageTypeFromPath(path) {
    // Normalize path (remove trailing slash except for root)
    const normalizedPath = path === '/' ? '/' : path.replace(/\/$/, '');
    const pathMap = {
        '/': 'homepage',
        '/categories': 'categories',
        '/products': 'products',
        '/cart': 'cart',
        '/checkout': 'checkout',
        '/account': 'account',
        '/search': 'search'
    };
    // Check exact match first
    if (pathMap[normalizedPath]) {
        return pathMap[normalizedPath];
    }
    // Check for product detail (e.g., /products/slug)
    if (normalizedPath.startsWith('/products/')) {
        return 'product-detail';
    }
    // Check for category detail (e.g., /categories/slug)
    if (normalizedPath.startsWith('/categories/')) {
        return 'category-detail';
    }
    // If it's a simple one-level path like /about, try to use the path name as type
    if (normalizedPath.startsWith('/') && !normalizedPath.includes('/', 1)) {
        return normalizedPath.substring(1);
    }
    // Default to homepage
    return 'homepage';
}
/**
 * Generate generic HTML for custom pages that don't have generated HTML
 */ function generateGenericPageHTML(pageType, pageSetting) {
    const title = pageSetting.settings.metaTitle || pageType;
    const description = pageSetting.settings.metaDescription || '';
    return `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${title}</title>
      <meta name="description" content="${description}">
    </head>
    <body>
      <header>
        <nav>{{menu}}</nav>
      </header>
      <main>
        <h1>${title}</h1>
        <div class="page-content">
          {{content}}
        </div>
      </main>
      <footer>
        {{footerLinks}}
      </footer>
    </body>
    </html>
  `;
}
/**
 * Fetch dynamic data for a specific page
 */ async function fetchDynamicDataForPage(storefrontId, pageType, pagePath, customPageContent) {
    const data = {};
    try {
        // Fetch common data (menu, footer links)
        const [menu, footerLinks, siteSettings, featuredProducts] = await Promise.all([
            fetchMenu(storefrontId),
            fetchFooterLinks(storefrontId),
            fetchSiteSettings(storefrontId),
            fetchFeaturedProducts(storefrontId)
        ]);
        data.menu = menu;
        data.footerLinks = footerLinks;
        data.siteSettings = siteSettings;
        data.featuredProducts = featuredProducts;
        // Calculate breadcrumbs from path
        const pathSegments = pagePath.split('/').filter(Boolean);
        const breadcrumbs = pathSegments.map((segment, index)=>({
                label: segment.charAt(0).toUpperCase() + segment.slice(1).replace(/-/g, ' '),
                url: '/' + pathSegments.slice(0, index + 1).join('/')
            }));
        // Add Home as the root breadcrumb
        breadcrumbs.unshift({
            label: 'Home',
            url: '/'
        });
        data.breadcrumbs = breadcrumbs;
        // Handle custom pages (testimonial, about, contact, etc.)
        if (customPageContent !== null && customPageContent !== undefined) {
            // Inject custom page content
            if (pageType === 'testimonial') {
                data.testimonials = customPageContent;
                data.content = customPageContent; // Generic content placeholder
            } else {
                data.content = customPageContent;
            }
        }
        // Fetch page-specific data
        switch(pageType){
            case 'homepage':
                data.categories = await fetchCategories(storefrontId, {
                    limit: 6
                });
                break;
            case 'products':
                data.products = await fetchProducts(storefrontId, {});
                data.categories = await fetchCategories(storefrontId);
                break;
            case 'product-detail':
                const productSlug = pagePath.split('/').pop();
                data.product = await fetchProductBySlug(storefrontId, productSlug || '');
                data.relatedProducts = await fetchRelatedProducts(storefrontId, productSlug || '');
                break;
            case 'categories':
                data.categories = await fetchCategories(storefrontId);
                break;
            case 'category-detail':
                const categorySlug = pagePath.split('/').pop();
                data.category = await fetchCategoryBySlug(storefrontId, categorySlug || '');
                data.products = await fetchProducts(storefrontId, {
                    category: categorySlug
                });
                break;
            case 'testimonial':
                // Testimonials are already in customPageContent
                if (!data.testimonials) {
                    data.testimonials = customPageContent || [];
                }
                break;
            case 'cart':
                break;
            case 'search':
                break;
        }
    } catch (error) {
        console.error('Error fetching dynamic data:', error);
    // Return empty data on error
    }
    return data;
}
// Data fetching functions (implement these based on your API)
async function fetchMenu(storefrontId) {
    const settings = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$services$2f$pageSettings$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getPageSettingsByStorefront"])(storefrontId);
    // Filter only those that should be in menu
    const menuSettings = settings.filter((s)=>s.settings.showInMenu);
    // Map to common format
    const allItems = menuSettings.map((s)=>({
            id: s.id,
            parentId: s.parentId,
            order: s.order || 0,
            label: s.settings.metaTitle || s.pageType,
            route: s.route,
            children: []
        }));
    // Build tree
    const menuTree = [
        {
            label: 'Home',
            route: '/',
            order: -1,
            children: []
        }
    ];
    const idMap = new Map();
    allItems.forEach((item)=>idMap.set(item.id, item));
    allItems.forEach((item)=>{
        if (item.parentId && idMap.has(item.parentId)) {
            idMap.get(item.parentId).children.push(item);
        } else {
            menuTree.push(item);
        }
    });
    // Sort by order
    const sortRecursive = (items)=>{
        items.sort((a, b)=>(a.order || 0) - (b.order || 0));
        items.forEach((item)=>{
            if (item.children.length > 0) sortRecursive(item.children);
        });
    };
    sortRecursive(menuTree);
    return menuTree;
}
/**
 * Generate Tailwind CSS Menu HTML
 */ function generateMenuHTML(menuItems, config) {
    const primaryColor = config.theme?.primaryColor || '#3b82f6';
    const isSinglePage = config.layout === 'single-page';
    const formatRoute = (route)=>{
        if (!isSinglePage) return route;
        if (route === '/') return '#home';
        // Convert /products to #products, etc.
        return '#' + route.replace(/^\//, '');
    };
    const renderDesktopItem = (item)=>{
        const route = formatRoute(item.route);
        if (item.children && item.children.length > 0) {
            return `
        <div class="relative group/menu">
          <button class="flex items-center gap-1 text-sm font-bold text-gray-700 hover:text-[${primaryColor}] transition-colors uppercase tracking-widest px-4 py-2">
            ${item.label}
            <svg class="w-4 h-4 transition-transform group-hover/menu:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          <div class="absolute left-0 top-full hidden group-hover/menu:block min-w-[220px] bg-white shadow-2xl border border-gray-100 rounded-2xl py-3 z-50 animate-in fade-in slide-in-from-top-2 duration-200">
            ${item.children.map((child)=>`
              <a href="${formatRoute(child.route)}" class="block px-6 py-2.5 text-xs font-bold text-gray-600 hover:text-[${primaryColor}] hover:bg-gray-50 transition-all uppercase tracking-widest">
                ${child.label}
              </a>
            `).join('')}
          </div>
        </div>
      `;
        }
        return `
      <a href="${route}" class="text-sm font-bold text-gray-700 hover:text-[${primaryColor}] transition-colors uppercase tracking-widest px-4 py-2">
        ${item.label}
      </a>
    `;
    };
    const renderMobileItem = (item)=>{
        const route = formatRoute(item.route);
        if (item.children && item.children.length > 0) {
            return `
        <div class="space-y-1 py-2">
          <div class="px-6 text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">${item.label}</div>
          ${item.children.map((child)=>`
            <a href="${formatRoute(child.route)}" class="block px-8 py-3 text-sm font-bold text-gray-600 hover:bg-gray-50 border-l-4 border-transparent hover:border-[${primaryColor}] uppercase tracking-widest">
              ${child.label}
            </a>
          `).join('')}
        </div>
      `;
        }
        return `
      <a href="${route}" class="block px-6 py-4 text-base font-black text-gray-900 hover:bg-gray-50 transition-all uppercase tracking-widest border-l-4 border-transparent hover:border-[${primaryColor}]">
        ${item.label}
      </a>
    `;
    };
    const links = menuItems.map((item)=>renderDesktopItem(item)).join('');
    const mobileLinks = menuItems.map((item)=>renderMobileItem(item)).join('');
    return `
    <nav class="bg-white/80 backdrop-blur-md sticky top-0 z-50 border-b border-gray-100 uppercase">
      <div class="container mx-auto px-4">
        <div class="flex items-center justify-between h-20">
          <!-- Logo -->
          <div class="flex-shrink-0 flex items-center gap-3">
            <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-[${primaryColor}] to-indigo-600 flex items-center justify-center shadow-lg transform -rotate-3 hover:rotate-0 transition-transform cursor-pointer">
              <span class="text-white font-black text-xl italic">${config.companyName?.charAt(0) || 'S'}</span>
            </div>
            <span class="text-xl font-black text-gray-900 tracking-tight uppercase">${config.companyName || 'Storefront'}</span>
          </div>

          <!-- Desktop Menu -->
          <div class="hidden md:flex items-center space-x-1">
            ${links}
            <button class="ml-6 px-6 py-2.5 bg-gray-900 text-white rounded-full text-xs font-black uppercase tracking-widest shadow-xl hover:bg-[${primaryColor}] hover:scale-105 transition-all">
              Shop Now
            </button>
          </div>

          <!-- Mobile Toggle -->
          <button id="mobile-menu-toggle" class="md:hidden p-2 text-gray-900 hover:bg-gray-50 rounded-xl transition-colors">
            <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M4 8h16M4 16h16"></path>
            </svg>
          </button>
        </div>
      </div>

      <!-- Mobile Menu -->
      <div id="mobile-menu" class="hidden md:hidden bg-white border-t border-gray-100 overflow-y-auto max-h-[80vh] transition-all duration-300 shadow-2xl">
        <div class="py-4 space-y-1">
          ${mobileLinks}
          <div class="px-6 py-6 border-t border-gray-50">
            <button class="w-full py-4 bg-gray-900 text-white rounded-2xl font-black uppercase tracking-widest text-sm shadow-xl active:scale-95 transition-all">
              Shop Now
            </button>
          </div>
        </div>
      </div>

      <script>
        (function() {
          const toggle = document.getElementById('mobile-menu-toggle');
          const menu = document.getElementById('mobile-menu');
          if (toggle && menu) {
            toggle.addEventListener('click', () => {
              menu.classList.toggle('hidden');
            });
          }
        })();
      </script>
    </nav>
  `;
}
async function fetchFooterLinks(storefrontId) {
    // TODO: Implement API call to fetch footer links
    return [];
}
async function fetchSiteSettings(storefrontId) {
    // TODO: Implement API call to fetch site settings
    return {};
}
async function fetchFeaturedProducts(storefrontId) {
    try {
        const res = await fetch('https://fakestoreapi.com/products?limit=4');
        const products = await res.json();
        return products.map((p)=>({
                id: p.id,
                name: p.title,
                price: p.price.toFixed(2),
                image: p.image,
                description: p.description
            }));
    } catch (error) {
        console.error('Error fetching featured products:', error);
        return [];
    }
}
async function fetchCategories(storefrontId, options) {
    try {
        const res = await fetch('https://fakestoreapi.com/products/categories');
        const categories = await res.json();
        const mapped = categories.map((cat)=>({
                id: cat,
                name: cat.charAt(0).toUpperCase() + cat.slice(1),
                slug: cat
            }));
        return options?.limit ? mapped.slice(0, options.limit) : mapped;
    } catch (error) {
        console.error('Error fetching categories:', error);
        return [];
    }
}
async function fetchProducts(storefrontId, filters) {
    try {
        const url = filters?.category ? `https://fakestoreapi.com/products/category/${filters.category}` : 'https://fakestoreapi.com/products';
        const res = await fetch(url);
        const products = await res.json();
        return products.map((p)=>({
                id: p.id,
                name: p.title,
                price: p.price.toFixed(2),
                image: p.image,
                description: p.description
            }));
    } catch (error) {
        console.error('Error fetching products:', error);
        return [];
    }
}
async function fetchProductBySlug(storefrontId, slug) {
    try {
        // FakeStoreAPI uses numeric IDs, but we can treat the slug as an ID for testing
        const id = slug.match(/^\d+$/) ? slug : '1';
        const res = await fetch(`https://fakestoreapi.com/products/${id}`);
        const p = await res.json();
        return {
            id: p.id,
            name: p.title,
            price: p.price.toFixed(2),
            image: p.image,
            description: p.description
        };
    } catch (error) {
        console.error('Error fetching product:', error);
        return null;
    }
}
async function fetchRelatedProducts(storefrontId, productSlug) {
    // TODO: Implement API call to fetch related products
    return [];
}
async function fetchCategoryBySlug(storefrontId, slug) {
    // TODO: Implement API call to fetch category by slug
    return null;
}
}),
"[project]/app/storefront/[[...path]]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/storefront/[[...path]]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__387909ee._.js.map