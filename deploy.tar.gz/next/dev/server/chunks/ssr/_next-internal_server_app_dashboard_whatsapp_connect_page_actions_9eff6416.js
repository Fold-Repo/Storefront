module.exports = [
"[project]/.next-internal/server/app/dashboard/whatsapp/connect/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_dashboard_whatsapp_connect_page_actions_9eff6416.js.map