module.exports = [
"[project]/.next-internal/server/app/storefront/[[...path]]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_storefront_%5B%5B___path%5D%5D_page_actions_ce503e92.js.map