module.exports = [
"[project]/lib/firebaseConfig.ts [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/lib/firebaseConfig.ts [app-rsc] (ecmascript)");
    });
});
}),
"[project]/node_modules/firebase/firestore/dist/index.mjs [app-rsc] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/node_modules_firebase_firestore_dist_index_mjs_5ec5dc39._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/firebase/firestore/dist/index.mjs [app-rsc] (ecmascript)");
    });
});
}),
];