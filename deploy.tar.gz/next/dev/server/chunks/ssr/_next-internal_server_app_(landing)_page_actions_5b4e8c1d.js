module.exports = [
"[project]/.next-internal/server/app/(landing)/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28landing%29_page_actions_5b4e8c1d.js.map