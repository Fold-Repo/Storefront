module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/app/api/ai/generate/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * API Route for AI-powered page generation using Claude 3.5 Sonnet
 * 
 * This route handles server-side AI generation to keep API keys secure.
 */ __turbopack_context__.s([
    "POST",
    ()=>POST,
    "maxDuration",
    ()=>maxDuration,
    "runtime",
    ()=>runtime
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$anthropic$2d$ai$2f$sdk$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@anthropic-ai/sdk/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$anthropic$2d$ai$2f$sdk$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__Anthropic__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/@anthropic-ai/sdk/client.mjs [app-route] (ecmascript) <export Anthropic as default>");
;
;
// Initialize Claude client
const anthropic = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$anthropic$2d$ai$2f$sdk$2f$client$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__Anthropic__as__default$3e$__["default"]({
    apiKey: process.env.ANTHROPIC_API_KEY
});
/**
 * Create a comprehensive prompt for Claude to generate a page
 */ function createDynamicPagePrompt(params) {
    const { pageType, businessNiche, companyName, description, theme, logoUrl, layout } = params;
    const isSinglePage = layout === 'single-page';
    console.log(`📋 Generating ${pageType} for ${companyName}${isSinglePage ? ' (Single Page Layout)' : ''}`);
    let pageRequirements = getPageSpecificRequirements(pageType, businessNiche);
    // Enhance requirements for single page
    if (isSinglePage && pageType === 'homepage') {
        pageRequirements = `${pageRequirements}\n- Since this is a SINGLE PAGE layout, also include:\n  - A detailed product catalog section\n  - A clear "About Us" and "Contact Us" section\n  - A simplified shopping cart and checkout section that can be handled within this page (e.g., using modals or toggling visibility)\n  - Smooth scroll navigation to these sections`;
    }
    return `You are an expert web developer specializing in modern, responsive e-commerce websites using Tailwind CSS. Generate a complete, production-ready ${pageType} page.

## Business Context
- **Company Name**: ${companyName}
- **Industry/Niche**: ${businessNiche}
- **Description**: ${description}
- **Tone**: Professional, inviting, and industry-appropriate
${logoUrl ? `- **Logo URL**: ${logoUrl}` : ''}

## Design Requirements (CRITICAL)
- **Styling**: You MUST use Tailwind CSS utility classes for ALL styling. DO NOT generate separate CSS files or <style> blocks.
- **Primary Color**: ${theme.primaryColor} (Use CSS custom properties: style="background-color: ${theme.primaryColor}" or create utility classes)
- **Font Family**: ${theme.fontFamily}
- **Design Style**: ${theme.designFeel}
- **Include Tailwind CDN**: Add <script src="https://cdn.tailwindcss.com"></script> in the <head>

## Page-Specific Requirements
${pageRequirements}

## Technical Requirements
1. **Fully Responsive**: Mobile-first design using Tailwind breakpoints (sm:, md:, lg:, xl:).
2. **Modern Layout**: Use flexbox (flex) and grid (grid) utilities. Example: class="container mx-auto px-4"
3. **Whitespace**: Use generous padding and margins (p-8, my-12, gap-6).
4. **Typography**: Use text sizing (text-xl, text-3xl), font weights (font-bold, font-semibold).
5. **Colors**: Use gray scale (bg-gray-50, text-gray-600) and the primary color for accents.
6. **Interactive States**: Include hover effects (hover:bg-blue-600, hover:shadow-lg).
7. **No Dummy Content**: Generate realistic, niche-specific content. NO "Lorem Ipsum".
8. **SEO**: Proper heading hierarchy (single h1, h2 for sections).

## Dynamic Data Placeholders (MUST INCLUDE)
Place these exact placeholders where dynamic data will be injected:
- {{menu}} - Inside <header> or <nav>
- {{footerLinks}} - Inside <footer>
- {{products}} - For product grids (will be replaced by styled cards)
- {{categories}} - For category listings
- {{featuredProducts}} - For featured product section on homepage
- {{breadcrumbs}} - Below header for navigation
- {{companyName}} - For branding

## Client-Side Data Fetching Script (MUST INCLUDE)
Include this script before </body> to enable dynamic data loading:
\`\`\`html
<script>
(function() {
  const storefrontId = window.location.hostname.split('.')[0];
  const API_BASE = '/api/storefront/' + storefrontId;
  
  async function fetchData(endpoint, containerId) {
    try {
      const container = document.getElementById(containerId);
      if (!container) return;
      const res = await fetch(API_BASE + '/' + endpoint);
      if (res.ok) {
        const data = await res.json();
        console.log(endpoint + ' loaded:', data);
      }
    } catch (e) { console.error('Fetch error:', e); }
  }
  
  document.addEventListener('DOMContentLoaded', function() {
    fetchData('products', 'products-container');
    fetchData('categories', 'categories-container');
  });
})();
</script>
\`\`\`

## Output Format (STRICT JSON)
Return ONLY valid JSON in this exact format, no markdown code blocks:
{
  "html": "<complete HTML document with <!DOCTYPE html>, <html>, <head>, <body>>",
  "css": "",
  "js": "",
  "metadata": {
    "title": "SEO optimized page title",
    "description": "Meta description for SEO"
  }
}

## Example HTML Structure
\`\`\`html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${companyName} - ${pageType}</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=${theme.fontFamily.replace(' ', '+')}:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>body { font-family: '${theme.fontFamily}', sans-serif; }</style>
</head>
<body class="bg-gray-50 text-gray-900">
  <header class="bg-white shadow-sm sticky top-0 z-50">
    <nav class="container mx-auto px-4 py-4 flex items-center justify-between">
      <a href="/" class="text-2xl font-bold" style="color: ${theme.primaryColor}">${companyName}</a>
      {{menu}}
    </nav>
  </header>
  <main>
    <!-- Page content here with Tailwind classes -->
  </main>
  <footer class="bg-gray-900 text-white py-12">
    <!-- Footer content -->
  </footer>
</body>
</html>
\`\`\`

Generate the complete ${pageType} page now. Return ONLY the JSON object, no explanations.`;
}
/**
 * Get page-specific requirements based on page type and business niche
 */ function getPageSpecificRequirements(pageType, businessNiche) {
    const baseRequirements = {
        homepage: `
- Hero section with compelling headline and call-to-action
- Featured products or categories section
- "About Us" section highlighting the business story and mission
- "Contact Us" section with a contact form and business info
- Trust indicators (testimonials, badges, etc.)
- Newsletter signup or promotional section
- Footer with links and company info`,
        categories: `
- Grid or list view of product categories
- Category cards with images and names
- Filter/search functionality (UI only, no backend)
- Breadcrumb navigation
- Category descriptions where appropriate`,
        products: `
- Product grid/list with cards showing:
  - Product image
  - Product name
  - Price
  - "Add to Cart" button
  - Quick view option
- Filter sidebar (by price, category, etc.)
- Sort options (price, popularity, new)
- Pagination controls
- Search bar`,
        'product-detail': `
- Large product image gallery
- Product title and price
- Product description
- Variants selector (size, color, etc.)
- Quantity selector
- "Add to Cart" button
- Product specifications/features
- Related products section
- Reviews section (placeholder)`,
        cart: `
- List of cart items with:
  - Product image
  - Product name
  - Quantity selector
  - Price
  - Remove button
- Cart summary sidebar:
  - Subtotal
  - Shipping estimate
  - Tax
  - Total
- "Continue Shopping" link
- "Proceed to Checkout" button
- Empty cart state`,
        checkout: `
- Multi-step checkout form:
  - Shipping information
  - Payment method selection
  - Order review
- Order summary sidebar
- Form validation indicators
- "Place Order" button
- Security badges/trust indicators`,
        account: `
- Dashboard overview
- Order history list
- Account settings section
- Address book
- Payment methods
- Profile information`,
        search: `
- Search bar with query display
- Search results grid/list
- Filter options
- "No results" state
- Search suggestions`,
        testimonial: `
- Testimonials grid/list layout
- Testimonial cards with:
  - Customer name
  - Testimonial text/quote
  - Customer photo/avatar
  - Rating (stars)
  - Role/company (optional)
- Section for displaying multiple testimonials
- Use placeholder {{testimonials}} for dynamic content`,
        about: `
- About page with company information
- Company history/mission section
- Team members section (optional)
- Values/vision section
- Use placeholder {{content}} for dynamic content`,
        contact: `
- Contact form
- Company contact information
- Map/location (optional)
- Business hours
- Social media links
- Use placeholder {{content}} for dynamic content`
    };
    const nicheSpecific = getNicheSpecificContent(businessNiche);
    return `${baseRequirements[pageType] || ''}

## Industry-Specific Requirements
${nicheSpecific}`;
}
/**
 * Get niche-specific content and layout suggestions
 */ function getNicheSpecificContent(businessNiche) {
    const niche = businessNiche.toLowerCase();
    if (niche.includes('fashion') || niche.includes('clothing') || niche.includes('apparel')) {
        return `- Focus on visual appeal with high-quality product images
- Include size charts and fit information
- Show styling suggestions or lookbooks
- Emphasize color and style variations
- Use elegant, modern layouts`;
    }
    if (niche.includes('electronics') || niche.includes('tech') || niche.includes('gadget')) {
        return `- Highlight technical specifications
- Include comparison features
- Show product ratings and reviews prominently
- Emphasize warranty and support information
- Use clean, technical layouts`;
    }
    if (niche.includes('food') || niche.includes('restaurant') || niche.includes('grocery')) {
        return `- Show appetizing food images
- Include nutritional information
- Highlight ingredients and sourcing
- Show delivery/pickup options
- Use warm, inviting color schemes`;
    }
    if (niche.includes('beauty') || niche.includes('cosmetic') || niche.includes('skincare')) {
        return `- Emphasize product benefits and ingredients
- Show before/after or usage images
- Include skin type matching
- Highlight cruelty-free or organic badges
- Use elegant, luxurious layouts`;
    }
    if (niche.includes('home') || niche.includes('furniture') || niche.includes('decor')) {
        return `- Show products in room settings
- Include dimensions and materials
- Show color/material variations
- Emphasize style and aesthetic
- Use spacious, lifestyle-focused layouts`;
    }
    // Default for other niches
    return `- Tailor content and imagery to ${businessNiche} industry
- Use appropriate product presentation
- Include relevant product information
- Match industry standards and expectations`;
}
/**
 * Parse Claude's response to extract HTML, CSS, JS, and metadata
 */ function parseClaudeResponse(responseText) {
    try {
        // Try to parse as JSON first
        const jsonMatch = responseText.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
            const parsed = JSON.parse(jsonMatch[0]);
            return {
                html: parsed.html || '',
                css: parsed.css || '',
                js: parsed.js || '',
                metadata: parsed.metadata || {
                    title: 'Page',
                    description: ''
                }
            };
        }
    } catch (error) {
        console.warn('Failed to parse JSON response, extracting from text:', error);
    }
    // Fallback: Extract from markdown code blocks or plain text
    const htmlMatch = responseText.match(/```html\n([\s\S]*?)```/) || responseText.match(/<html[\s\S]*?<\/html>/i) || responseText.match(/<body[\s\S]*?<\/body>/i);
    const cssMatch = responseText.match(/```css\n([\s\S]*?)```/) || responseText.match(/<style>([\s\S]*?)<\/style>/i);
    const jsMatch = responseText.match(/```javascript\n([\s\S]*?)```/) || responseText.match(/```js\n([\s\S]*?)```/) || responseText.match(/<script>([\s\S]*?)<\/script>/i);
    return {
        html: htmlMatch ? htmlMatch[1] || htmlMatch[0] : '<div>Generated page</div>',
        css: cssMatch ? cssMatch[1] || '' : '',
        js: jsMatch ? jsMatch[1] || '' : '',
        metadata: {
            title: 'Generated Page',
            description: 'AI-generated e-commerce page'
        }
    };
}
const maxDuration = 180; // 3 minutes (for platforms that support it)
const runtime = 'nodejs'; // Use Node.js runtime
async function POST(request) {
    try {
        console.log('📥 Received request to /api/ai/generate');
        // Check for API key
        if (!process.env.ANTHROPIC_API_KEY) {
            console.error('❌ ANTHROPIC_API_KEY is not configured');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'ANTHROPIC_API_KEY is not configured'
            }, {
                status: 500
            });
        }
        // Parse request body
        const body = await request.json();
        console.log('📋 Request body:', {
            pageType: body.pageType,
            companyName: body.companyName,
            businessNiche: body.businessNiche,
            hasTheme: !!body.theme
        });
        // Validate required fields
        if (!body.pageType || !body.companyName || !body.businessNiche || !body.theme) {
            console.error('❌ Missing required fields:', {
                pageType: !!body.pageType,
                companyName: !!body.companyName,
                businessNiche: !!body.businessNiche,
                theme: !!body.theme
            });
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Missing required fields: pageType, companyName, businessNiche, theme'
            }, {
                status: 400
            });
        }
        // Create prompt
        const prompt = createDynamicPagePrompt(body);
        console.log('🤖 Calling Claude API for page:', body.pageType);
        // Call Claude API with timeout wrapper
        const claudePromise = anthropic.messages.create({
            model: 'claude-sonnet-4-5',
            max_tokens: 4000,
            messages: [
                {
                    role: 'user',
                    content: prompt
                }
            ]
        });
        // Add timeout (2 minutes) to prevent hanging requests
        const timeoutPromise = new Promise((_, reject)=>{
            setTimeout(()=>{
                reject(new Error('Claude API request timeout after 2 minutes'));
            }, 120000);
        });
        const message = await Promise.race([
            claudePromise,
            timeoutPromise
        ]);
        console.log('✅ Claude API responded');
        // Extract response text
        const responseText = message.content[0].type === 'text' ? message.content[0].text : '';
        if (!responseText) {
            console.error('❌ Empty response from Claude API');
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: 'Empty response from Claude API'
            }, {
                status: 500
            });
        }
        console.log('📝 Parsing Claude response (length:', responseText.length, ')');
        // Parse response
        const parsed = parseClaudeResponse(responseText);
        console.log('✅ Successfully parsed response for page:', body.pageType);
        // Return generated page
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            page: parsed
        });
    } catch (error) {
        console.error('❌ Error generating page with Claude:', error);
        console.error('Error stack:', error.stack);
        console.error('Error details:', {
            message: error.message,
            name: error.name,
            code: error.code
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Failed to generate page',
            message: error.message || 'Unknown error',
            details: ("TURBOPACK compile-time truthy", 1) ? error.stack : "TURBOPACK unreachable"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0a61f333._.js.map