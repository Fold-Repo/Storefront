module.exports = [
"[project]/.next-internal/server/app/api/storefront/[storefrontId]/products/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ce889_server_app_api_storefront_%5BstorefrontId%5D_products_route_actions_bdfec79c.js.map