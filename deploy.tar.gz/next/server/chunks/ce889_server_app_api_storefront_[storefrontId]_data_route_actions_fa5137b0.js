module.exports=[95932,(e,o,d)=>{}];

//# sourceMappingURL=ce889_server_app_api_storefront_%5BstorefrontId%5D_data_route_actions_fa5137b0.js.map