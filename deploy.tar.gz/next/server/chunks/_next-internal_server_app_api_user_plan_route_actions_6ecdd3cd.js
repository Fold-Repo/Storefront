module.exports=[954260,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_plan_route_actions_6ecdd3cd.js.map