module.exports=[201816,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_settings_notifications_page_actions_bfe56f07.js.map