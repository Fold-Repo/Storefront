module.exports=[279698,a=>{"use strict";var b=a.i(187924),c=a.i(572131),d=a.i(50944),e=a.i(736545),f=a.i(516911),g=a.i(1271);a.i(462822);var h=a.i(877466),i=a.i(930731);let j=c.forwardRef(function({title:a,titleId:b,...d},e){return c.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:e,"aria-labelledby":b},d),a?c.createElement("title",{id:b},a):null,c.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M2.25 12.75V12A2.25 2.25 0 0 1 4.5 9.75h15A2.25 2.25 0 0 1 21.75 12v.75m-8.69-6.44-2.12-2.12a1.5 1.5 0 0 0-1.061-.44H4.5A2.25 2.25 0 0 0 2.25 6v12a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9a2.25 2.25 0 0 0-2.25-2.25h-5.379a1.5 1.5 0 0 1-1.06-.44Z"}))});var k=a.i(180417),l=a.i(329514),m=a.i(482258),n=a.i(696713),o=a.i(745086);let p=[{label:"Category Grid",category:"E-commerce",content:`
      <section class="py-12 bg-white">
        <div class="container mx-auto px-4">
          <h2 class="text-2xl font-bold mb-8 text-center text-gray-800">Shop by Category</h2>
          <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-blue-50 flex items-center justify-center mb-4 group-hover:bg-blue-100 transition-colors border border-blue-100 shadow-sm">
                <img src="/assets/img/categories/electronics.png" alt="Electronics" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3659/3659899.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-blue-600">Electronics</span>
            </div>
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-pink-50 flex items-center justify-center mb-4 group-hover:bg-pink-100 transition-colors border border-pink-100 shadow-sm">
                <img src="/assets/img/categories/fashion.png" alt="Fashion" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3050/3050239.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-pink-600">Fashion</span>
            </div>
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-green-50 flex items-center justify-center mb-4 group-hover:bg-green-100 transition-colors border border-green-100 shadow-sm">
                <img src="/assets/img/categories/home.png" alt="Home" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/2544/2544111.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-green-600">Home</span>
            </div>
            <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-yellow-50 flex items-center justify-center mb-4 group-hover:bg-yellow-100 transition-colors border border-yellow-100 shadow-sm">
                <img src="/assets/img/categories/beauty.png" alt="Beauty" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3163/3163212.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-yellow-600">Beauty</span>
            </div>
             <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-purple-50 flex items-center justify-center mb-4 group-hover:bg-purple-100 transition-colors border border-purple-100 shadow-sm">
                <img src="/assets/img/categories/sports.png" alt="Sports" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/857/857455.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-purple-600">Sports</span>
            </div>
             <div class="flex flex-col items-center group cursor-pointer">
              <div class="w-24 h-24 rounded-full bg-indigo-50 flex items-center justify-center mb-4 group-hover:bg-indigo-100 transition-colors border border-indigo-100 shadow-sm">
                <img src="/assets/img/categories/toys.png" alt="Toys" class="w-12 h-12 object-contain" onerror="this.src='https://cdn-icons-png.flaticon.com/512/3082/3082045.png'">
              </div>
              <span class="text-sm font-semibold text-gray-700 group-hover:text-indigo-600">Toys</span>
            </div>
          </div>
        </div>
      </section>
    `},{label:"Top Brands",category:"E-commerce",content:`
      <section class="py-10 border-t border-b border-gray-100 bg-gray-50">
        <div class="container mx-auto px-4 text-center">
          <p class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Our Top Trusted Brands</p>
          <div class="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-60">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/a/a6/Logo_NIKE.svg" alt="Nike">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/2/20/Adidas_Logo.svg" alt="Adidas">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/5/53/H%26M-Logo.svg" alt="H&M">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/9/94/Zara_Logo.svg" alt="Zara">
            <img class="h-8 md:h-10 grayscale hover:grayscale-0 transition-all cursor-pointer" src="https://upload.wikimedia.org/wikipedia/commons/f/f9/Apple_logo_black.svg" alt="Apple">
          </div>
        </div>
      </section>
    `},{label:"Trending Products",category:"E-commerce",content:`
      <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
          <div class="flex items-center justify-between mb-10">
            <div>
              <h2 class="text-3xl font-bold text-gray-900 mb-2">Trending Now</h2>
              <p class="text-gray-500">The most popular items this month</p>
            </div>
            <a href="#" class="text-blue-600 font-semibold flex items-center gap-1 hover:underline">
              View All <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
            </a>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- Product 1 -->
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <span class="absolute top-4 left-4 bg-orange-500 text-white text-[10px] font-bold px-2 py-1 rounded-full uppercase tracking-wider">Trending</span>
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">Premium Wireless Watch</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">High-performance smartwatch with health tracking and GPS connectivity.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$299.99</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(45)</span>
                  </div>
                </div>
              </div>
            </div>
            <!-- More products can be added here with same structure -->
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">UltraBass Headphones</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">Noise-canceling over-ear headphones with 40-hour battery life.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$189.00</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(128)</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">SpeedRun Sport Shoes</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">Lightweight running shoes designed for ultimate speed and stability.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$125.50</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(84)</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="group border border-gray-100 rounded-xl overflow-hidden hover:shadow-2xl transition-all h-full flex flex-col">
              <div class="aspect-square bg-gray-100 relative overflow-hidden">
                <img src="https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=500&q=80" alt="Product" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                <button class="absolute bottom-4 left-1/2 -translate-x-1/2 translate-y-20 group-hover:translate-y-0 bg-white text-gray-900 w-[80%] py-2 rounded-lg font-bold shadow-xl transition-all duration-300 flex items-center justify-center gap-2 hover:bg-gray-900 hover:text-white">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 21z"></path></svg> Add to Cart
                </button>
              </div>
              <div class="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <h3 class="font-bold text-gray-800 text-lg mb-1 group-hover:text-blue-600 transition-colors">Classic Aviators</h3>
                  <p class="text-sm text-gray-500 mb-4 line-clamp-2">Handcrafted sunglasses with UV400 protection and polarized lenses.</p>
                </div>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-black text-gray-900">$75.00</span>
                  <div class="flex text-yellow-400">
                    <svg class="w-4 h-4 fill-current" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    <span class="text-xs text-gray-400 ml-1 font-medium">(32)</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `},{label:"Flash Sales",category:"E-commerce",content:`
      <section class="py-12 bg-gradient-to-r from-red-600 to-orange-500">
        <div class="container mx-auto px-4">
          <div class="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-8">
            <div class="text-center md:text-left flex-1">
              <span class="inline-block bg-white text-red-600 text-xs font-black px-4 py-1 rounded-full mb-4 animate-pulse">FLASH SALE 🔥</span>
              <h2 class="text-4xl font-black text-white mb-4">Upto 70% Off!</h2>
              <p class="text-white/80 text-lg mb-6">Don't miss out on our biggest yearly clearance event.</p>
              <div class="flex items-center justify-center md:justify-start gap-4">
                 <div class="flex flex-col items-center">
                    <span class="w-12 h-12 flex items-center justify-center bg-white rounded-lg text-red-600 font-black text-xl">12</span>
                    <span class="text-[10px] text-white/70 mt-1 uppercase">hrs</span>
                 </div>
                 <span class="text-2xl text-white font-bold">:</span>
                 <div class="flex flex-col items-center">
                    <span class="w-12 h-12 flex items-center justify-center bg-white rounded-lg text-red-600 font-black text-xl">45</span>
                    <span class="text-[10px] text-white/70 mt-1 uppercase">min</span>
                 </div>
                 <span class="text-2xl text-white font-bold">:</span>
                 <div class="flex flex-col items-center">
                    <span class="w-12 h-12 flex items-center justify-center bg-white rounded-lg text-red-600 font-black text-xl">22</span>
                    <span class="text-[10px] text-white/70 mt-1 uppercase">sec</span>
                 </div>
              </div>
            </div>
            <div class="flex-1 flex justify-center">
               <div class="relative group">
                  <div class="absolute -inset-4 bg-white/20 blur-2xl group-hover:bg-white/30 transition-all rounded-full"></div>
                  <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&q=80" alt="Flash Sale Product" class="w-72 md:w-96 drop-shadow-2xl translate-z-10 transform -rotate-12 group-hover:rotate-0 transition-transform duration-700">
               </div>
            </div>
            <div class="shrink-0">
               <button class="bg-white text-gray-900 px-10 py-4 rounded-xl font-black shadow-2xl hover:bg-gray-900 hover:text-white transition-all transform hover:scale-105">SHOP THE SALE</button>
            </div>
          </div>
        </div>
      </section>
    `},{label:"Product Carousel",category:"E-commerce",content:`
      <section class="py-16 bg-gray-50 overflow-hidden">
        <div class="container mx-auto px-4">
          <div class="text-center mb-12">
             <h2 class="text-3xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-indigo-600">Handpicked with ❤️</h2>
             <div class="w-20 h-1.5 bg-indigo-600 mx-auto mt-4 rounded-full"></div>
          </div>
          
          <div class="relative w-full max-w-5xl mx-auto">
            <!-- Navigation Buttons -->
            <button class="absolute top-1/2 -left-4 md:-left-12 -translate-y-1/2 w-10 h-10 md:w-14 md:h-14 bg-white rounded-full shadow-2xl flex items-center justify-center text-gray-900 hover:bg-gray-900 hover:text-white z-10 transition-all">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M15 19l-7-7 7-7"></path></svg>
            </button>
            <button class="absolute top-1/2 -right-4 md:-right-12 -translate-y-1/2 w-10 h-10 md:w-14 md:h-14 bg-white rounded-full shadow-2xl flex items-center justify-center text-gray-900 hover:bg-gray-900 hover:text-white z-10 transition-all">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M9 5l7 7-7 7"></path></svg>
            </button>

            <!-- Product Display Area -->
            <div class="flex gap-8 overflow-x-auto no-scrollbar scroll-smooth pb-10">
              <!-- Item 1 -->
              <div class="min-w-[280px] md:min-w-[320px] bg-white rounded-2xl shadow-sm border border-gray-100 p-6 transform hover:-translate-y-2 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80" class="w-full aspect-square object-contain mb-6 drop-shadow-lg" alt="Item">
                <div class="text-center">
                  <h4 class="font-bold text-lg text-gray-800">Air Zoom Pegasus 38</h4>
                  <p class="text-gray-400 text-sm mb-4">Unisex Running Shield</p>
                  <p class="text-2xl font-black text-indigo-600 mb-6">$120.00</p>
                  <button class="w-full py-3 bg-gray-50 hover:bg-gray-900 hover:text-white text-gray-900 border border-gray-100 font-bold rounded-xl transition-all">DETAILS</button>
                </div>
              </div>
              <div class="min-w-[280px] md:min-w-[320px] bg-white rounded-2xl shadow-sm border border-gray-100 p-6 transform hover:-translate-y-2 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&q=80" class="w-full aspect-square object-contain mb-6 drop-shadow-lg" alt="Item">
                <div class="text-center">
                  <h4 class="font-bold text-lg text-gray-800">Premium White Watch</h4>
                  <p class="text-gray-400 text-sm mb-4">Smart Lifestyle Gear</p>
                  <p class="text-2xl font-black text-indigo-600 mb-6">$299.00</p>
                  <button class="w-full py-3 bg-gray-50 hover:bg-gray-900 hover:text-white text-gray-900 border border-gray-100 font-bold rounded-xl transition-all">DETAILS</button>
                </div>
              </div>
              <div class="min-w-[280px] md:min-w-[320px] bg-white rounded-2xl shadow-sm border border-gray-100 p-6 transform hover:-translate-y-2 transition-transform duration-300">
                <img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&q=80" class="w-full aspect-square object-contain mb-6 drop-shadow-lg" alt="Item">
                <div class="text-center">
                  <h4 class="font-bold text-lg text-gray-800">Ultra High-Res Audio</h4>
                  <p class="text-gray-400 text-sm mb-4">Wireless Beats Experience</p>
                  <p class="text-2xl font-black text-indigo-600 mb-6">$189.00</p>
                  <button class="w-full py-3 bg-gray-50 hover:bg-gray-900 hover:text-white text-gray-900 border border-gray-100 font-bold rounded-xl transition-all">DETAILS</button>
                </div>
              </div>
            </div>

            <!-- Indicators -->
            <div class="flex justify-center gap-2 mt-4">
              <div class="w-8 h-2 bg-indigo-600 rounded-full transition-all"></div>
              <div class="w-2 h-2 bg-gray-300 rounded-full transition-all hover:bg-indigo-300"></div>
              <div class="w-2 h-2 bg-gray-300 rounded-full transition-all hover:bg-indigo-300"></div>
            </div>
          </div>
        </div>
      </section>
    `},{label:"Live Product Grid",category:"Dynamic Content",content:`
      <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
          <div class="flex items-center justify-between mb-10">
            <h2 class="text-3xl font-black text-gray-900 tracking-tight uppercase">Back-End Products</h2>
            <span class="px-4 py-1 bg-green-100 text-green-600 text-[10px] font-black rounded-full uppercase tracking-widest">Live Sync Alpha</span>
          </div>
          {{products}}
        </div>
      </section>
    `},{label:"Live Featured Slider",category:"Dynamic Content",content:`
      <section class="py-16 bg-gray-900 overflow-hidden">
        <div class="container mx-auto px-4">
          <div class="text-center mb-12">
            <h2 class="text-3xl font-black text-white tracking-tighter">FEATURED COLLECTIONS</h2>
            <p class="text-blue-400 font-bold text-sm tracking-widest mt-2 uppercase">Auto-populated from API</p>
          </div>
          {{featuredProducts}}
        </div>
      </section>
    `},{label:"Breadcrumbs",category:"Breadcrumbs",content:`
      <nav class="flex py-4 bg-gray-50/50" aria-label="Breadcrumb">
        <div class="container mx-auto px-4 flex items-center space-x-1 md:space-x-3">
          <ol class="inline-flex items-center space-x-1 md:space-x-3">
            {{breadcrumbs}}
          </ol>
        </div>
      </nav>
    `},{label:"Minimalist Breadcrumb",category:"Breadcrumbs",content:`
      <nav class="flex justify-center py-6 bg-transparent" aria-label="Breadcrumb">
        <ol class="flex items-center space-x-2 text-xs uppercase tracking-widest font-bold">
          {{breadcrumbs}}
        </ol>
      </nav>
    `},{label:"Brand Accent Breadcrumb",category:"Breadcrumbs",content:`
      <nav class="bg-blue-600 py-3" aria-label="Breadcrumb">
        <div class="container mx-auto px-4 flex items-center justify-between">
          <ol class="flex items-center space-x-2 text-sm font-medium text-blue-100">
            {{breadcrumbs}}
          </ol>
          <span class="text-[10px] text-blue-200 font-bold hidden sm:block">FREE SHIPPING ON ALL ORDERS OVER $100</span>
        </div>
      </nav>
    `},{label:"Pill Style Breadcrumb",category:"Breadcrumbs",content:`
      <nav class="py-8 bg-white" aria-label="Breadcrumb">
        <div class="container mx-auto px-4">
          <ol class="flex flex-wrap items-center gap-2">
            {{breadcrumbs}}
          </ol>
        </div>
      </nav>
    `},{label:"Glass Breadcrumb",category:"Breadcrumbs",content:`
      <section class="py-12 bg-gray-900 relative">
        <div class="absolute inset-0 bg-gradient-to-r from-purple-900/40 to-blue-900/40 opacity-70"></div>
        <div class="container mx-auto px-4 relative z-10">
          <nav class="inline-flex px-5 py-3 text-white border border-white/10 rounded-2xl bg-white/5 backdrop-blur-xl shadow-2xl" aria-label="Breadcrumb">
            <ol class="inline-flex items-center space-x-1 md:space-x-3">
              {{breadcrumbs}}
            </ol>
          </nav>
        </div>
      </section>
    `},{label:"Page Header",category:"Page Sections",content:`
      <section class="py-16 md:py-24 bg-gray-900 text-white relative overflow-hidden">
        <div class="absolute inset-0 opacity-20 bg-[url('https://images.unsplash.com/photo-1497215728101-856f4ea42174?w=1600&q=80')] bg-cover bg-center"></div>
        <div class="container mx-auto px-4 relative z-10 text-center">
          <h1 class="text-4xl md:text-6xl font-black mb-6 tracking-tight">Our Story</h1>
          <p class="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Discover the passion and purpose behind everything we do. We're committed to delivering excellence every single day.
          </p>
          <ol class="mt-8 flex justify-center items-center space-x-2 text-sm text-gray-400 font-medium">
             {{breadcrumbs}}
          </ol>
        </div>
      </section>
    `},{label:"Split Image Header",category:"Page Sections",content:`
      <section class="bg-white overflow-hidden">
        <div class="flex flex-col md:flex-row">
          <div class="w-full md:w-1/2 p-12 md:p-24 flex flex-col justify-center">
            <h1 class="text-4xl md:text-5xl font-black text-gray-900 mb-6 leading-tight">Get in Touch <br><span class="text-blue-600">With Our Team</span></h1>
            <p class="text-gray-600 text-lg mb-8 max-w-md">Have questions? We're here to help you scaling your business to the next level with our expert support.</p>
            <ol class="flex items-center gap-4 text-sm font-bold text-gray-400">
               {{breadcrumbs}}
            </ol>
          </div>
          <div class="w-full md:w-1/2 h-[400px] md:h-auto bg-gray-100">
             <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1200&q=80" alt="Team" class="w-full h-full object-cover">
          </div>
        </div>
      </section>
    `},{label:"Wave Header",category:"Page Sections",content:`
      <section class="pt-20 pb-0 bg-gradient-to-br from-indigo-700 via-purple-700 to-pink-600 relative overflow-hidden">
        <div class="container mx-auto px-4 text-center pb-20">
          <h1 class="text-5xl md:text-7xl font-black text-white mb-6 uppercase tracking-tight">Our Services</h1>
          <p class="text-white/80 text-lg md:text-xl max-w-xl mx-auto font-medium">Empowering your vision with cutting-edge technology and innovative solutions.</p>
        </div>
        <div class="w-full leading-[0]">
          <svg class="relative block w-full h-[150px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
            <path d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V120H0V95.8C58.05,117,133.27,125.13,203,111.45,251.52,101.9,294,83.05,321.39,56.44Z" class="fill-white"></path>
          </svg>
        </div>
      </section>
    `},{label:"Minimalist Header",category:"Page Sections",content:`
      <section class="py-20 bg-white border-b border-gray-100">
        <div class="container mx-auto px-4 text-center">
          <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-8 transform rotate-3 hover:rotate-0 transition-transform shadow-xl">
             <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m4 0h1m-5 10h5m-5 4h5m-4-4h4m-4 4h4m-4-4h4m-4 4h4"></path></svg>
          </div>
          <h1 class="text-4xl md:text-5xl font-black text-gray-900 mb-4 tracking-tight uppercase">Company Profile</h1>
          <div class="flex items-center justify-center gap-2 text-xs font-black text-blue-600 tracking-[0.2em] mb-6">
             <span>ESTABLISHED 2024</span>
             <span class="w-1.5 h-1.5 bg-blue-600 rounded-full"></span>
             <span>CERTIFIED PARTNER</span>
          </div>
          <p class="text-gray-500 text-lg max-w-2xl mx-auto italic leading-relaxed">"Delivering value through integrity and innovation in every project we undertake."</p>
        </div>
      </section>
    `},{label:"Glass Jumbotron",category:"Page Sections",content:`
      <section class="h-[500px] md:h-[600px] relative flex items-center justify-center overflow-hidden">
        <!-- Background Layer -->
        <div class="absolute inset-0 z-0">
          <img src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1600&q=80" class="w-full h-full object-cover scale-105" alt="Building">
          <div class="absolute inset-0 bg-black/40 backdrop-blur-[2px]"></div>
        </div>
        
        <!-- Content Card -->
        <div class="container mx-auto px-4 relative z-10">
          <div class="max-w-3xl mx-auto bg-white/10 backdrop-blur-xl border border-white/20 p-10 md:p-16 rounded-[40px] shadow-2xl text-center">
             <h1 class="text-5xl md:text-7xl font-black text-white mb-6 drop-shadow-lg leading-tight">Join Our <br><span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400">Mission</span></h1>
             <p class="text-white/80 text-lg md:text-xl mb-10 max-w-lg mx-auto">Be part of the future of digital commerce. We're looking for passionate individuals to join our global team.</p>
             <div class="flex flex-wrap justify-center gap-4">
                <button class="px-8 py-3 bg-white text-gray-900 rounded-full font-bold shadow-xl hover:bg-gray-900 hover:text-white transition-all transform hover:scale-105 uppercase text-sm tracking-widest">Apply Now</button>
                <button class="px-8 py-3 bg-transparent border border-white/50 text-white rounded-full font-bold hover:bg-white/10 transition-all uppercase text-sm tracking-widest">View Roles</button>
             </div>
          </div>
        </div>
      </section>
    `},{label:"Top NavBar",category:"NavBar",content:'<nav class="bg-brand p-2"><div class="container flex items-center flex-wrap gap-y-2 gap-x-3 justify-center"><img class="w-5 md:w-6" src="/assets/img/gift.svg" alt="Gift Box" loading="lazy"><p class="text-white text-[12px] md:text-xs">Special Offer: 50% off - limited time only</p><button class="btn btn-outline !border-border btn-sm !text-[12px] !py-1.5">Buy Now</button></div></nav>'},{label:"Hero Banner One",category:"Hero Banner",content:`<div class="flex items-center justify-center h-full min-h-[60vh] lg:min-h-[90vh] relative w-full bg-[url('/assets/img/banner/1.jpg')] bg-cover bg-center">
        <div class="absolute inset-0 bg-black/50"></div>
        <div class="container relative flex flex-col justify-center items-center gap-y-6 text-center">
            <h1 class="text-white text-2xl sm:text-3xl md:text-4xl lg:text-5xl 2xl:text-6xl font-medium sm:leading-12 lg:leading-14 2xl:leading-[70px]">
                Discover Amazing Products, <br class="hidden md:block" /> Best Deals for You
            </h1>
            <p class="font-inter text-white text-sm md:text-base font-light tracking-wider">
                Explore our curated collection and find what you love
            </p>
            <button class="btn btn-brand text-white !px-12 rounded-lg">
                Shop Now
            </button>
        </div>
    </div>`}];var q=a.i(843761);let r=({setting:a,allSettings:d,onToggle:e,onMove:f,depth:g=0})=>{let[h,i]=(0,c.useState)(null),j=d.filter(b=>b.parentId===a.id).sort((a,b)=>a.order-b.order);return(0,b.jsxs)("div",{className:"space-y-1",children:[(0,b.jsxs)("div",{draggable:!0,onDragStart:b=>{b.dataTransfer.setData("text/plain",a.id),b.dataTransfer.effectAllowed="move",document.body.classList.add("dragging-menu-item")},onDragOver:a=>{a.preventDefault(),a.stopPropagation();let b=a.currentTarget.getBoundingClientRect(),c=a.clientY-b.top;c<.25*b.height?i("before"):c>.75*b.height?i("after"):i("inside")},onDragLeave:()=>i(null),onDrop:b=>{b.preventDefault(),b.stopPropagation();let c=b.dataTransfer.getData("text/plain");c===a.id||h&&f(c,a.id,h),i(null)},onDragEnd:()=>document.body.classList.remove("dragging-menu-item"),className:`relative p-3 rounded-xl border transition-all cursor-move group ${"inside"===h?"bg-blue-50 border-blue-400 scale-[1.02] shadow-md z-10":"before"===h?"border-t-blue-500 border-t-2 bg-gray-50":"after"===h?"border-b-blue-500 border-b-2 bg-gray-50":"bg-white border-gray-100 hover:border-blue-200 hover:shadow-sm"}`,style:{marginLeft:`${16*g}px`},children:[(0,b.jsxs)("div",{className:"flex items-center justify-between",children:[(0,b.jsxs)("div",{className:"flex items-center gap-3",children:[(0,b.jsx)("div",{className:"p-1.5 bg-gray-50 rounded-lg text-gray-400 group-hover:text-blue-500 transition-colors",children:(0,b.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 6h16M4 12h16M4 18h16"})})}),(0,b.jsxs)("div",{children:[(0,b.jsx)("span",{className:"text-xs font-black text-gray-900 uppercase tracking-tighter block",children:a.settings.metaTitle||a.pageType}),(0,b.jsx)("span",{className:"text-[10px] text-gray-400 font-mono tracking-tighter",children:a.route})]})]}),(0,b.jsxs)("div",{className:"flex items-center gap-2",children:[(0,b.jsx)("button",{onClick:()=>e(a.id,"showInMenu",!a.settings.showInMenu),className:`px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest transition-all ${a.settings.showInMenu?"bg-blue-100 text-blue-700":"bg-gray-100 text-gray-400 hover:bg-gray-200"}`,title:"Show in Menu",children:a.settings.showInMenu?"In Menu":"Hidden"}),(0,b.jsx)("div",{className:`w-2 h-2 rounded-full ${a.settings.enabled?"bg-green-500":"bg-gray-300 shadow-inner"}`,title:a.settings.enabled?"Live":"Draft"})]})]}),"inside"===h&&(0,b.jsx)("div",{className:"absolute -bottom-2 right-4 bg-blue-600 text-white text-[8px] font-black uppercase px-2 py-0.5 rounded-full shadow-lg animate-bounce",children:"Make Child"})]}),j.length>0&&(0,b.jsx)("div",{className:"space-y-1",children:j.map(a=>(0,b.jsx)(r,{setting:a,allSettings:d,onToggle:e,onMove:f,depth:g+1},a.id))})]})},s=({subdomain:s,initialPage:t="homepage"})=>{let u=(0,d.useRouter)(),{user:v,isAuthenticated:w}=(0,e.useAuth)(),{showSuccess:x,showError:y}=(0,g.useToast)(),z=(0,c.useRef)(null),A=(0,c.useRef)(null),[B,C]=(0,c.useState)(null),[D,E]=(0,c.useState)(null),[F,G]=(0,c.useState)(t),[H,I]=(0,c.useState)(!0),[J,K]=(0,c.useState)("blocks"),[L,M]=(0,c.useState)([]),[N,O]=(0,c.useState)(!1),[P,Q]=(0,c.useState)(!0),[R,S]=(0,c.useState)(!1),[T,U]=(0,c.useState)(null);(0,c.useEffect)(()=>{B&&"blocks"===J&&setTimeout(()=>{B.BlockManager.render();let a=document.getElementById("blocks-container");if(a){let b=a.querySelector(".gjs-category");b&&!b.classList.contains("gjs-open")&&b.classList.add("gjs-open")}},100)},[J,B]);let[V,W]=(0,c.useState)(null),[X,Y]=(0,c.useState)(0),Z=async(a=!1)=>{if(!v||!w){W("Not authenticated. Please sign in to access the editor."),Q(!1);return}try{Q(!0),W(null),console.log("🔄 Loading site data from Firebase...",{userId:v.user_id||v.uid,isRetry:a});let b=await (0,f.loadGeneratedSiteFromFirebase)(v);if(!b){0===X?W("Unable to connect to Firebase. Please check your internet connection."):W("No storefront found. Please create a storefront first."),Q(!1);return}if(console.log("✅ Site data loaded:",{companyName:b.companyName,subdomain:b.subdomain,pagesCount:Object.keys(b.pages||{}).length}),E(b),W(null),Q(!1),t&&b.pages[t])G(t);else if(b.pages&&Object.keys(b.pages).length>0){let a=Object.keys(b.pages)[0];G(a)}}catch(a){console.error("❌ Error loading site:",a),W(a.message||"Failed to load storefront"),y("Failed to load storefront. Please try again."),Q(!1)}},$=async()=>{if(s&&v)try{S(!0);let a=await (0,q.getPageSettingsByStorefront)(s,!1);if(D){let b=Object.keys(D.pages),c=v.user_id?.toString()||v.uid||"";await (0,q.ensureAllPagesHaveSettings)(s,c,b),a=await (0,q.getPageSettingsByStorefront)(s,!1)}M(a)}catch(a){console.error("Error loading page settings:",a)}finally{S(!1)}};(0,c.useEffect)(()=>{Z(),$()},[v,w]),(0,c.useEffect)(()=>{if(!D||P)return;let b=null,c=!0,d=setTimeout(()=>{if(!A.current){console.error("Container ref is null - editor container not found in DOM"),y("Editor container not found. Please refresh the page.");return}A.current,Promise.all([a.A(526591),a.A(834505),a.A(581212)]).then(([a,d,e])=>{if(!c||!A.current)return void console.warn("Component unmounted or container removed before GrapesJS initialization");try{let f,g;if((f=(b=a.default.init({container:A.current,height:"100%",width:"100%",storageManager:!1,fromElement:!0,canvas:{styles:["https://cdn.jsdelivr.net/npm/tailwindcss@3.4.1/dist/tailwind.min.css","https://fold-html.netlify.app/assets/css/global.css"],scripts:["https://cdn.tailwindcss.com"]},plugins:[d.default,e.default],pluginsOpts:{[d.default]:{modalImportTitle:"Import Template",modalImportLabel:"<div style='margin-bottom: 10px; font-size: 13px;'>Paste here your HTML/CSS and click Import</div>",modalImportContent:a=>{let b=document.createElement("textarea");return b.value=`<div class="container mx-auto px-4 py-8">
  <h1 class="text-3xl font-bold mb-4">Your Content</h1>
  <p class="text-gray-600">Start editing...</p>
</div>`,b}}},blockManager:{},layerManager:{appendTo:"#layers-container"},styleManager:{appendTo:"#styles-container",sectors:[{name:"Background",open:!0,properties:[{name:"Background Image",property:"background-image"},{name:"Size",property:"background-size"},{name:"Position",property:"background-position"},{name:"Repeat",property:"background-repeat"},{name:"Attachment",property:"background-attachment"}]},{name:"Dimensions",open:!1,buildProps:["width","height","min-height","padding","margin"]},{name:"Typography",open:!1,buildProps:["font-family","font-size","font-weight","letter-spacing","color","line-height","text-align"]},{name:"Tailwind Classes",open:!0,buildProps:["class"]}]},deviceManager:{devices:[{name:"Desktop",width:""},{name:"Tablet",width:"768px",widthMedia:"992px"},{name:"Mobile",width:"320px",widthMedia:"768px"}]}})).BlockManager).add("hero-section",{label:"Hero Section",category:"Sections",content:`
      <section class="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div class="container mx-auto px-4 text-center">
          <h1 class="text-5xl font-bold mb-4">Welcome to Our Store</h1>
          <p class="text-xl mb-8">Discover amazing products at great prices</p>
          <button class="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
            Shop Now
          </button>
        </div>
      </section>
    `,attributes:{class:"fa fa-star"}}),f.add("feature-cards",{label:"Feature Cards",category:"Sections",content:`
      <section class="py-16 bg-gray-50">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold text-center mb-12">Our Features</h2>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
              <div class="text-blue-600 text-4xl mb-4">🚀</div>
              <h3 class="text-xl font-semibold mb-2">Fast Delivery</h3>
              <p class="text-gray-600">Get your orders delivered quickly and safely</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
              <div class="text-blue-600 text-4xl mb-4">💎</div>
              <h3 class="text-xl font-semibold mb-2">Premium Quality</h3>
              <p class="text-gray-600">Only the best products for our customers</p>
            </div>
            <div class="bg-white p-6 rounded-lg shadow-lg text-center">
              <div class="text-blue-600 text-4xl mb-4">🔒</div>
              <h3 class="text-xl font-semibold mb-2">Secure Payment</h3>
              <p class="text-gray-600">Your transactions are safe and encrypted</p>
            </div>
          </div>
        </div>
      </section>
    `,attributes:{class:"fa fa-th"}}),f.add("product-grid",{label:"Product Grid",category:"E-commerce",content:`
      <section class="py-16">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold text-center mb-12">Featured Products</h2>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$99</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$149</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$79</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
            <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition">
              <div class="h-48 bg-gray-200"></div>
              <div class="p-4">
                <h3 class="font-semibold text-lg mb-2">Product Name</h3>
                <p class="text-gray-600 text-sm mb-3">Brief product description</p>
                <div class="flex items-center justify-between">
                  <span class="text-2xl font-bold text-blue-600">$199</span>
                  <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                    Add to Cart
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `,attributes:{class:"fa fa-shopping-cart"}}),f.add("testimonials",{label:"Testimonials",category:"Sections",content:`
      <section class="py-16 bg-white">
        <div class="container mx-auto px-4">
          <h2 class="text-3xl font-bold text-center mb-12">What Our Customers Say</h2>
          <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div class="bg-gray-50 p-6 rounded-lg">
              <div class="flex items-center mb-4">
                <div class="w-12 h-12 bg-blue-600 rounded-full mr-4"></div>
                <div>
                  <h4 class="font-semibold">John Doe</h4>
                  <p class="text-sm text-gray-600">Verified Customer</p>
                </div>
              </div>
              <p class="text-gray-700 italic">"Amazing products and excellent service! Highly recommended."</p>
              <div class="mt-4 text-yellow-500">★★★★★</div>
            </div>
            <div class="bg-gray-50 p-6 rounded-lg">
              <div class="flex items-center mb-4">
                <div class="w-12 h-12 bg-blue-600 rounded-full mr-4"></div>
                <div>
                  <h4 class="font-semibold">Jane Smith</h4>
                  <p class="text-sm text-gray-600">Verified Customer</p>
                </div>
              </div>
              <p class="text-gray-700 italic">"Fast shipping and great quality. Will definitely order again!"</p>
              <div class="mt-4 text-yellow-500">★★★★★</div>
            </div>
            <div class="bg-gray-50 p-6 rounded-lg">
              <div class="flex items-center mb-4">
                <div class="w-12 h-12 bg-blue-600 rounded-full mr-4"></div>
                <div>
                  <h4 class="font-semibold">Mike Johnson</h4>
                  <p class="text-sm text-gray-600">Verified Customer</p>
                </div>
              </div>
              <p class="text-gray-700 italic">"Best online shopping experience I've had. Five stars!"</p>
              <div class="mt-4 text-yellow-500">★★★★★</div>
            </div>
          </div>
        </div>
      </section>
    `,attributes:{class:"fa fa-comments"}}),f.add("cta-section",{label:"Call to Action",category:"Sections",content:`
      <section class="bg-blue-600 text-white py-16">
        <div class="container mx-auto px-4 text-center">
          <h2 class="text-4xl font-bold mb-4">Ready to Get Started?</h2>
          <p class="text-xl mb-8">Join thousands of satisfied customers today</p>
          <div class="flex gap-4 justify-center">
            <button class="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition">
              Get Started
            </button>
            <button class="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition">
              Learn More
            </button>
          </div>
        </div>
      </section>
    `,attributes:{class:"fa fa-bullhorn"}}),f.add("footer",{label:"Footer",category:"Sections",content:`
      <footer class="bg-gray-900 text-white py-12">
        <div class="container mx-auto px-4">
          <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 class="text-xl font-bold mb-4">About Us</h3>
              <p class="text-gray-400">Your trusted online store for quality products.</p>
            </div>
            <div>
              <h3 class="text-xl font-bold mb-4">Quick Links</h3>
              <ul class="space-y-2 text-gray-400">
                <li><a href="#" class="hover:text-white transition">Home</a></li>
                <li><a href="#" class="hover:text-white transition">Shop</a></li>
                <li><a href="#" class="hover:text-white transition">About</a></li>
                <li><a href="#" class="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
            <div>
              <h3 class="text-xl font-bold mb-4">Customer Service</h3>
              <ul class="space-y-2 text-gray-400">
                <li><a href="#" class="hover:text-white transition">FAQ</a></li>
                <li><a href="#" class="hover:text-white transition">Shipping</a></li>
                <li><a href="#" class="hover:text-white transition">Returns</a></li>
                <li><a href="#" class="hover:text-white transition">Support</a></li>
              </ul>
            </div>
            <div>
              <h3 class="text-xl font-bold mb-4">Newsletter</h3>
              <p class="text-gray-400 mb-4">Subscribe for updates and offers</p>
              <input type="email" placeholder="Your email" class="w-full px-4 py-2 rounded text-gray-900 mb-2">
              <button class="w-full bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
                Subscribe
              </button>
            </div>
          </div>
          <div class="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2026 Your Store. All rights reserved.</p>
          </div>
        </div>
      </footer>
    `,attributes:{class:"fa fa-bars"}}),f.add("container",{label:"Container",category:"Layout",content:'<div class="container mx-auto px-4 py-8"></div>',attributes:{class:"fa fa-square-o"}}),f.add("grid-2-col",{label:"2 Columns",category:"Layout",content:`
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="p-4 bg-gray-100 rounded">Column 1</div>
        <div class="p-4 bg-gray-100 rounded">Column 2</div>
      </div>
    `,attributes:{class:"fa fa-columns"}}),f.add("grid-3-col",{label:"3 Columns",category:"Layout",content:`
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="p-4 bg-gray-100 rounded">Column 1</div>
        <div class="p-4 bg-gray-100 rounded">Column 2</div>
        <div class="p-4 bg-gray-100 rounded">Column 3</div>
      </div>
    `,attributes:{class:"fa fa-th"}}),f.add("button",{label:"Button",category:"Components",content:`
      <button class="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-semibold">
        Click Me
      </button>
    `,attributes:{class:"fa fa-hand-pointer-o"}}),f.add("card",{label:"Card",category:"Components",content:`
      <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm">
        <h3 class="text-xl font-bold mb-2">Card Title</h3>
        <p class="text-gray-600 mb-4">Card description goes here. Add your content.</p>
        <button class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition">
          Learn More
        </button>
      </div>
    `,attributes:{class:"fa fa-id-card-o"}}),g=b.BlockManager,p.forEach(a=>{g.add(a.label.toLowerCase().replace(/\s+/g,"-"),{label:a.label,category:a.category,content:a.content,attributes:{class:"fa fa-cube"}})}),D.pages[F]){let a=D.pages[F];b.setComponents(a.html),b.setStyle(a.css)}b.on("update",()=>{if(!D||!F)return}),b.on("load",()=>{b.BlockManager.getCategories().each((a,b)=>{a.set("open",0===b)})}),setTimeout(()=>{let a=document.getElementById("blocks-container");if(a&&b){let c=b.BlockManager,d=c.getContainer();a.contains(d)||a.appendChild(d),c.render(),console.log("🛠️ Block Manager initialized and rendered");let e=a.querySelector(".gjs-category");e&&e.classList.add("gjs-open"),a.hasAttribute("data-listener-attached")||(a.addEventListener("click",a=>{let b=a.target.closest(".gjs-category-title");if(b){let a=b.closest(".gjs-category");a&&a.classList.toggle("gjs-open")}}),a.setAttribute("data-listener-attached","true"))}},1e3),c&&(C(b),z.current=b)}catch(a){if(console.error("Error initializing GrapesJS:",a),c){let b=a.message||"Failed to initialize editor";b.includes("Content Security Policy")||b.includes("eval")?y("Editor requires additional permissions. Please check browser settings or contact support."):(y("Failed to initialize editor. Redirecting to dashboard..."),setTimeout(()=>{u.push("/dashboard")},2e3))}}}).catch(a=>{console.error("Error loading GrapesJS modules:",a),c&&(y("Failed to load editor. Redirecting to dashboard..."),setTimeout(()=>{u.push("/dashboard")},2e3))})},100);return()=>{if(c=!1,d&&clearTimeout(d),z.current){try{z.current.destroy()}catch(a){console.error("Error destroying editor:",a)}z.current=null,C(null)}}},[D,P,y]);let _=async()=>{if(B&&D&&v)try{O(!0);let a=B.getHtml(),b=B.getCss(),c={...D,pages:{...D.pages,[F]:{...D.pages[F],html:a,css:b}}};await (0,f.saveGeneratedSiteToFirebase)(c,v),E(c),x("Page saved successfully!")}catch(a){console.error("Error saving page:",a),y("Failed to save page")}finally{O(!1)}},aa=async(a,b,c)=>{try{let d=L.find(b=>b.id===a);if(!d)return;let e={...d.settings,[b]:c};await (0,q.updatePageSetting)(a,{settings:e}),M(b=>b.map(b=>b.id===a?{...b,settings:e}:b)),x("Setting updated!")}catch(a){console.error("Error updating setting:",a),y("Failed to update setting")}};if(P)return(0,b.jsxs)("div",{className:"flex flex-col items-center justify-center h-screen bg-gray-50",children:[(0,b.jsx)("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"}),(0,b.jsx)("p",{className:"text-gray-600",children:"Loading editor..."}),(0,b.jsx)("p",{className:"text-sm text-gray-500 mt-2",children:"Fetching storefront data..."})]});if(!D)return(0,b.jsx)("div",{className:"flex flex-col items-center justify-center h-screen bg-gray-50 px-4",children:(0,b.jsxs)("div",{className:"max-w-md w-full bg-white rounded-lg shadow-lg p-6 text-center",children:[(0,b.jsx)("div",{className:"mb-4",children:(0,b.jsx)(m.XCircleIcon,{className:"w-16 h-16 text-red-500 mx-auto"})}),(0,b.jsx)("h2",{className:"text-xl font-semibold text-gray-900 mb-2",children:V||"Unable to Load Editor"}),(0,b.jsx)("p",{className:"text-gray-600 mb-6",children:V?.includes("connect")||V?.includes("offline")||V?.includes("Unable to connect")?"Unable to connect to Firebase. This is usually due to network connectivity issues. Please check your internet connection and try again.":V||"No storefront found. Please create a storefront first."}),(0,b.jsxs)("div",{className:"flex flex-col sm:flex-row gap-3 justify-center",children:[(0,b.jsx)(h.Button,{onClick:()=>{Y(a=>a+1),Z(!0)},className:"bg-blue-600 hover:bg-blue-700 text-white",loading:P,children:X>0?`Retry (${X})`:"Retry"}),(0,b.jsx)(h.Button,{onClick:()=>u.push("/dashboard"),variant:"bordered",className:"border-gray-300 text-gray-700 hover:bg-gray-50",children:"Go to Dashboard"})]}),V&&(0,b.jsx)("p",{className:"text-xs text-gray-500 mt-4",children:"If this persists, check your internet connection and Firebase configuration."})]})});let ab=Object.keys(D.pages||{});return(0,b.jsxs)("div",{className:"h-screen flex flex-col bg-gray-100",children:[(0,b.jsx)("style",{children:`
        .gjs-blocks-c, .gjs-sm-c, .gjs-layers-c {
          display: grid !important;
          grid-template-columns: repeat(3, 1fr) !important;
          gap: 8px !important;
          padding: 10px !important;
          background: transparent !important;
        }
        #blocks-container, #styles-container, #layers-container {
          min-height: 100% !important;
          padding-bottom: 40px !important;
        }
        /* Style Manager and Layers should be single column, only Blocks is 3-column */
        .gjs-sm-c, .gjs-layers-c {
          display: block !important;
        }
        .gjs-block {
          width: auto !important;
          min-height: 80px !important;
          color: white !important;
          border: 1px solid #efefef !important;
          padding: 8px !important;
          margin: 0 !important;
          display: flex !important;
          flex-direction: column !important;
          align-items: center !important;
          justify-content: center !important;
          transition: all 0.2s ease !important;
          cursor: pointer !important;
          background: rgba(255, 255, 255, 0.1) !important;
          border-radius: 4px !important;
        }
        .gjs-block:hover {
          border-color: #6366f1 !important;
          background: rgba(99, 102, 241, 0.2) !important;
          transform: translateY(-1px) !important;
        }
        .gjs-block-label, .gjs-block svg {
          color: white !important;
          fill: white !important;
          font-size: 13px !important;
          text-align: center !important;
          word-break: break-all !important;
          font-weight: 600 !important;
        }
        /* SECTION TITLES: Bold and White */
        .gjs-category-title, .gjs-sm-sector-title, .gjs-sm-title {
          background-color: #111827 !important;
          color: white !important;
          font-weight: 800 !important;
          padding: 10px 12px !important;
          margin: 12px 0 6px 0 !important;
          font-size: 12px !important;
          text-transform: uppercase !important;
          letter-spacing: 0.05em !important;
          border-bottom: 2px solid rgba(255,255,255,0.2) !important;
          display: flex !important;
          align-items: center !important;
          justify-content: space-between !important;
          cursor: pointer !important;
        }
        .gjs-category-title::after {
          content: '▼';
          font-size: 8px;
          transition: transform 0.3s ease;
        }
        .gjs-category.gjs-open .gjs-category-title::after {
          transform: rotate(-180deg);
        }
        /* Ensure categories are visible if they have the open class */
        .gjs-category:not(.gjs-open) .gjs-blocks-c {
          display: none !important;
        }
        .gjs-category.gjs-open .gjs-blocks-c {
          display: grid !important;
        }
        .gjs-blocks-c {
          transition: all 0.3s ease-out !important;
        }
        /* Style Manager Inner Labels */
        .gjs-sm-label, .gjs-sm-field, .gjs-sm-property {
          color: #e5e7eb !important;
        }
      `}),(0,b.jsxs)("div",{className:"bg-gradient-to-r from-white via-blue-50 to-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm",children:[(0,b.jsxs)("div",{className:"flex items-center gap-4",children:[(0,b.jsxs)(h.Button,{onClick:()=>u.push("/dashboard"),className:"flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white border-none shadow-sm transition-all",size:"sm",children:[(0,b.jsx)(i.ArrowLeftIcon,{className:"w-4 h-4 font-bold"}),"Dashboard"]}),(0,b.jsxs)("h1",{className:"text-lg font-semibold text-gray-800",children:["Editing: ",D.companyName]}),(0,b.jsxs)("div",{className:"flex items-center bg-gray-100/50 p-1 rounded-xl border border-gray-200",children:[(0,b.jsxs)(h.Button,{onClick:()=>{K("pages"),I(!0)},variant:"bordered",size:"sm",className:`min-w-[100px] flex items-center justify-center gap-2 transition-all rounded-lg border-none ${"pages"===J&&H?"bg-white text-orange-600 shadow-sm":"text-gray-500 hover:text-gray-700 hover:bg-white/50"}`,children:[(0,b.jsx)(j,{className:"w-4 h-4"}),(0,b.jsx)("span",{children:"Pages"})]}),(0,b.jsxs)(h.Button,{onClick:()=>{K("blocks"),I(!0)},variant:"bordered",size:"sm",className:`min-w-[100px] flex items-center justify-center gap-2 transition-all rounded-lg border-none ${"blocks"===J&&H?"bg-white text-purple-600 shadow-sm":"text-gray-500 hover:text-gray-700 hover:bg-white/50"}`,children:[(0,b.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1V5z"})}),(0,b.jsx)("span",{children:"Blocks"})]}),(0,b.jsxs)(h.Button,{onClick:()=>{K("settings"),I(!0)},variant:"bordered",size:"sm",className:`min-w-[100px] flex items-center justify-center gap-2 transition-all rounded-lg border-none ${"settings"===J&&H?"bg-white text-blue-600 shadow-sm":"text-gray-500 hover:text-gray-700 hover:bg-white/50"}`,children:[(0,b.jsx)(o.Cog6ToothIcon,{className:"w-4 h-4"}),(0,b.jsx)("span",{children:"Settings"})]})]})]}),(0,b.jsxs)("div",{className:"flex items-center gap-2",children:[(0,b.jsxs)("span",{className:"text-sm text-gray-600",children:["Current: ",F]}),(0,b.jsx)(h.Button,{onClick:_,isDisabled:N,className:"bg-primary-500 hover:bg-primary-600 text-white",children:N?"Saving...":"Save Page"})]})]}),(0,b.jsxs)("div",{className:"flex-1 flex overflow-hidden",children:[(0,b.jsxs)("div",{className:"flex-1 relative flex flex-col h-full overflow-hidden",children:[(0,b.jsx)("div",{ref:A,className:"flex-1 bg-white"}),(0,b.jsxs)("div",{className:"absolute bottom-8 right-8 z-40 group",children:[(0,b.jsx)("div",{className:"absolute -top-12 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-xs py-1.5 px-3 rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none",children:"Save changes to Cloud"}),(0,b.jsx)(h.Button,{onClick:_,isDisabled:N,className:`w-14 h-14 rounded-full shadow-2xl flex items-center justify-center p-0 transition-all transform hover:scale-110 active:scale-95 ${N?"bg-gray-400":"bg-primary-500 hover:bg-primary-600"}`,children:N?(0,b.jsx)("div",{className:"w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"}):(0,b.jsx)(n.CloudArrowUpIcon,{className:"w-7 h-7 text-white"})})]})]}),(0,b.jsxs)("div",{className:`relative transition-all duration-300 ease-in-out ${H?"w-96":"w-0"} bg-white border-l border-gray-200 shadow-xl flex flex-col z-30`,children:[(0,b.jsx)("button",{onClick:()=>I(!H),className:"absolute top-1/2 -translate-y-1/2 -left-7 w-10 h-10 bg-white border border-gray-200 rounded-full shadow-lg flex items-center justify-center hover:bg-gray-50 transition-all z-50 hover:scale-110 active:scale-95",title:H?"Collapse Panel":"Expand Panel",children:(0,b.jsx)("svg",{className:`w-5 h-5 text-gray-500 transition-transform duration-300 ${H?"rotate-180":"rotate-0"}`,fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M15 19l-7-7 7-7"})})}),(0,b.jsxs)("div",{className:"w-96 h-full flex flex-col overflow-hidden",children:[(0,b.jsxs)("div",{className:"flex border-b border-gray-200 bg-gray-50 shrink-0",children:[(0,b.jsxs)("button",{onClick:()=>K("blocks"),className:`flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${"blocks"===J?"bg-white text-purple-600 border-b-2 border-purple-600":"text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,title:"Blocks",children:[(0,b.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM14 5a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1V5z"})}),(0,b.jsx)("span",{className:"scale-90",children:"Blocks"})]}),(0,b.jsxs)("button",{onClick:()=>K("styles"),className:`flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${"styles"===J?"bg-white text-green-600 border-b-2 border-green-600":"text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,title:"Styles",children:[(0,b.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.657-1.657a2 2 0 012.828 0l2.829 2.829a2 2 0 010 2.828l-8.486 8.485M7 17h.01"})}),(0,b.jsx)("span",{className:"scale-90",children:"Styles"})]}),(0,b.jsxs)("button",{onClick:()=>K("layers"),className:`flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${"layers"===J?"bg-white text-blue-600 border-b-2 border-blue-600":"text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,title:"Layers",children:[(0,b.jsx)("svg",{className:"w-4 h-4",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"})}),(0,b.jsx)("span",{className:"scale-90",children:"Layers"})]}),(0,b.jsxs)("button",{onClick:()=>K("pages"),className:`flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${"pages"===J?"bg-white text-orange-600 border-b-2 border-orange-600":"text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,title:"Pages",children:[(0,b.jsx)(j,{className:"w-4 h-4"}),(0,b.jsx)("span",{className:"scale-90",children:"Pages"})]}),(0,b.jsxs)("button",{onClick:()=>K("settings"),className:`flex-1 px-2 py-3 text-xs font-bold transition flex flex-col items-center justify-center gap-1 ${"settings"===J?"bg-white text-indigo-600 border-b-2 border-indigo-600":"text-gray-500 hover:text-gray-800 hover:bg-gray-100"}`,title:"Settings",children:[(0,b.jsx)(o.Cog6ToothIcon,{className:"w-4 h-4"}),(0,b.jsx)("span",{className:"scale-90",children:"Settings"})]})]}),(0,b.jsxs)("div",{className:"flex-1 overflow-y-auto",children:[(0,b.jsx)("div",{id:"blocks-container",className:`p-4 ${"blocks"===J?"":"hidden"}`}),(0,b.jsx)("div",{id:"styles-container",className:`p-4 ${"styles"===J?"":"hidden"}`}),(0,b.jsx)("div",{id:"layers-container",className:`p-4 ${"layers"===J?"":"hidden"}`}),(0,b.jsxs)("div",{className:`p-4 ${"pages"===J?"":"hidden"}`,children:[(0,b.jsxs)("h3",{className:"text-sm font-semibold text-gray-700 mb-4 flex items-center gap-2",children:[(0,b.jsx)(j,{className:"w-5 h-5 text-orange-600"}),"Your Pages"]}),(0,b.jsx)("div",{className:"space-y-2",children:ab.map(a=>(0,b.jsxs)("button",{onClick:()=>(a=>{if(!B||!D||!D.pages[a])return;if(D.pages[F]){let a=B.getHtml(),b=B.getCss();E({...D,pages:{...D.pages,[F]:{...D.pages[F],html:a,css:b}}})}let b=D.pages[a];B.setComponents(b.html),B.setStyle(b.css),G(a),setTimeout(()=>{B.BlockManager.render()},100)})(a),className:`w-full text-left px-4 py-3 rounded-lg flex items-center gap-3 transition ${F===a?"bg-orange-50 text-orange-700 border-2 border-orange-200 shadow-sm":"text-gray-700 hover:bg-gray-50 border-2 border-transparent"}`,children:[(0,b.jsx)(k.DocumentIcon,{className:"w-5 h-5"}),(0,b.jsx)("span",{className:"capitalize font-medium",children:a.replace(/-/g," ")}),F===a&&(0,b.jsx)(l.CheckCircleIcon,{className:"w-5 h-5 ml-auto text-orange-600"})]},a))})]}),(0,b.jsxs)("div",{className:`p-4 ${"settings"===J?"":"hidden"}`,children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,b.jsxs)("h3",{className:"text-sm font-semibold text-gray-700 flex items-center gap-2",children:[(0,b.jsx)(o.Cog6ToothIcon,{className:"w-5 h-5 text-blue-600"}),"Storefront Settings"]}),(0,b.jsx)(h.Button,{variant:"ghost",size:"xs",onClick:$,className:"text-gray-400 hover:text-gray-600",isDisabled:R,children:"Refresh"})]}),(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsxs)("div",{className:"bg-blue-50 border border-blue-100 rounded-lg p-3",children:[(0,b.jsx)("h4",{className:"text-xs font-black text-blue-800 uppercase tracking-widest mb-1",children:"Navigation Menu"}),(0,b.jsx)("p",{className:"text-[10px] text-blue-600 font-medium font-mono leading-tight",children:"DRAG TO REORDER. DRAG OVER TO NEST."})]}),(0,b.jsxs)("div",{className:"space-y-2",children:[L.filter(a=>!a.parentId).sort((a,b)=>(a.order||0)-(b.order||0)).map(a=>(0,b.jsx)(r,{setting:a,allSettings:L,onToggle:aa,onMove:async(a,b,c)=>{if(!L.find(b=>b.id===a))return;let d=null,e=0;if("inside"===c){d=b;let a=L.filter(a=>a.parentId===b);e=a.length>0?Math.max(...a.map(a=>a.order||0))+1:0}else{let a=L.find(a=>a.id===b);d=a?.parentId||null,e="before"===c?(a?.order||0)-.5:(a?.order||0)+.5}try{S(!0),await (0,q.updatePageSetting)(a,{parentId:d,order:e}),await $(),x("Menu updated")}catch(a){y("Failed to move item"),console.error(a)}finally{S(!1)}}},a.id)),0===L.length&&!R&&(0,b.jsx)("div",{className:"p-8 text-center text-gray-400 text-xs italic bg-gray-50 rounded-2xl border border-dashed border-gray-200",children:"No pages found."}),R&&(0,b.jsx)("div",{className:"space-y-2 animate-pulse mt-4",children:[1,2,3].map(a=>(0,b.jsx)("div",{className:"h-12 bg-gray-100 rounded-xl w-full"},a))})]})]})]})]})]})]})]})]})};function t(){let a=(0,d.useSearchParams)(),c=a.get("subdomain")||void 0,e=a.get("page")||void 0;return(0,b.jsx)(s,{subdomain:c,initialPage:e})}function u(){return(0,b.jsx)(c.Suspense,{fallback:(0,b.jsx)("div",{className:"flex items-center justify-center h-screen",children:(0,b.jsx)("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"})}),children:(0,b.jsx)(t,{})})}a.s(["default",()=>u],279698)}];

//# sourceMappingURL=app_editor_page_tsx_b89e3172._.js.map