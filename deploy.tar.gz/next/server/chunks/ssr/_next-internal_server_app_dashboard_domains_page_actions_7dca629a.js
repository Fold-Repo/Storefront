module.exports=[951959,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_domains_page_actions_7dca629a.js.map