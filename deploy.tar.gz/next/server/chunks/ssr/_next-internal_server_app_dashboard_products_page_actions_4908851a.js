module.exports=[578773,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_products_page_actions_4908851a.js.map