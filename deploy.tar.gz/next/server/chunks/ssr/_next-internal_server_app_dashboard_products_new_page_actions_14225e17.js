module.exports=[443055,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_products_new_page_actions_14225e17.js.map