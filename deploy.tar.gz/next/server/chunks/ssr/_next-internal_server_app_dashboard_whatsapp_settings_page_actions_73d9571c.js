module.exports=[820582,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_whatsapp_settings_page_actions_73d9571c.js.map