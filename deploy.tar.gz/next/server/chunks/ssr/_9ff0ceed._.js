module.exports=[119970,a=>{"use strict";var b=a.i(514205);a.s(["PopupModal",()=>b.default])},134083,940777,a=>{"use strict";var b=a.i(187924),c=a.i(572131);a.i(462822);var d=a.i(119970);a.i(576106);var e=a.i(282518),f=a.i(544051),g=a.i(771733),h=a.i(877466),i=a.i(381427),j=a.i(193428),k=a.i(89329),l=a.i(182374),m=a.i(91503),n=a.i(930731),o=a.i(329514),p=a.i(43949),q=a.i(180417);let r=c.forwardRef(function({title:a,titleId:b,...d},e){return c.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:e,"aria-labelledby":b},d),a?c.createElement("title",{id:b},a):null,c.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v2.25a2.25 2.25 0 0 1-2.25 2.25H6a2.25 2.25 0 0 1-2.25-2.25V6ZM3.75 15.75A2.25 2.25 0 0 1 6 13.5h2.25a2.25 2.25 0 0 1 2.25 2.25V18a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18v-2.25ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v2.25A2.25 2.25 0 0 1 18 10.5h-2.25a2.25 2.25 0 0 1-2.25-2.25V6ZM13.5 15.75a2.25 2.25 0 0 1 2.25-2.25H18a2.25 2.25 0 0 1 2.25 2.25V18A2.25 2.25 0 0 1 18 20.25h-2.25A2.25 2.25 0 0 1 13.5 18v-2.25Z"}))});var s=a.i(571987),t=a.i(736545),u=a.i(50944),v=a.i(516911),w=a.i(1271),x=a.i(889840);let y=[{id:1,title:"Idea Scope",description:"What type of storefront do you want to create?"},{id:2,title:"Company Details",description:"Tell us about your company"},{id:3,title:"Description",description:"Describe your business"},{id:4,title:"Subdomain",description:"Choose your storefront URL"},{id:5,title:"Logo",description:"Upload your company logo"},{id:6,title:"Theming",description:"Customize your storefront appearance"},{id:7,title:"Site Layout",description:"Choose how your site is structured"},{id:8,title:"AI Design",description:"Generate design recommendations"}],z=[{value:"fashion",label:"Fashion & Apparel"},{value:"electronics",label:"Electronics"},{value:"food",label:"Food & Beverages"},{value:"home",label:"Home & Living"},{value:"beauty",label:"Beauty & Cosmetics"},{value:"sports",label:"Sports & Outdoors"},{value:"books",label:"Books & Media"},{value:"toys",label:"Toys & Games"},{value:"other",label:"Other"}];a.s([],134083),a.s(["StorefrontWizard",0,({isOpen:a,onClose:A,onComplete:B})=>{let C=(0,u.useRouter)(),{user:D,loading:E}=(0,t.useAuth)(),[F,G]=(0,c.useState)(1),[H,I]=(0,c.useState)(!1),{showSuccess:J,showError:K}=(0,w.useToast)(),L=(0,x.getMainDomain)(),[M,N]=(0,c.useState)(!1),[O,P]=(0,c.useState)(!1),[Q,R]=(0,c.useState)(!1),[S,T]=(0,c.useState)([]),[U,V]=(0,c.useState)(0),[W,X]=(0,c.useState)(""),[Y,Z]=(0,c.useState)({}),[$,_]=(0,c.useState)(!1),[aa,ab]=(0,c.useState)(!1),ac=async()=>ad(),ad=()=>({ideaScope:"",companyName:"",description:"",subdomain:"",logo:null,logoPreview:null,theme:ae(),layout:"multi-page"}),ae=()=>({primaryColor:"#3B82F6",fontFamily:"Inter",designFeel:"modern"}),[af,ag]=(0,c.useState)(ad()),[ah,ai]=(0,c.useState)({}),[aj,ak]=(0,c.useState)(!1),[al,am]=(0,c.useState)(!1);(0,c.useEffect)(()=>{(async()=>{a&&!al&&(ag(await ac()),am(!0))})()},[a,D,al]),(0,c.useEffect)(()=>{E||I(!0),(async()=>{if(D&&a&&H)try{let a=await (0,v.loadWizardFromFirebase)(D);a&&(ag({ideaScope:a.ideaScope||"",companyName:a.companyName||"",description:a.description||"",subdomain:a.subdomain||"",logo:null,logoPreview:a.logoPreview||null,theme:a.theme||ae(),layout:a.layout||"multi-page"}),J("Your saved progress has been loaded!"))}catch(a){console.error("Error loading Firebase data:",a)}})()},[D,a,E,H]),(0,c.useEffect)(()=>{},[af,a,D,al]),(0,c.useEffect)(()=>{},[a]);let an=a=>{let{name:b,value:c}=a.target;ag({...af,[b]:c}),ah[b]&&ai(a=>({...a,[b]:""}))},ao=a=>{let b=a.target.files?.[0];if(b){if(b.size>5242880)return void ai(a=>({...a,logo:"File size must be less than 5MB"}));if(!b.type.startsWith("image/"))return void ai(a=>({...a,logo:"File must be an image"}));let a=new FileReader;a.onloadend=()=>{ag({...af,logo:b,logoPreview:a.result})},a.readAsDataURL(b),ah.logo&&ai(a=>({...a,logo:""}))}},ap=a=>{let b={};switch(a){case 1:af.ideaScope||(b.ideaScope="Please select an idea scope");break;case 2:af.companyName||(b.companyName="Company name is required");break;case 3:af.description?af.description.length<50&&(b.description="Description must be at least 50 characters"):b.description="Description is required";break;case 4:af.subdomain?/^[a-z0-9-]+$/.test(af.subdomain)?af.subdomain.length<3&&(b.subdomain="Subdomain must be at least 3 characters"):b.subdomain="Subdomain can only contain lowercase letters, numbers, and hyphens":b.subdomain="Subdomain is required";break;case 5:break;case 6:af.theme?.primaryColor||(b.primaryColor="Primary color is required"),af.theme?.fontFamily||(b.fontFamily="Font family is required"),af.theme?.designFeel||(b.designFeel="Design feel is required");break;case 7:af.layout||(b.layout="Please select a layout")}return ai(b),0===Object.keys(b).length},aq=async()=>{if(!af.companyName||!af.description||!af.ideaScope)return void K("Please complete the previous steps before generating AI recommendations");N(!0);try{await new Promise(a=>setTimeout(a,2e3));let a=`Based on your ${af.ideaScope} storefront for ${af.companyName}, we recommend a ${af.theme?.designFeel||"modern"} design approach. The storefront should feature a clean, professional layout with ${af.theme?.primaryColor||"blue"} as the primary accent color. Use ${af.theme?.fontFamily||"Inter"} font family for a contemporary feel. Focus on showcasing your products with high-quality imagery and clear call-to-action buttons. The design should emphasize ${af.description}`;ag(b=>({...b,theme:{...b.theme,aiDescription:a}})),J("AI design recommendations generated!")}catch(a){K("Failed to generate AI recommendations. Please try again.")}finally{N(!1)}},ar=async()=>{if(!af.companyName||!af.ideaScope)return void K("Company name and niche are required");_(!0);try{let a=await fetch(`/api/ai/generate-description/questions/all?companyName=${encodeURIComponent(af.companyName)}&niche=${encodeURIComponent(af.ideaScope)}`);if(!a.ok)throw Error("Failed to fetch questions");let b=await a.json();if(b.questions&&b.questions.length>0)T(b.questions),V(0),X(""),Z({});else throw Error("No questions received")}catch(a){K(a.message||"Failed to load questions")}finally{_(!1)}},as=async()=>{if(!W.trim())return void K("Please provide an answer");let a=S[U];if(!a)return;let b={...Y,[a.question]:W};Z(b),X(""),U<S.length-1?V(U+1):await at(b)},at=async a=>{if(0===Object.keys(a).length)return void K("No answers provided");ab(!0);try{let b=await fetch("/api/ai/generate-description",{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({companyName:af.companyName,niche:af.ideaScope,answers:a})});if(!b.ok)throw Error("Failed to generate description");let c=await b.json();ag(a=>({...a,description:c.description})),J("Business description generated successfully!"),R(!1),T([]),Z({}),V(0),X("")}catch(a){K(a.message||"Failed to generate description")}finally{ab(!1)}},au=async()=>{if(ap(F)){if(!D){let a=window.location.pathname;C.push(`/signin?callbackUrl=${encodeURIComponent(a)}`);return}B?.(af),A(),setTimeout(()=>{G(1),ag(ad()),ak(!1)},500)}},av=()=>{A()};return(0,b.jsxs)(b.Fragment,{children:[(0,b.jsxs)(d.PopupModal,{isOpen:a,onClose:av,size:"2xl",placement:"center",showCloseButton:!1,className:"max-w-3xl",children:[(0,b.jsxs)("div",{className:"p-6 relative",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-6",children:[(0,b.jsxs)("div",{children:[(0,b.jsx)("h2",{className:"text-2xl font-bold text-neutral-800",children:"Create Your Storefront"}),(0,b.jsxs)("p",{className:"text-sm text-neutral-600 mt-1",children:["Step ",F," of ",y.length]})]}),(0,b.jsx)("button",{onClick:av,className:"p-2 hover:bg-neutral-100 rounded-full transition-colors",children:(0,b.jsx)(k.XMarkIcon,{className:"w-5 h-5 text-neutral-600"})})]}),(0,b.jsx)("div",{className:"mb-8",children:(0,b.jsx)("div",{className:"flex items-start justify-between mb-2 w-full",children:y.map((a,c)=>(0,b.jsxs)("div",{className:"flex items-start flex-1 relative",children:[(0,b.jsxs)("div",{className:"flex flex-col items-center flex-1 z-10",children:[(0,b.jsx)("div",{className:`w-10 h-10 rounded-full flex items-center justify-center border-2 transition-colors shrink-0 ${F>=a.id?"bg-blue-600 border-blue-600 text-white":"border-neutral-300 bg-white text-neutral-400"}`,children:F>a.id?(0,b.jsx)(o.CheckCircleIcon,{className:"w-6 h-6"}):(0,b.jsx)("span",{className:"text-sm font-semibold",children:a.id})}),(0,b.jsx)("p",{className:`text-xs mt-2 text-center max-w-[100px] ${F>=a.id?"text-neutral-800 font-medium":"text-neutral-400"}`,children:a.title})]}),c<y.length-1&&(0,b.jsx)("div",{className:`absolute top-5 left-[calc(50%+20px)] right-0 h-0.5 transition-colors ${F>a.id?"bg-blue-600":"bg-neutral-200"}`,style:{width:"calc(100% - 40px)"}})]},a.id))})}),(0,b.jsx)("div",{className:"min-h-[400px] mb-6 relative",children:(()=>{switch(F){case 1:return(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsxs)("div",{className:"text-center mb-6",children:[(0,b.jsx)(l.SparklesIcon,{className:"w-16 h-16 text-blue-600 mx-auto mb-4"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"What type of storefront do you want to create?"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Select the category that best describes your business"})]}),(0,b.jsx)("div",{className:"grid grid-cols-2 gap-3",children:z.map(a=>(0,b.jsx)("button",{type:"button",onClick:()=>{ag({...af,ideaScope:a.value}),ah.ideaScope&&ai(a=>({...a,ideaScope:""}))},className:`p-4 rounded-lg border-2 transition-all text-left ${af.ideaScope===a.value?"border-blue-600 bg-blue-50":"border-neutral-200 hover:border-blue-300"}`,children:(0,b.jsx)("span",{className:"text-sm font-medium text-neutral-800",children:a.label})},a.value))}),ah.ideaScope&&(0,b.jsx)("p",{className:"text-sm text-error mt-2",children:ah.ideaScope})]});case 2:return(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsxs)("div",{className:"text-center mb-6",children:[(0,b.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Company Information"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Tell us about your company"})]}),(0,b.jsx)(e.Input,{label:"Dfold Lab",name:"companyName",type:"text",value:af.companyName,onChange:an,error:ah.companyName,placeholder:"Enter your company name",className:"w-full"})]});case 3:return(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsxs)("div",{className:"text-center mb-6",children:[(0,b.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Business Description"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Describe what your business does (minimum 50 characters)"})]}),(0,b.jsxs)("div",{className:"relative",children:[(0,b.jsx)(f.TextArea,{label:"Description",name:"description",value:af.description,onChange:an,error:ah.description,placeholder:"Tell us about your business, products, and what makes you unique...",className:"w-full min-h-[150px] pr-12"}),af.companyName&&af.ideaScope&&(0,b.jsx)("button",{type:"button",onClick:()=>{af.companyName&&af.ideaScope?(R(!0),Z({}),V(0),T([]),ar()):K("Please complete company name and niche selection first")},className:"absolute right-3 top-9 p-2 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-600 transition-colors",title:"Generate description with AI",children:(0,b.jsx)(l.SparklesIcon,{className:"w-5 h-5"})})]}),(0,b.jsxs)("p",{className:"text-xs text-neutral-500",children:[af.description.length," / 50 characters minimum"]}),af.companyName&&af.ideaScope&&(0,b.jsxs)("p",{className:"text-xs text-blue-600 flex items-center gap-1",children:[(0,b.jsx)(l.SparklesIcon,{className:"w-3 h-3"}),"Click the sparkles icon to generate a description with AI"]})]});case 4:return(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsxs)("div",{className:"text-center mb-6",children:[(0,b.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Choose Your Subdomain"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"This will be your storefront URL"})]}),(0,b.jsxs)("div",{className:"relative",children:[(0,b.jsx)(e.Input,{label:"Subdomain",name:"subdomain",type:"text",value:af.subdomain,onChange:an,error:ah.subdomain,placeholder:"your-store",className:"w-full pr-24"}),(0,b.jsxs)("div",{className:"absolute right-3 top-9 text-neutral-500 text-sm",children:[".",L]})]}),(0,b.jsxs)("div",{className:"bg-neutral-50 p-4 rounded-lg",children:[(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Your storefront will be available at:"}),(0,b.jsxs)("p",{className:"text-sm font-semibold text-primary-600 mt-1",children:[af.subdomain||"your-store",".",L]})]})]});case 5:return(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsxs)("div",{className:"text-center mb-6",children:[(0,b.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Upload Your Logo"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Add your company logo (PNG, JPG, max 5MB)"})]}),(0,b.jsx)("div",{className:"border-2 border-dashed border-neutral-300 rounded-lg p-8 text-center hover:border-primary-400 transition-colors",children:af.logoPreview?(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsx)("div",{className:"relative w-32 h-32 mx-auto",children:(0,b.jsx)(s.default,{src:af.logoPreview,alt:"Logo preview",fill:!0,className:"object-contain rounded-lg"})}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:af.logo?.name}),(0,b.jsx)("button",{type:"button",onClick:()=>{ag(a=>({...a,logo:null,logoPreview:null}))},className:"text-sm text-error hover:text-error/80",children:"Remove"})]}):(0,b.jsxs)("label",{className:"cursor-pointer",children:[(0,b.jsx)("input",{type:"file",accept:"image/*",onChange:ao,className:"hidden"}),(0,b.jsxs)("div",{className:"space-y-2",children:[(0,b.jsx)("div",{className:"w-12 h-12 mx-auto bg-neutral-100 rounded-full flex items-center justify-center",children:(0,b.jsx)("svg",{className:"w-6 h-6 text-neutral-600",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:(0,b.jsx)("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M12 4v16m8-8H4"})})}),(0,b.jsx)("p",{className:"text-sm font-medium text-neutral-700",children:"Click to upload or drag and drop"}),(0,b.jsx)("p",{className:"text-xs text-neutral-500",children:"PNG, JPG up to 5MB"})]})]})}),ah.logo&&(0,b.jsx)("p",{className:"text-sm text-error mt-2",children:ah.logo})]});case 6:return(0,b.jsxs)("div",{className:"space-y-6",children:[(0,b.jsxs)("div",{className:"text-center mb-6",children:[(0,b.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"Customize Your Storefront Appearance"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Choose colors, fonts, and design style for your storefront"})]}),(0,b.jsx)(i.ColorPicker,{value:af.theme?.primaryColor||"#3B82F6",onChange:a=>{ag(b=>({...b,theme:{...b.theme,primaryColor:a}})),ah.primaryColor&&ai(a=>({...a,primaryColor:""}))},label:"Primary Color"}),ah.primaryColor&&(0,b.jsx)("p",{className:"text-sm text-error mt-1",children:ah.primaryColor}),(0,b.jsx)("div",{children:(0,b.jsxs)(g.Select,{label:"Font Family",name:"fontFamily",value:af.theme?.fontFamily||"Inter",onChange:a=>{ag(b=>({...b,theme:{...b.theme,fontFamily:a.target.value}})),ah.fontFamily&&ai(a=>({...a,fontFamily:""}))},error:ah.fontFamily,className:"w-full",children:[(0,b.jsx)("option",{value:"Inter",children:"Inter (Modern)"}),(0,b.jsx)("option",{value:"Roboto",children:"Roboto (Clean)"}),(0,b.jsx)("option",{value:"Poppins",children:"Poppins (Bold)"}),(0,b.jsx)("option",{value:"Open Sans",children:"Open Sans (Friendly)"}),(0,b.jsx)("option",{value:"Montserrat",children:"Montserrat (Elegant)"}),(0,b.jsx)("option",{value:"Lato",children:"Lato (Professional)"})]})}),(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:"block text-sm font-medium text-neutral-700 mb-2",children:"Design Feel"}),(0,b.jsx)("div",{className:"grid grid-cols-2 gap-3",children:[{value:"modern",label:"Modern",desc:"Clean and minimalist"},{value:"classic",label:"Classic",desc:"Traditional and elegant"},{value:"bold",label:"Bold",desc:"Vibrant and energetic"},{value:"minimal",label:"Minimal",desc:"Simple and focused"}].map(a=>(0,b.jsxs)("button",{type:"button",onClick:()=>{ag(b=>({...b,theme:{...b.theme,designFeel:a.value}})),ah.designFeel&&ai(a=>({...a,designFeel:""}))},className:`p-4 rounded-lg border-2 text-left transition-all ${af.theme?.designFeel===a.value?"border-blue-600 bg-blue-50":"border-neutral-200 hover:border-blue-300"}`,children:[(0,b.jsx)("div",{className:"font-semibold text-neutral-800",children:a.label}),(0,b.jsx)("div",{className:"text-xs text-neutral-600 mt-1",children:a.desc})]},a.value))}),ah.designFeel&&(0,b.jsx)("p",{className:"text-sm text-error mt-2",children:ah.designFeel})]})]});case 7:return(0,b.jsx)("div",{className:"space-y-6",children:(0,b.jsxs)("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-4",children:[(0,b.jsxs)("button",{onClick:()=>ag({...af,layout:"single-page"}),className:`p-6 rounded-2xl border-2 transition-all text-left flex flex-col gap-4 ${"single-page"===af.layout?"border-blue-500 bg-blue-50":"border-neutral-100 hover:border-neutral-200 bg-white"}`,children:[(0,b.jsx)("div",{className:`p-3 rounded-xl w-fit ${"single-page"===af.layout?"bg-blue-500 text-white":"bg-neutral-100 text-neutral-500"}`,children:(0,b.jsx)(q.DocumentIcon,{className:"w-8 h-8"})}),(0,b.jsxs)("div",{children:[(0,b.jsx)("h3",{className:"font-bold text-lg text-neutral-900",children:"Single Page Layout"}),(0,b.jsx)("p",{className:"text-sm text-neutral-500 mt-1",children:"Everything on one page (Home, Products, Cart, Checkout). Perfect for simple, fast stores."})]}),"single-page"===af.layout&&(0,b.jsx)(o.CheckCircleIcon,{className:"w-6 h-6 text-blue-500 absolute top-4 right-4"})]}),(0,b.jsxs)("button",{onClick:()=>ag({...af,layout:"multi-page"}),className:`p-6 rounded-2xl border-2 transition-all text-left flex flex-col gap-4 ${"multi-page"===af.layout?"border-blue-500 bg-blue-50":"border-neutral-100 hover:border-neutral-200 bg-white"}`,children:[(0,b.jsx)("div",{className:`p-3 rounded-xl w-fit ${"multi-page"===af.layout?"bg-blue-500 text-white":"bg-neutral-100 text-neutral-500"}`,children:(0,b.jsx)(r,{className:"w-8 h-8"})}),(0,b.jsxs)("div",{children:[(0,b.jsx)("h3",{className:"font-bold text-lg text-neutral-900",children:"Multi Page Layout"}),(0,b.jsx)("p",{className:"text-sm text-neutral-500 mt-1",children:"Standard e-commerce structure with separate pages for browsing, cart, and checkout."})]}),"multi-page"===af.layout&&(0,b.jsx)(o.CheckCircleIcon,{className:"w-6 h-6 text-blue-500 absolute top-4 right-4"})]})]})});case 8:return(0,b.jsxs)("div",{className:"space-y-6",children:[(0,b.jsxs)("div",{className:"text-center mb-6",children:[(0,b.jsx)(l.SparklesIcon,{className:"w-16 h-16 text-blue-600 mx-auto mb-4"}),(0,b.jsx)("h3",{className:"text-xl font-semibold text-neutral-800 mb-2",children:"AI Design Recommendations"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Generate personalized design recommendations based on your storefront details"})]}),af.theme?.aiDescription?(0,b.jsxs)("div",{className:"bg-blue-50 border border-blue-200 rounded-lg p-6",children:[(0,b.jsxs)("div",{className:"flex items-start gap-3",children:[(0,b.jsx)(l.SparklesIcon,{className:"w-6 h-6 text-primary-600 flex-shrink-0 mt-0.5"}),(0,b.jsxs)("div",{className:"flex-1",children:[(0,b.jsx)("h4",{className:"font-semibold text-neutral-800 mb-2",children:"AI Design Analysis"}),(0,b.jsx)("p",{className:"text-sm text-neutral-700 leading-relaxed whitespace-pre-wrap",children:af.theme.aiDescription})]})]}),(0,b.jsx)(h.Button,{type:"button",variant:"light",onClick:aq,isLoading:M,className:"mt-4",children:"Regenerate"})]}):(0,b.jsx)("div",{className:"text-center py-12",children:M?(0,b.jsx)(j.CaptivatingLoader,{loadingTexts:["Analyzing your business details...","Generating color palette options...","Selecting typography combinations...","Crafting layout recommendations...","Finalizing your design..."],subText:"Our AI is creating a custom design just for you"}):(0,b.jsxs)(b.Fragment,{children:[(0,b.jsx)("p",{className:"text-neutral-600 mb-6",children:"Click the button below to generate AI-powered design recommendations for your storefront"}),(0,b.jsx)(h.Button,{type:"button",onPress:aq,loading:M,color:"primary",className:"text-white",startContent:(0,b.jsx)(l.SparklesIcon,{className:"w-5 h-5"}),children:"Generate Design Recommendations"})]})})]});default:return null}})()}),(0,b.jsxs)("div",{className:"flex items-center justify-between pt-6 border-t border-neutral-200",children:[(0,b.jsx)(h.Button,{type:"button",variant:"bordered",onClick:()=>{F>1&&G(F-1)},isDisabled:1===F,startContent:(0,b.jsx)(n.ArrowLeftIcon,{className:"w-4 h-4"}),className:`border-neutral-300 text-neutral-600 hover:bg-neutral-50 ${1===F?"invisible":"visible"}`,children:"Previous"}),(0,b.jsx)("div",{className:"flex gap-2",children:F<y.length?(0,b.jsx)(h.Button,{type:"button",onClick:()=>{ap(F)&&F<y.length&&G(F+1)},className:"bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md hover:shadow-lg transition-all",endContent:(0,b.jsx)(m.ArrowRightIcon,{className:"w-4 h-4"}),children:"Next"}):(0,b.jsxs)(b.Fragment,{children:[!D&&(0,b.jsxs)("div",{className:"flex items-center gap-2 text-sm text-neutral-600 mb-2",children:[(0,b.jsx)(p.LockClosedIcon,{className:"w-4 h-4"}),(0,b.jsx)("span",{children:"Sign in required to create storefront"})]}),(0,b.jsx)(h.Button,{type:"button",onClick:au,loading:aj,className:"bg-blue-600 hover:bg-blue-700 text-white font-semibold shadow-md hover:shadow-lg transition-all",endContent:(0,b.jsx)(o.CheckCircleIcon,{className:"w-4 h-4"}),children:"Create Storefront"})]})})]})]}),(0,b.jsx)(d.PopupModal,{isOpen:O,onClose:()=>P(!1),title:"Found Saved Progress",size:"md",children:(0,b.jsxs)("div",{className:"space-y-4",children:[(0,b.jsx)("p",{className:"text-neutral-600",children:"We found saved progress from a previous session. Would you like to continue from where you left off?"}),(0,b.jsxs)("div",{className:"flex gap-3",children:[(0,b.jsx)(h.Button,{onPress:()=>{P(!1),J("Continuing with saved progress")},className:"flex-1 bg-blue-600 hover:bg-blue-700 text-white",children:"Continue"}),(0,b.jsx)(h.Button,{onPress:()=>{(0,v.clearWizardLocally)(),ag(ad()),P(!1),J("Starting fresh")},variant:"bordered",className:"flex-1",children:"Start Fresh"})]})]})}),H?D||F!==y.length?null:(0,b.jsx)("div",{className:"absolute inset-0 bg-white/95 backdrop-blur-sm flex items-center justify-center z-10 rounded-lg",children:(0,b.jsxs)("div",{className:"text-center p-6 max-w-md",children:[(0,b.jsx)(p.LockClosedIcon,{className:"w-12 h-12 text-blue-600 mx-auto mb-4"}),(0,b.jsx)("h3",{className:"text-lg font-semibold text-neutral-800 mb-2",children:"Sign In Required"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600 mb-6",children:"Please sign in or create an account to create your storefront. Your progress has been saved and will be restored when you return."}),(0,b.jsxs)("div",{className:"flex gap-3 justify-center",children:[(0,b.jsx)(h.Button,{onClick:()=>{A(),C.push("/signup")},className:"bg-blue-600 hover:bg-blue-700 text-white",children:"Sign Up"}),(0,b.jsx)(h.Button,{onClick:()=>{let a=window.location.pathname;C.push(`/signin?callbackUrl=${encodeURIComponent(a)}`)},variant:"bordered",className:"border-neutral-300",children:"Sign In"})]})]})}):(0,b.jsx)("div",{className:"absolute inset-0 bg-white/80 backdrop-blur-sm flex items-center justify-center z-10 rounded-lg",children:(0,b.jsxs)("div",{className:"text-center",children:[(0,b.jsx)("div",{className:"animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600",children:"Checking authentication..."})]})})]}),(0,b.jsx)(d.PopupModal,{isOpen:Q,onClose:()=>{R(!1),Z({}),T([]),V(0),X("")},title:"AI Description Generator",size:"md",children:(0,b.jsx)("div",{className:"space-y-6",children:aa?(0,b.jsx)(j.CaptivatingLoader,{loadingTexts:["Synthesizing your answers...","Drafting compelling copy...","Optimizing for SEO...","Polishing the tone...","Almost ready..."],subText:"Creating your unique business description"}):$?(0,b.jsx)("div",{className:"py-8",children:(0,b.jsx)(j.CaptivatingLoader,{loadingTexts:["Preparing AI interview...","Understanding your business...","Crafting relevant questions...","Almost ready..."],subText:"Our AI is tailored to your niche"})}):S.length>0&&U<S.length?(0,b.jsxs)(b.Fragment,{children:[(0,b.jsxs)("div",{className:"bg-blue-50 rounded-lg p-4 mb-4",children:[(0,b.jsxs)("div",{className:"flex items-center justify-between mb-2",children:[(0,b.jsxs)("span",{className:"text-sm font-semibold text-blue-600",children:["Question ",U+1," of ",S.length]}),(0,b.jsxs)("span",{className:"text-xs text-blue-500",children:[Math.round((U+1)/S.length*100),"% complete"]})]}),(0,b.jsx)("div",{className:"w-full bg-blue-200 rounded-full h-2",children:(0,b.jsx)("div",{className:"bg-blue-600 h-2 rounded-full transition-all duration-300",style:{width:`${(U+1)/S.length*100}%`}})})]}),(0,b.jsxs)("div",{children:[(0,b.jsx)("label",{className:"block text-sm font-medium text-neutral-700 mb-2",children:S[U]?.question}),S[U]?.hint&&(0,b.jsx)("p",{className:"text-xs text-neutral-500 mb-2",children:S[U]?.hint}),S[U]?.type==="textarea"?(0,b.jsx)(f.TextArea,{value:W,onChange:a=>X(a.target.value),placeholder:"Type your answer here...",className:"w-full min-h-[120px]",name:"aiAnswer"}):(0,b.jsx)(e.Input,{value:W,onChange:a=>X(a.target.value),placeholder:"Type your answer here...",className:"w-full",name:"aiAnswer",type:"text"})]}),(0,b.jsxs)("div",{className:"flex gap-3",children:[(0,b.jsx)(h.Button,{onClick:as,className:"flex-1 bg-blue-600 hover:bg-blue-700 text-white",isDisabled:!W.trim(),children:U<S.length-1?"Next Question":"Generate Description"}),(0,b.jsx)(h.Button,{onClick:()=>{R(!1),Z({}),T([]),V(0),X("")},variant:"light",className:"px-4",children:"Cancel"})]})]}):(0,b.jsxs)("div",{className:"text-center py-8",children:[(0,b.jsx)(l.SparklesIcon,{className:"w-16 h-16 text-blue-600 mx-auto mb-4"}),(0,b.jsx)("h3",{className:"text-lg font-semibold text-neutral-800 mb-2",children:"Let AI Help Create Your Description"}),(0,b.jsx)("p",{className:"text-sm text-neutral-600 mb-6",children:"We'll ask you 5 quick questions about your business to generate a compelling description."}),(0,b.jsx)(h.Button,{onClick:ar,className:"bg-blue-600 hover:bg-blue-700 text-white",isDisabled:$,children:$?"Loading...":"Start Questionnaire"})]})})})]})}],940777)},82919,872811,a=>{"use strict";let b=async a=>{var b,c;let f,{pageType:h,businessNiche:i,companyName:j,theme:k,templateHtml:l}=a;return l?{html:(b=l,c={primaryColor:k.primaryColor,fontFamily:k.fontFamily,companyName:j,businessNiche:i},(f=(f=(f=(f=b).replace(/--primary-color:\s*[^;]+/g,`--primary-color: ${c.primaryColor}`)).replace(/font-family:\s*[^;]+/g,`font-family: ${c.fontFamily}, sans-serif`)).replace(/\{\{companyName\}\}/g,c.companyName)).replace(/\{\{businessNiche\}\}/g,c.businessNiche)),css:e(k),metadata:{title:`${j} - ${g(h)}`,description:`Browse ${i} products at ${j}`}}:await d(a)},c=async a=>{let{wizardData:c}=a,d="single-page"===c.layout,h=d?["homepage"]:["homepage","products","product-detail","cart","checkout"];console.log("🚀 Starting complete site generation for:",c.companyName),console.log(`📋 Layout: ${c.layout}`),console.log(`📋 Will generate ${h.length} essential pages`);let i={},j=c.theme||{primaryColor:"#3B82F6",fontFamily:"Inter",designFeel:"modern"};console.log(`📄 Generating ${h.length} essential pages...`);let k=h.map(async a=>{try{let d=Date.now(),e=await b({pageType:a,businessNiche:c.ideaScope,companyName:c.companyName,description:c.description,theme:j,logoUrl:c.logoPreview||void 0,layout:c.layout}),f=((Date.now()-d)/1e3).toFixed(1);return console.log(`✅ Successfully generated ${a} in ${f}s`),{pageType:a,page:e}}catch(b){return console.error(`❌ Error generating ${a}:`,b),{pageType:a,page:{html:f({pageType:a,businessNiche:c.ideaScope,companyName:c.companyName,description:c.description,theme:j}),css:e(j),metadata:{title:`${c.companyName} - ${g(a)}`,description:c.description}}}}});if((await Promise.all(k)).forEach(a=>{i[a.pageType]=a.page}),!d)for(let a of d?[]:["categories","account","search","testimonial"])console.log(`📄 Creating basic template for optional page: ${a}`),i[a]={html:f({pageType:a,businessNiche:c.ideaScope,companyName:c.companyName,description:c.description,theme:j}),css:e(j),metadata:{title:`${c.companyName} - ${g(a)}`,description:c.description}};return console.log("🎉 Complete site generation finished. Generated pages:",Object.keys(i).length),i};async function d(a){try{console.log("🔄 Generating page with AI:",a.pageType);let b=new AbortController,c=setTimeout(()=>{console.warn("⏱️ Request timeout for:",a.pageType),b.abort()},18e4);try{let d=await fetch("/api/ai/generate",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({pageType:a.pageType,businessNiche:a.businessNiche,companyName:a.companyName,description:a.description,theme:a.theme,logoUrl:a.logoUrl,layout:a.layout}),signal:b.signal});if(clearTimeout(c),console.log("📡 API response status:",d.status,d.statusText),!d.ok){let a;try{a=await d.json()}catch{a={message:`HTTP ${d.status}: ${d.statusText}`}}throw console.error("❌ API error:",a),Error(a.message||a.error||`API error: ${d.status}`)}let e=await d.json();if(console.log("✅ API response received:",{success:e.success,hasPage:!!e.page}),!e.success||!e.page)throw console.error("❌ Invalid response structure:",e),Error("Invalid response from AI service");return e.page}catch(a){if(clearTimeout(c),"AbortError"===a.name)throw Error("Request timeout: AI generation took too long (2 minutes)");throw a}}catch(b){return console.error("❌ Error calling AI generation API:",b),console.error("Error details:",{message:b.message,stack:b.stack}),console.warn("⚠️ Falling back to basic template for:",a.pageType),{html:f(a),css:e(a.theme),metadata:{title:`${a.companyName} - ${g(a.pageType)}`,description:a.description}}}}function e(a){return`
    :root {
      --primary-color: ${a.primaryColor};
      --font-family: ${a.fontFamily}, sans-serif;
    }
    
    body {
      font-family: var(--font-family);
    }
    
    .primary-bg {
      background-color: var(--primary-color);
    }
    
    .primary-text {
      color: var(--primary-color);
    }
    
    /* Add more theme-based styles */
  `}function f(a){let{pageType:b,companyName:c,businessNiche:d,theme:e,description:f}=a,h=new Date().getFullYear(),i=`
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${c} - ${g(b)}</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=${e.fontFamily.replace(" ","+")}:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
      body { font-family: '${e.fontFamily}', sans-serif; }
      .primary-bg { background-color: ${e.primaryColor}; }
      .primary-text { color: ${e.primaryColor}; }
      .primary-border { border-color: ${e.primaryColor}; }
    </style>
  `,j=`
    <header class="bg-white shadow-sm sticky top-0 z-50">
      <nav class="container mx-auto px-4 py-4 flex items-center justify-between">
        <a href="/" class="text-2xl font-bold primary-text">${c}</a>
        {{menu}}
      </nav>
    </header>
  `,k=`
    <footer class="bg-gray-900 text-white py-12">
      <div class="container mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-8">
        <div>
          <h3 class="text-xl font-bold mb-4">${c}</h3>
          <p class="text-gray-400">${f||"Your trusted "+d+" store."}</p>
        </div>
        <div>
          <h4 class="font-semibold mb-4">Quick Links</h4>
          {{footerLinks}}
        </div>
        <div>
          <h4 class="font-semibold mb-4">Contact</h4>
          <p class="text-gray-400">Email: info@{{companyName}}.com</p>
        </div>
        <div>
          <h4 class="font-semibold mb-4">Follow Us</h4>
          <div class="flex gap-4">
            <a href="#" class="text-gray-400 hover:text-white">Twitter</a>
            <a href="#" class="text-gray-400 hover:text-white">Facebook</a>
          </div>
        </div>
      </div>
      <div class="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500">
        &copy; ${h} ${c}. All rights reserved.
      </div>
    </footer>
  `,l=`
    <script>
      // Dynamic Data Fetching Script
      (function() {
        const API_BASE = '/api';
        const storefrontId = window.location.hostname.split('.')[0]; // Extract subdomain

        async function fetchProducts() {
          try {
            const container = document.getElementById('products-container');
            if (!container) return;
            const res = await fetch(API_BASE + '/storefront/' + storefrontId + '/products');
            if (!res.ok) return;
            const data = await res.json();
            // Render logic can be added here or rely on server-side injection
            console.log('Products fetched:', data);
          } catch (e) { console.error('Failed to fetch products', e); }
        }

        async function fetchCategories() {
          try {
            const container = document.getElementById('categories-container');
            if (!container) return;
            const res = await fetch(API_BASE + '/storefront/' + storefrontId + '/categories');
            if (!res.ok) return;
            const data = await res.json();
            console.log('Categories fetched:', data);
          } catch (e) { console.error('Failed to fetch categories', e); }
        }

        document.addEventListener('DOMContentLoaded', function() {
          fetchProducts();
          fetchCategories();
        });
      })();
    </script>
  `,m="";switch(b){case"homepage":m=`
        <!-- Hero Section -->
        <section class="relative bg-gradient-to-r from-gray-900 to-gray-700 text-white py-24">
          <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-6xl font-bold mb-6">Welcome to ${c}</h1>
            <p class="text-xl md:text-2xl text-gray-300 mb-8 max-w-2xl mx-auto">${f||"Discover exceptional "+d+" products curated just for you."}</p>
            <a href="/products" class="inline-block primary-bg text-white px-8 py-4 rounded-lg font-semibold hover:opacity-90 transition-opacity">Shop Now</a>
          </div>
        </section>
        
        <!-- Featured Products -->
        <section class="py-16 bg-gray-50">
          <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-10">Featured Products</h2>
            <div id="products-container">{{featuredProducts}}</div>
          </div>
        </section>

        <!-- About Us Section -->
        <section class="py-16 bg-white">
          <div class="container mx-auto px-4 max-w-3xl text-center">
            <h2 class="text-3xl font-bold mb-6">About Our Story</h2>
            <p class="text-lg text-gray-600 mb-8">${f||"We are dedicated to providing the best products in the "+d+" industry."}</p>
          </div>
        </section>

        <!-- Contact Us Section -->
        <section class="py-16 bg-gray-50">
          <div class="container mx-auto px-4 max-w-2xl">
            <h2 class="text-3xl font-bold text-center mb-10">Get In Touch</h2>
            <form class="space-y-4 bg-white p-8 rounded-xl shadow-sm">
              <div><input type="text" placeholder="Name" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></div>
              <div><input type="email" placeholder="Email" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></div>
              <div><textarea placeholder="Message" rows="4" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea></div>
              <button type="button" class="w-full primary-bg text-white py-3 rounded-lg font-semibold hover:opacity-90">Send Message</button>
            </form>
          </div>
        </section>
        <!-- Categories -->
        <section class="py-16">
          <div class="container mx-auto px-4">
            <h2 class="text-3xl font-bold text-center mb-10">Shop by Category</h2>
            <div id="categories-container">{{categories}}</div>
          </div>
        </section>
      `;break;case"products":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Our Products</h1>
            <div id="products-container">{{products}}</div>
          </div>
        </section>
      `;break;case"product-detail":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <div class="grid md:grid-cols-2 gap-12">
              <div class="aspect-square bg-gray-100 rounded-2xl flex items-center justify-center">
                <img src="{{product.image}}" alt="{{product.name}}" class="max-h-full object-contain"/>
              </div>
              <div>
                <h1 class="text-3xl font-bold mb-4">{{product.name}}</h1>
                <p class="text-2xl primary-text font-semibold mb-6">{{product.price}}</p>
                <p class="text-gray-600 mb-8">{{product.description}}</p>
                <button class="primary-bg text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 w-full md:w-auto">Add to Cart</button>
              </div>
            </div>
          </div>
        </section>
      `;break;case"categories":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Shop by Category</h1>
            <div id="categories-container">{{categories}}</div>
          </div>
        </section>
      `;break;case"cart":m=`
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Your Cart</h1>
            <div id="cart-items" class="bg-white rounded-xl shadow p-6">
              <p class="text-gray-500 text-center py-12">Your cart is empty.</p>
            </div>
            <div class="mt-8 flex justify-end">
              <a href="/checkout" class="primary-bg text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90">Proceed to Checkout</a>
            </div>
          </div>
        </section>
      `;break;case"checkout":m=`
        <section class="py-12">
          <div class="container mx-auto px-4 max-w-2xl">
            <h1 class="text-3xl font-bold mb-8 text-center">Checkout</h1>
            <form class="space-y-6 bg-white p-8 rounded-xl shadow">
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label><input type="text" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Address</label><textarea class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></textarea></div>
              <button type="submit" class="w-full primary-bg text-white py-3 rounded-lg font-semibold hover:opacity-90">Place Order</button>
            </form>
          </div>
        </section>
      `;break;case"about":m=`
        <section class="py-16">
          <div class="container mx-auto px-4 max-w-3xl text-center">
            <h1 class="text-4xl font-bold mb-6">About ${c}</h1>
            <p class="text-xl text-gray-600 mb-8">${f||"We are passionate about bringing you the best "+d+" products."}</p>
            <div class="grid md:grid-cols-3 gap-8 mt-12">
              <div class="p-6 bg-gray-50 rounded-xl"><h3 class="font-bold text-lg mb-2">Our Mission</h3><p class="text-gray-600">To deliver quality and value to our customers.</p></div>
              <div class="p-6 bg-gray-50 rounded-xl"><h3 class="font-bold text-lg mb-2">Our Vision</h3><p class="text-gray-600">To be a leader in the ${d} industry.</p></div>
              <div class="p-6 bg-gray-50 rounded-xl"><h3 class="font-bold text-lg mb-2">Our Values</h3><p class="text-gray-600">Integrity, Quality, Customer Focus.</p></div>
            </div>
          </div>
        </section>
      `;break;case"contact":m=`
        <section class="py-16">
          <div class="container mx-auto px-4 max-w-2xl">
            <h1 class="text-4xl font-bold mb-6 text-center">Contact Us</h1>
            <p class="text-center text-gray-600 mb-10">Have questions? We'd love to hear from you.</p>
            <form class="space-y-6 bg-white p-8 rounded-xl shadow">
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Name</label><input type="text" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Email</label><input type="email" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
              <div><label class="block text-sm font-medium text-gray-700 mb-1">Message</label><textarea rows="5" class="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none"></textarea></div>
              <button type="submit" class="w-full primary-bg text-white py-3 rounded-lg font-semibold hover:opacity-90">Send Message</button>
            </form>
          </div>
        </section>
      `;break;case"testimonial":m=`
        <section class="py-16 bg-gray-50">
          <div class="container mx-auto px-4">
            <h1 class="text-4xl font-bold mb-10 text-center">What Our Customers Say</h1>
            <div class="grid md:grid-cols-3 gap-8">{{testimonials}}</div>
          </div>
        </section>
      `;break;case"account":m=`
        <section class="py-12">
          <div class="container mx-auto px-4 max-w-4xl">
            <h1 class="text-3xl font-bold mb-8">My Account</h1>
            <div class="grid md:grid-cols-3 gap-6">
              <a href="/account/orders" class="p-6 bg-white rounded-xl shadow hover:shadow-lg transition-shadow"><h3 class="font-bold">Order History</h3><p class="text-gray-500 text-sm">View past orders</p></a>
              <a href="/account/settings" class="p-6 bg-white rounded-xl shadow hover:shadow-lg transition-shadow"><h3 class="font-bold">Account Settings</h3><p class="text-gray-500 text-sm">Manage your profile</p></a>
              <a href="/account/addresses" class="p-6 bg-white rounded-xl shadow hover:shadow-lg transition-shadow"><h3 class="font-bold">Addresses</h3><p class="text-gray-500 text-sm">Manage your addresses</p></a>
            </div>
          </div>
        </section>
      `;break;case"search":m=`
        {{breadcrumbs}}
        <section class="py-12">
          <div class="container mx-auto px-4">
            <h1 class="text-3xl font-bold mb-8">Search Results</h1>
            <div class="mb-8"><input type="text" placeholder="Search products..." class="w-full md:w-1/2 border border-gray-300 rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:outline-none"></div>
            <div id="products-container">{{products}}</div>
          </div>
        </section>
      `;break;default:m=`
        <section class="py-16">
          <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl font-bold mb-6">${g(b)}</h1>
            <p class="text-gray-600">Welcome to ${c}.</p>
          </div>
        </section>
      `}return`
    <!DOCTYPE html>
    <html lang="en">
    <head>${i}</head>
    <body class="bg-gray-50 text-gray-900 min-h-screen flex flex-col">
      ${j}
      <main class="flex-grow">${m}</main>
      ${k}
      ${l}
    </body>
    </html>
  `}function g(a){return({homepage:"Home",categories:"Categories",products:"Products","product-detail":"Product Details",cart:"Shopping Cart",checkout:"Checkout",account:"My Account",search:"Search Results",about:"About Us",contact:"Contact Us",testimonial:"Testimonials"})[a]||"Page"}async function h(a){try{let b=await fetch(`/api/user/plan?userId=${encodeURIComponent(a)}`);if(!b.ok)throw Error(`Failed to get user plan: ${b.statusText}`);return(await b.json()).data||null}catch(a){return console.error("Error getting user plan:",a),null}}async function i(a){try{let b=await h(a);if(!b)return{allowed:!1,current:0,max:0,message:"User plan not found"};let c=b.currentUsage.storefronts,d=b.limits.maxStorefronts;if(c>=d)return{allowed:!1,current:c,max:d,message:`You have reached your plan limit of ${d} storefront${d>1?"s":""}. Please upgrade your plan to create more storefronts.`};return{allowed:!0,current:c,max:d}}catch(a){return console.error("Error checking storefront limit:",a),{allowed:!1,current:0,max:0,message:"Error checking limits"}}}async function j(a){try{let b=await fetch("/api/user/plan",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:a,action:"incrementStorefront"})});if(!b.ok){let a=await b.json();throw Error(a.error||"Failed to increment storefront count")}}catch(a){throw console.error("Error incrementing storefront count:",a),a}}async function k(a,b){try{let c=await fetch("/api/user/plan",{method:"PATCH",headers:{"Content-Type":"application/json"},body:JSON.stringify({userId:a,action:"incrementPage",storefrontId:b})});if(!c.ok){let a=await c.json();throw Error(a.error||"Failed to increment page count")}}catch(a){throw console.error("Error incrementing page count:",a),a}}a.s(["generateCompleteSite",0,c],82919),a.i(69387),a.i(60574),a.i(554950),a.s(["canCreateStorefront",()=>i,"getUserPlan",()=>h,"incrementPageCount",()=>k,"incrementStorefrontCount",()=>j],872811)},90722,a=>{"use strict";var b=a.i(572131);let c=b.forwardRef(function({title:a,titleId:c,...d},e){return b.createElement("svg",Object.assign({xmlns:"http://www.w3.org/2000/svg",fill:"none",viewBox:"0 0 24 24",strokeWidth:1.5,stroke:"currentColor","aria-hidden":"true","data-slot":"icon",ref:e,"aria-labelledby":c},d),a?b.createElement("title",{id:c},a):null,b.createElement("path",{strokeLinecap:"round",strokeLinejoin:"round",d:"M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75C7.5 20.496 6.996 21 6.375 21h-2.25A1.125 1.125 0 0 1 3 19.875v-6.75ZM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V8.625ZM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 0 1-1.125-1.125V4.125Z"}))});a.s(["ChartBarIcon",0,c],90722)}];

//# sourceMappingURL=_9ff0ceed._.js.map