module.exports=[458377,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28landing%29_page_actions_5b4e8c1d.js.map