module.exports=[527439,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%28auth%29_reset-password_page_actions_07d1adfb.js.map