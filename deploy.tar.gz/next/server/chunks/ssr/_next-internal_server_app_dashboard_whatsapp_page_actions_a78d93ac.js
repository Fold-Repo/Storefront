module.exports=[485566,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_whatsapp_page_actions_a78d93ac.js.map