module.exports=[814556,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_components_page_actions_8c0cfa38.js.map