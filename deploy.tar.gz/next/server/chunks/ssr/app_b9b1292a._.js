module.exports=[326758,a=>{a.v("/_next/static/media/favicon.3d75de69.ico")},438872,a=>{"use strict";let b={src:a.i(326758).default,width:48,height:48};a.s(["default",0,b])}];

//# sourceMappingURL=app_b9b1292a._.js.map