module.exports=[987105,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_sales_page_actions_182f1439.js.map