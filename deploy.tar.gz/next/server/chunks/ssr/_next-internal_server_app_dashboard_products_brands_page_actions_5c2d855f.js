module.exports=[473974,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_products_brands_page_actions_5c2d855f.js.map