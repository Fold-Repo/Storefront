module.exports=[19504,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_dashboard_whatsapp_marketing_page_actions_7e60b647.js.map