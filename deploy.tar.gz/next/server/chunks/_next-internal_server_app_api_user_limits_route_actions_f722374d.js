module.exports=[92220,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_user_limits_route_actions_f722374d.js.map