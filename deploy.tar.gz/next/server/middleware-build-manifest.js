globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/8a40a56d5df81d62.js",
    "static/chunks/1b707127480b1bc2.js",
    "static/chunks/7a8c3074575153c7.js",
    "static/chunks/c0f364d84595f0c6.js",
    "static/chunks/b562a94b35d7daa2.js",
    "static/chunks/turbopack-706f2f20ad47477d.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];