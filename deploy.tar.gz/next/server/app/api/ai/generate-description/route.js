var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate-description/route.js")
R.c("server/chunks/[root-of-the-server]__9f02bab4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_@anthropic-ai_sdk_index_mjs_b618add1._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_generate-description_route_actions_069911c3.js")
R.m(700323)
module.exports=R.m(700323).exports
