var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate-description/questions/all/route.js")
R.c("server/chunks/[root-of-the-server]__634c8ad2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_@anthropic-ai_sdk_index_mjs_b618add1._.js")
R.c("server/chunks/ce889_server_app_api_ai_generate-description_questions_all_route_actions_d9241380.js")
R.m(598717)
module.exports=R.m(598717).exports
