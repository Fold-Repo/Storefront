var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate-description/questions/route.js")
R.c("server/chunks/[root-of-the-server]__d8c62169._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_@anthropic-ai_sdk_index_mjs_b618add1._.js")
R.c("server/chunks/ce889_server_app_api_ai_generate-description_questions_route_actions_4b6bdec5.js")
R.m(772534)
module.exports=R.m(772534).exports
