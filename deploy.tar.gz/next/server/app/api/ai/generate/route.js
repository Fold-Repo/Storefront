var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ai/generate/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_f2319586.js")
R.c("server/chunks/node_modules_@anthropic-ai_sdk_index_mjs_b618add1._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_ai_generate_route_actions_c237a67b.js")
R.m(989014)
module.exports=R.m(989014).exports
