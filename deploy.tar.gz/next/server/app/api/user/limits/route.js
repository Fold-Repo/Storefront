var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/user/limits/route.js")
R.c("server/chunks/[root-of-the-server]__e34da9c7._.js")
R.c("server/chunks/[root-of-the-server]__08654993._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/_8b169e80._.js")
R.c("server/chunks/_next-internal_server_app_api_user_limits_route_actions_f722374d.js")
R.m(701213)
module.exports=R.m(701213).exports
