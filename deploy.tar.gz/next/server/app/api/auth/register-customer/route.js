var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/register-customer/route.js")
R.c("server/chunks/[root-of-the-server]__a2f32b52._.js")
R.c("server/chunks/[root-of-the-server]__e34da9c7._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/node_modules_5cf12a84._.js")
R.c("server/chunks/_8b169e80._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_register-customer_route_actions_51e8395a.js")
R.m(341725)
module.exports=R.m(341725).exports
